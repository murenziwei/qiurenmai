<?php
namespace app\api\validate;

use think\Validate;

class Calendar extends Validate
{
    protected $rule = [
        'start_day'  => 'require',
        //'calendar' => 'require',
        'search_word' => 'require',
        'day_count' => 'require|number'
    ];


    protected $field = [
        'start_day'  => '开始时间',
        //'calendar' => 'require',
        'search_word' => '搜索关键词',
        'day_count' => '天数'
    ];
}