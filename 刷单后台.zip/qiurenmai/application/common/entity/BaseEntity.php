<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/5/11
 * Time: 18:35
 */

namespace app\common\entity;


class BaseEntity
{
    public function params()
    {
        return array_filter((array)$this);
    }
}