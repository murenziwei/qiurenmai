<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/16
 * Time: 9:05
 */

namespace app\common\logic;
use app\common\BaseModel;
use app\common\model\Country as countryModel;

class Country extends BaseModel
{
    public function findAll(){
        $data= countryModel::findAll(['is_deleted'=>0]);
        return $this->successReturn('获取数据成功',$data->toArray());
    }
}