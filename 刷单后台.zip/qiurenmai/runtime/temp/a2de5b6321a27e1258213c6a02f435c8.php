<?php /*a:1:{s:87:"D:\phpstudy\PHPTutorial\WWW\shuadan\application\admin\view\member\accept_task_list.html";i:1560235847;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.0</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/css/font.css">
    <link rel="stylesheet" href="/static/css/xadmin.css">
    <script type="text/javascript" src="/static/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        .layui-form-select .layui-anim-upbit{z-index: 999999 !important;}
    </style>
</head>

<body>
<div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">会员管理</a>
        <a>
          <cite>接受的任务</cite></a>
      </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
</div>
<div class="x-body">
    <!-- <div class="layui-row"> -->
        <!--<form class="layui-form layui-col-md12 x-so layui-form-pane">-->
            <!--<input class="layui-input" placeholder="标题" name="search" >-->
            <!--<button class="layui-btn"  lay-submit="" lay-filter="sreach"><i class="layui-icon">&#xe615;</i></button>-->
        <!--</form>-->
    <!-- </div> -->
    <!-- <xblock> -->
        <!-- <button class="layui-btn layui-btn-danger" onclick="delAll()"><i class="layui-icon"></i>批量删除</button> -->
        <!-- <button class="layui-btn" onclick="x_admin_show('添加套餐','<?php echo url('Member/addPackage'); ?>',1000,600)">
            <i class="layui-icon"></i>添加
        </button> -->
        <!-- <span class="x-right" style="line-height:40px">共有数据： 条</span> -->
    <!-- </xblock> -->
    <table class="layui-table">
        <thead>
        <tr>
            <!-- <th>
                <div class="layui-unselect header layui-form-checkbox" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
            </th> -->
            <th>ID</th>
            <th>旺旺ID</th>
            <th>状态</th>
            <th>接手时间</th>
            <th>任务详情</th>
        </tr>
        </thead>
        <tbody>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <tr>

            <td><?php echo htmlentities($vo['id']); ?></td>
            <td><?php echo htmlentities($vo['wangwang_id']); ?></td>
            <td>
                <?php switch($vo['status']): case "3": ?>
                        待操作
                    <?php break; case "4": ?>
                        待返款
                    <?php break; case "5": ?>
                        待评价
                    <?php break; case "6": ?>
                        已完成
                    <?php break; case "7": ?>
                        已完成
                    <?php break; case "8": ?>
                        已完成
                    <?php break; ?>
                <?php endswitch; ?>
            </td>
            <td><?php echo htmlentities(date('Y-m-d H:i:s',!is_numeric($vo['accept_at'])? strtotime($vo['accept_at']) : $vo['accept_at'])); ?></td>
            <td>
                <td>
               <!--  <a title="发布的任务"  onclick="x_admin_show('发布的任务','/index.php/admin/Member/sendTaskList?id=<?php echo htmlentities($vo['id']); ?>')" href="javascript:;"> -->
                <i class="layui-icon">&#xe63c;</i>
                <!-- </a> -->
                </td>
            </td>

        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
    <?php echo $list->render(); ?>


</div>
<script>
    layui.use('laydate', function(){
        var laydate = layui.laydate;



        //执行一个laydate实例
        laydate.render({
            elem: '#start' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#end' //指定元素
        });
    });

    /*用户-停用*/
    function member_stop(obj,id){
        layer.confirm('确认要停用吗？',function(index){

            if($(obj).attr('title')=='启用'){

                //发异步把用户状态进行更改
                $(obj).attr('title','停用')
                $(obj).find('i').html('&#xe62f;');

                $(obj).parents("tr").find(".td-status").find('span').addClass('layui-btn-disabled').html('已停用');
                layer.msg('已停用!',{icon: 5,time:1000});

            }else{
                $(obj).attr('title','启用')
                $(obj).find('i').html('&#xe601;');

                $(obj).parents("tr").find(".td-status").find('span').removeClass('layui-btn-disabled').html('已启用');
                layer.msg('已启用!',{icon: 5,time:1000});
            }

        });
    }

    /*用户-删除*/
    function member_del(obj,id){
        layer.confirm('确认取消吗？',function(index){
            $.ajax({
                type:'post',
                data:{'id':id},
                url:'<?php echo url("admin/Member/cancelTask"); ?>',
                dataType:'json',
                success:function (json) {
                    if (json.code == 1) {
                        //发异步删除数据
                        $(obj).parents("tr").remove();
                        layer.msg(json.msg,{icon:1,time:1000});
                    }else{
                        layer.msg(json.msg,{icon: 2,time:1000});
                    }
                }
            });
        });
    }

    /*审核*/
    function ck_shop(obj,id,status){
        layer.confirm('确定操作吗？',function(index){
            $.ajax({
                type:'post',
                data:{'id':id,'status':status},
                url:'<?php echo url("admin/Member/doCkShop"); ?>',
                dataType:'json',
                success:function (json) {
                    if (json.code == 1) {
                        //发异步删除数据
                        //$(obj).parents("tr").remove();
                        if(status == 1){
                            var msg = '<font color="green">已通过</font>';
                        }else{
                            var msg = '<font color="red">不通过</font>';
                        }
                        $(obj).parents("td").html(msg);
                        layer.msg(json.msg,{icon:1,time:1000});
                    }else{
                        layer.msg(json.msg,{icon: 2,time:1000});
                    }
                }
            });
        });
    }

    // function delAll (argument) {

    //     var data = tableCheck.getData();
    //     layer.confirm('确认要删除吗？'+data,function(index){
    //         layer.confirm('确认要删除吗？'+data,function(index){
    //             $.ajax({
    //                 type:'post',
    //                 data:{'id':data},
    //                 url:'<?php echo url("admin/Member/doDelPackage"); ?>',
    //                 dataType:'json',
    //                 success:function (json) {
    //                     if (json.code == 1) {
    //                         //捉到所有被选中的，发异步进行删除
    //                         layer.msg('删除成功', {icon: 1});
    //                         $(".layui-form-checked").not('.header').parents('tr').remove();
    //                     }else{
    //                         layer.msg(json.message,{icon: 2,time:1000});
    //                     }
    //                 }
    //             });
    //         });
    //     });
    // }
</script>
</body>

</html>