<?php
namespace app\api\validate;



class BankCard extends BaseVali
{
    protected $rule = [
        'name'  => 'require|max:10',
        'bank'  => 'require',
        'open_city'  => 'require',
        'open_branch_name'  => 'require',
        'phone'  => 'require|isMobile',
        'card_no' => 'require'
    ];

    protected $field = [
        'name'  => '姓名',
        'bank'  => '选择银行',
        'open_city'  =>'开户行城市',
        'open_branch_name'  => '开户行支行名称',
        'phone'  => '手机号',
        'card_no' => '银行卡号'
    ];

}