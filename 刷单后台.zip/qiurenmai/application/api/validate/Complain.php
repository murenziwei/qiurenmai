<?php
namespace app\api\validate;

use think\Validate;

class Complain extends Validate
{
    protected $rule = [
        'son_task_id'  => 'require|number',
        'type' => 'require|number|between:1,5',
        'note' => 'require',
        'img1' => 'require',
        'img2' => 'require'
    ];

    protected $field = [
        'son_task_id'  => '任务编号',
        'type' => '投诉类型',
        'note' => '投诉说明',
        'img1' => '图片证据',
        'img2' => '图片证据'
    ];

}