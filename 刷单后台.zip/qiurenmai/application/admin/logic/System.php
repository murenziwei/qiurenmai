<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 13:26
 */

namespace app\admin\logic;

use app\common\BaseModel;
use app\common\model\Config as configModel;

class System extends BaseModel
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

    public function saveData(){
        $data = $this->requestData;
        $inc_type = $data['inc_type'];
        unset($data['inc_type']);
        unset($data['from']);
        $res = configModel::tpCache($inc_type,'',$data);
        if(!$res)
            return $this->failReturn('保存失败');
        return $this->successReturn('保存成功');
    }
}