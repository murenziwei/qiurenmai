<?php
namespace app\admin\controller;

use think\facade\Session;

class Index extends Base
{
    public function index()
    {//var_dump(Session::get());exit;
        echo $this->fetch('layout/layout');
    }

    public function welcome(){
        echo $this->fetch();
    }
}
