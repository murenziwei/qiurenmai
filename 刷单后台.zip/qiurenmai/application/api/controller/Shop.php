<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-06-22 18:17:02
 */
namespace app\api\controller;

use think\Db;
use app\api\validate\Shop as ShopVali;
use app\api\model\Config as ConfigModel;

class Shop extends Base
{
    //绑定店铺
    public function bindShop(){
        $data = input();
        $validate = new ShopVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        //不超过10个
        $conf = ConfigModel::getConf("base");
        $data["user_id"] = $this ->user["id"];
        $bind_count = Db::name("bind_shop") ->where(["user_id"=>$data["user_id"],"platform_type"=>$data["platform_type"],"is_del"=>0]) ->count();
        if($bind_count > $conf["shop_upper_limit"]){
            exit(ajaxReturn([],0,"超出店铺绑定上限"));
        }
        //接单间隔
        $data["take_interval"] = $conf["default_take_interval"];
        unset($data["access_token"]);
        $res = Db::name("bind_shop") ->insert($data);
        if($res){
            exit(ajaxReturn([],1,"提交成功"));
        }else{
            exit(ajaxReturn([],0,"提交失败"));
        }
    }

    //店铺列表
    public function bindShopList(){
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where(["id"=>$user_id]) ->field("ue_account,id,qq_no,create_at") ->find();
        $member["create_at"] = date("Y-m-d H:i:s",$member["create_at"]);
        $list = Db::name("bind_shop") ->where(["user_id"=>$user_id]) ->field("id,platform_type,wangwang_id,shop_name,shop_url,address,status,take_interval") ->select();
        // if(empty($list)){
        //     exit(ajaxReturn([],0,"暂无数据"));
        // }
        exit(ajaxReturn(compact('member','list'),1,"获取成功"));
    }

    //修改店铺
    public function editShop(){
        $id = input("id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $user_id = $this ->user["id"];
        $res = Db::name("bind_shop") ->where(["id"=>$id,"user_id"=>$user_id]) ->field("id,platform_type,shop_name,shop_url,wangwang_id,address,detailed_address,phone") ->find();
        if(empty($res)){
            exit(ajaxReturn([],0,"暂无数据"));
        }
        exit(ajaxReturn($res,1,"获取成功"));
    }

    //执行
    public function doEditShop(){
        $data = input("post.");
        if(!isset($data["id"])|| !is_numeric($data["id"])){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $validate = new ShopVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $user_id = $this ->user["id"];
        $data["status"] = 0;
        unset($data["access_token"]);
        $res = Db::name("bind_shop") ->where(["id"=>$data["id"],"user_id"=>$user_id]) ->update($data);
        if($res !== false){
            exit(ajaxReturn([],1,"修改成功"));
        }else{
            exit(ajaxReturn([],0,"修改失败"));
        }
    }

    //修改间隔
    public function editInterval(){
        $id = input('id');
        $take_interval = input('take_interval');
        if(!is_numeric($id) || !is_numeric($take_interval)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $conf = ConfigModel::getConf("base");
        if($conf["min_take_interval"] > $take_interval || $conf["max_take_interval"] < $take_interval){
            exit(ajaxReturn([],0,"超出范围"));
        }
        $user_id = $this ->user["id"];
        $res = Db::name("bind_shop") ->where(["id"=>$id,"user_id"=>$user_id]) ->update(["take_interval"=>$take_interval]);
        if($res !== false){
            exit(ajaxReturn([],1,"修改成功"));
        }else{
            exit(ajaxReturn([],1,"修改失败"));
        }
    }
}