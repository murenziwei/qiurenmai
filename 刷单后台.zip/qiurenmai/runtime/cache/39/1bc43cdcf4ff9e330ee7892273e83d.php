<?php
//000000604800
 exit();?>
{"user":{"id":1,"uid":"","ue_account":"tst","cash_pledge":"0.00","ue_phone":"tst","qq_no":"","email":"","type":null,"create_at":"","last_login_at":"","bank_card":"","status":0},"access_token":"745d3c295b60a2e0a19dd91b9a9e2145","expire_in":604800,"refresh_token":"c70814da8fdca16490a0520fc8c0a9f0","timestamp":1559700700,"scope":""}