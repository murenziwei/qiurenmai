<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-06-25 14:09:53
 */
namespace app\api\controller;

use think\Db;
use think\Controller;

class Emptypack extends Controller
{
    public $appKey="chengqing";//appKey 请向业务员索取
    public $appSecret="xixihaha123";//Secret  请向业务员索取
    public $serverUrl="http://www.szjub.cn/OrderSubmit/index.asp";
    public $connectTimeout=180000;
    public $readTimeout=180000;

    public function main($data){

        $OrderNo = rand(1111,9999).time().rand(1111,9999);

      // "UserId":"8989",
      // "CellPhone":null,
        $array = [
              "logiType"=>"buykongbao",
              "orders"=>'{"Platform":"圆通",
              "SendContact":'.$data["order"]["shop_name"].',
              "SendOfficePhone":'.$data["order"]["post_phone"].',
              "SendCellPhone":'.$data["order"]["post_phone"].',

              "SendState":'.$data["order"]["ue_addr"][0].',
              "SendCity":'.$data["order"]["post_addr"][1].',
              "SendDistrict":'.$data["order"]["post_addr"][1].',
              "SendAddress":'.$data["order"]["post_addr"][2].$data["order"]["ue_street"].',
              "ProductTitle":'.$data["empty_parcel"]["goods_name"].',
              "Weight":'.$data["empty_parcel"]["parcel_weight"].',
              "Raddress":[{"OrderNo":'.$OrderNo.',
              "Contact":'.$data["order"]["ue_name"].',
              "OfficePhone":'.$data["order"]["ue_phone"].',
              "CellPhone":'.$data["order"]["ue_phone"].',
              "State":'.$data["order"]["ue_addr"][0].',
              "City":'.$data["order"]["ue_addr"][1].',
              "District":'.$data["order"]["ue_addr"][2].',
              "Address":'.$data["order"]["ue_street"].'}]}',
              "appKey"=>$this ->appKey,
              "timestamp"=>date("Y-m-d H:i:s",time())
            ];
        $sign = $this ->generateSign($array);
        $array["sign"] = $sign;
        //dump($array);
        return $this ->curl($this ->serverUrl,$array);
    }

    //curl
    public function curl($url, $postFields = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FAILONERROR, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($this->readTimeout) {
            curl_setopt($ch, CURLOPT_TIMEOUT, $this->readTimeout);
        }
        if ($this->connectTimeout) {
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->connectTimeout);
        }
        curl_setopt ( $ch, CURLOPT_USERAGENT, "djy-sdk-php-v20160501" );
        //https 请求
        if(strlen($url) > 5 && strtolower(substr($url,0,5)) == "https" ) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        if (is_array($postFields) && 0 < count($postFields))
        {
            $postBodyString = "";
            $postMultipart = false;
            foreach ($postFields as $k => $v)
            {
                if(!is_string($v))
                    continue ;
                $postBodyString .= "$k=" . urlencode($v) . "&";
            }
            // echo "<br/>";
            // echo "===============post的字符串==================";
            // echo "<br/>";
            // echo $postBodyString;
            unset($k, $v);
            curl_setopt($ch, CURLOPT_POST, true);

            $header = array("content-type: application/x-www-form-urlencoded; charset=UTF-8");
            curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
            curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString,0,-1));

        }
        $reponse = curl_exec($ch);

        if (curl_errno($ch))
        {
            throw new Exception(curl_error($ch),0);
        }
        else
        {
            $httpStatusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (200 !== $httpStatusCode)
            {
                throw new Exception($reponse,$httpStatusCode);
            }
        }
        curl_close($ch);
        return $reponse;
    }


    public function signature( $inputArr ) {
        ksort( $inputArr );
        $new_arr = [];
        foreach($inputArr as $key => $val) {
            $val = htmlspecialchars_decode($val);
            if(is_array($val)) {
            $val = json_encode($val, JSON_UNESCAPED_UNICODE);
            }
            $new_arr[] = "$key=$val";
        }
        $signature_str = implode('&' , $new_arr);
        return $signature_str;
    }

    protected function generateSign($params)
    {

        ksort($params);

        $stringToBeSigned = substr(md5($this->appSecret),8,16);  // 16位MD5加密;
        foreach ($params as $k => $v)
        {

            if(is_string($v) && "@" != substr($v, 0, 1) and $v<>"")
            {
                $stringToBeSigned .= "$k$v";
            }
        }
        unset($k, $v);
        $stringToBeSigned .= substr(md5($this->appSecret),8,16);

        // echo "===============加密的字符串==================";
        // echo "<br/>";
        // echo $stringToBeSigned;

        $sign= strtoupper(md5($stringToBeSigned));
        // if($this->isDebug){
        //     echo "query==>" .$stringToBeSigned."<br/>";
        //     echo "sign==>" .$sign."<br/>";
        // }

        return $sign;
    }
}