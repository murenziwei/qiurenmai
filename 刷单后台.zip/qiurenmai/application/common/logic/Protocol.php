<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/16
 * Time: 9:15
 */

namespace app\common\logic;
use app\common\BaseModel;
use app\common\entity\Protocol as protocolEntity;
use app\common\model\Protocol as protocolModel;

class Protocol extends BaseModel
{
    protected $protocolEntity;

    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->protocolEntity = new protocolEntity();
    }

    public function getProtocolByType(){
        $type = !array_key_exists('type',$this->requestData)?1:$this->requestData['type'];
        $this->protocolEntity->setType($type);
        $map = $this->protocolEntity->params();
        $data = protocolModel::findOne($map);
        if(empty($data)){
            return $this->failReturn('没有数据');
        }
        $content = htmlspecialchars_decode($data['content']);
        preg_match_all_img($content);
        $data['content'] = $content;
        return $this->successReturn('获取数据成功',$data);
    }
}