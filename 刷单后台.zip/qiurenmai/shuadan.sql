/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : shuadan

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-06-24 10:31:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ot_recharge
-- ----------------------------
DROP TABLE IF EXISTS `ot_recharge`;
CREATE TABLE `ot_recharge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `num` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '充值数量',
  `actual_num` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '实际得到的数量',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态(0无效，1有效）',
  `created_at` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `from` tinyint(2) DEFAULT '1' COMMENT '来源（1QDC，2PDC）',
  `is_admin` tinyint(2) DEFAULT '0' COMMENT '是否后台充值(0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户充值记录表';

-- ----------------------------
-- Records of ot_recharge
-- ----------------------------

-- ----------------------------
-- Table structure for sd_auth
-- ----------------------------
DROP TABLE IF EXISTS `sd_auth`;
CREATE TABLE `sd_auth` (
  `auth_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限表',
  `auth_name` varchar(255) DEFAULT NULL,
  `rules` varchar(255) DEFAULT NULL,
  `params` varchar(255) DEFAULT '[]' COMMENT '参数',
  `pid` int(11) DEFAULT NULL COMMENT '父ID',
  `is_delete` tinyint(1) DEFAULT '0' COMMENT '是否删除',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型（1表示总后台2分后台）',
  PRIMARY KEY (`auth_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sd_auth
-- ----------------------------
INSERT INTO `sd_auth` VALUES ('1', '权限管理', null, '[]', '0', '0', '1');
INSERT INTO `sd_auth` VALUES ('2', '管理员列表', 'user/index', '[]', '1', '0', '1');
INSERT INTO `sd_auth` VALUES ('3', '角色管理', 'role/index', '[]', '1', '0', '1');
INSERT INTO `sd_auth` VALUES ('10', '后台数据管理', null, '[]', '0', '0', '1');
INSERT INTO `sd_auth` VALUES ('11', '申诉管理', 'complain/index', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('6', '配置管理', null, '[]', '0', '0', '1');
INSERT INTO `sd_auth` VALUES ('7', '基本设置', 'config/index?type=1', '[]', '6', '0', '1');
INSERT INTO `sd_auth` VALUES ('12', '资金管理', null, '[]', '0', '0', '1');
INSERT INTO `sd_auth` VALUES ('20', '资金充值申请', 'Jin/topUpList', '[]', '12', '0', '1');
INSERT INTO `sd_auth` VALUES ('13', '资金提现申请', 'Jin/withdrawList', '[]', '12', '0', '1');
INSERT INTO `sd_auth` VALUES ('14', '商家管理', 'member/shopList', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('15', '买手管理', 'member/consumerList', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('16', '任务管理', 'Task/index', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('17', '审核管理', 'Member/check', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('18', '商家介绍管理', 'introduce/index', '[]', '10', '0', '1');
INSERT INTO `sd_auth` VALUES ('19', '扣费设置', 'config/index?type=2', '[]', '6', '0', '1');
INSERT INTO `sd_auth` VALUES ('21', '套餐管理', 'Member/packageList', '[]', '12', '0', '1');
INSERT INTO `sd_auth` VALUES ('22', '提现设置', 'config/index?type=3', '[]', '6', '0', '1');
INSERT INTO `sd_auth` VALUES ('23', '平台流水', 'Jin/platformFlow', '[]', '12', '0', '1');
INSERT INTO `sd_auth` VALUES ('24', '垫付区间设置', '', '[]', '0', '0', '1');
INSERT INTO `sd_auth` VALUES ('25', '淘宝手机精搜区间列表', 'Jin/sectionList?type=1', '[]', '24', '0', '1');
INSERT INTO `sd_auth` VALUES ('26', '淘宝淘口令区间列表', 'Jin/sectionList?type=2', '[]', '24', '0', '1');
INSERT INTO `sd_auth` VALUES ('27', '淘宝预售区间列表', 'Jin/sectionList?type=3', '[]', '24', '0', '1');
INSERT INTO `sd_auth` VALUES ('28', '拼多多区间列表', 'Jin/sectionList?type=4', '[]', '24', '0', '1');

-- ----------------------------
-- Table structure for sd_bind_bank_card
-- ----------------------------
DROP TABLE IF EXISTS `sd_bind_bank_card`;
CREATE TABLE `sd_bind_bank_card` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(15) DEFAULT '' COMMENT '姓名',
  `bank` varchar(15) DEFAULT '' COMMENT '银行',
  `open_city` varchar(20) DEFAULT '' COMMENT '开户行城市',
  `open_branch_name` varchar(50) DEFAULT '' COMMENT '开户行支行名称',
  `phone` varchar(11) DEFAULT '' COMMENT '到账短信提醒手机号',
  `card_no` varchar(50) DEFAULT '' COMMENT '银行卡号',
  `user_id` int(10) DEFAULT '0' COMMENT '用户id',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='绑定银行卡表';

-- ----------------------------
-- Records of sd_bind_bank_card
-- ----------------------------
INSERT INTO `sd_bind_bank_card` VALUES ('1', 'wei', '中国银行', '广州', '魏', '18011834048', '465465465465465', '1', '1560938993');

-- ----------------------------
-- Table structure for sd_bind_buy_no
-- ----------------------------
DROP TABLE IF EXISTS `sd_bind_buy_no`;
CREATE TABLE `sd_bind_buy_no` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wang_id` varchar(25) DEFAULT '' COMMENT '旺旺id',
  `often_area` varchar(50) DEFAULT '' COMMENT '旺旺常用登录地',
  `ip_img` varchar(255) DEFAULT '' COMMENT ' IP所在地截图',
  `wang_img` varchar(255) DEFAULT '' COMMENT '旺旺个人档案截图',
  `name` varchar(25) DEFAULT '' COMMENT '收货人姓名',
  `province` varchar(10) DEFAULT '' COMMENT '省',
  `location` varchar(50) DEFAULT '' COMMENT '所在地区',
  `street` varchar(50) DEFAULT '' COMMENT '街道',
  `phone` varchar(11) DEFAULT '' COMMENT '手机号',
  `zhifu_name` varchar(10) DEFAULT '' COMMENT '支付宝认证姓名',
  `zhifu_img` varchar(255) DEFAULT '' COMMENT ' 支付宝实名认证截图',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（-1未通过0未审核1已审核）',
  `sex` tinyint(1) DEFAULT '1' COMMENT '性别（1男2女）',
  `platform_type` tinyint(1) DEFAULT '1' COMMENT '平台类型(1淘宝2天猫3拼多多)',
  `user_id` int(10) DEFAULT '0' COMMENT '用户id',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除(0否1是)',
  `is_level` tinyint(1) DEFAULT '0' COMMENT '是否已达到钻级别（0否1是）',
  `is_down_root` tinyint(1) DEFAULT '0' COMMENT '是否降权(0否1是)',
  PRIMARY KEY (`id`),
  KEY `wang_id` (`wang_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='绑定买号表';

-- ----------------------------
-- Records of sd_bind_buy_no
-- ----------------------------
INSERT INTO `sd_bind_buy_no` VALUES ('1', '旺旺', '广州', 'http://pic31.nipic.com/20130705/9527735_231540074000_2.jpg', 'http://pic31.nipic.com/20130705/9527735_231540074000_2.jpg', 'wei', '广州', '广州', '嘉禾望岗', '110', 'wei', 'http://pic31.nipic.com/20130705/9527735_231540074000_2.jpg', '213123123', '1', '1', '1', '5', '0', '1', '0');
INSERT INTO `sd_bind_buy_no` VALUES ('2', 'www', '广东-汕头-潮阳', 'www', 'www', 'www', '广东', '广东-汕头-潮阳', '老街管道', '18011834048', 'wei', 'www', '1560925702', '1', '1', '1', '1', '0', '1', '0');

-- ----------------------------
-- Table structure for sd_bind_shop
-- ----------------------------
DROP TABLE IF EXISTS `sd_bind_shop`;
CREATE TABLE `sd_bind_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform_type` tinyint(1) DEFAULT '1' COMMENT '平台类型(1淘宝2天猫3拼多多)',
  `shop_name` varchar(50) DEFAULT '' COMMENT '店铺名',
  `shop_url` varchar(255) DEFAULT '' COMMENT '店铺首页网址',
  `wangwang_id` varchar(50) DEFAULT '' COMMENT '旺旺id',
  `address` varchar(50) DEFAULT '' COMMENT '发货地',
  `detailed_address` varchar(50) DEFAULT '' COMMENT '街道地址',
  `phone` varchar(11) DEFAULT '' COMMENT '发货电话',
  `user_id` int(10) DEFAULT '0' COMMENT '商家id',
  `status` tinyint(1) DEFAULT '0' COMMENT '审核状态（0未审核1通过-1未通过）',
  `take_interval` int(1) DEFAULT '33' COMMENT '接单间隔',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除（0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='绑定商铺表';

-- ----------------------------
-- Records of sd_bind_shop
-- ----------------------------
INSERT INTO `sd_bind_shop` VALUES ('1', '1', '笔记本', 'http://baidu.com', '111', '广东省', '嘉禾望岗', '18011834048', '1', '1', '33', '0');
INSERT INTO `sd_bind_shop` VALUES ('2', '1', 'www', 'www', 'www', 'www', 'www', '18011834048', '1', '0', '33', '0');

-- ----------------------------
-- Table structure for sd_blacklist
-- ----------------------------
DROP TABLE IF EXISTS `sd_blacklist`;
CREATE TABLE `sd_blacklist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0' COMMENT '拉黑者',
  `block_id` int(10) DEFAULT '0' COMMENT '被拉黑的id',
  `create_at` varchar(10) DEFAULT '' COMMENT '拉黑时间',
  `reason` varchar(255) DEFAULT '' COMMENT '拉黑原因',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否取消（0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='黑名单表';

-- ----------------------------
-- Records of sd_blacklist
-- ----------------------------
INSERT INTO `sd_blacklist` VALUES ('7', '1', '5', '1560913605', 'wrasfdsf', '1');
INSERT INTO `sd_blacklist` VALUES ('3', '0', '5', '1559186491', '', '0');
INSERT INTO `sd_blacklist` VALUES ('4', '0', '5', '1559187124', '', '0');
INSERT INTO `sd_blacklist` VALUES ('5', '0', '5', '1559187137', '', '0');

-- ----------------------------
-- Table structure for sd_browse_calendar
-- ----------------------------
DROP TABLE IF EXISTS `sd_browse_calendar`;
CREATE TABLE `sd_browse_calendar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) DEFAULT NULL COMMENT '任务id',
  `start_day` varchar(10) DEFAULT '' COMMENT '开始日期',
  `calendar` varchar(255) DEFAULT '' COMMENT '日程表',
  `search_word` varchar(50) DEFAULT '' COMMENT '搜索关键词',
  `task_num` int(10) DEFAULT '0' COMMENT '单数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COMMENT='浏览日程表';

-- ----------------------------
-- Records of sd_browse_calendar
-- ----------------------------
INSERT INTO `sd_browse_calendar` VALUES ('13', '37', '1560849999', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('14', '37', '1560936399', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('15', '37', '1560844684', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('16', '37', '1560931084', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('17', '44', '1560849999', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('18', '44', '1560936399', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('19', '44', '1560844684', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('20', '44', '1560931084', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('21', '45', '1560849999', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('22', '45', '1560936399', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('23', '45', '1560844684', '{\"1\":2,\"23\":1}', '搜索词', '3');
INSERT INTO `sd_browse_calendar` VALUES ('24', '45', '1560931084', '{\"1\":2,\"23\":1}', '搜索词', '3');

-- ----------------------------
-- Table structure for sd_complain
-- ----------------------------
DROP TABLE IF EXISTS `sd_complain`;
CREATE TABLE `sd_complain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `son_task_id` int(10) DEFAULT NULL COMMENT '订单编号',
  `type` tinyint(1) DEFAULT '1' COMMENT '投诉类型（1买手未按要求操作2买手退款3买手给差评4金额有误5其他）',
  `note` varchar(255) DEFAULT '' COMMENT '投诉说明',
  `img1` varchar(50) DEFAULT '' COMMENT '图1',
  `img2` varchar(50) DEFAULT '' COMMENT '图2',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `status` tinyint(1) unsigned zerofill DEFAULT '0' COMMENT '状态（0待查看1已处理）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='投诉表';

-- ----------------------------
-- Records of sd_complain
-- ----------------------------
INSERT INTO `sd_complain` VALUES ('1', '51', '1', 'asdsadasd', '', '', 'asdas', '1');
INSERT INTO `sd_complain` VALUES ('2', '51', '3', 'www', 'www', 'www', '1560931086', '0');

-- ----------------------------
-- Table structure for sd_config
-- ----------------------------
DROP TABLE IF EXISTS `sd_config`;
CREATE TABLE `sd_config` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(50) DEFAULT NULL,
  `value` varchar(20) DEFAULT NULL,
  `inc_type` varchar(20) DEFAULT NULL,
  `desc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inc_type` (`inc_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sd_config
-- ----------------------------
INSERT INTO `sd_config` VALUES ('30', 'withdraw_ratio', '0.1', 'withdraw', '本金提现手续比例（%）');
INSERT INTO `sd_config` VALUES ('31', 'shop_task_confirm_day', '2', 'base', '商家自动任务确定天数（天）');
INSERT INTO `sd_config` VALUES ('32', 'common_comment', '0', 'jin', '普通评论扣费');
INSERT INTO `sd_config` VALUES ('33', 'word_comment', '2', 'jin', '文字评论扣费/单');
INSERT INTO `sd_config` VALUES ('34', 'img_comment', '3', 'jin', '图片评论扣费/单');
INSERT INTO `sd_config` VALUES ('35', 'video_comment', '4', 'jin', '视频评论扣费/单');
INSERT INTO `sd_config` VALUES ('36', 'not_post', '10', 'jin', '不包邮扣费/单');
INSERT INTO `sd_config` VALUES ('37', 'empty_post', '3.5', 'jin', '空包服务扣费/单');
INSERT INTO `sd_config` VALUES ('38', 'task_top', '5', 'jin', '任务置顶扣费/单');
INSERT INTO `sd_config` VALUES ('39', 'restrict_area', '2', 'jin', '限制地区扣费/单');
INSERT INTO `sd_config` VALUES ('40', 'restrict_sex', '1', 'jin', '限制性别扣费/单');
INSERT INTO `sd_config` VALUES ('41', 'restrict_level', '2', 'jin', '限制钻级别扣费/单');
INSERT INTO `sd_config` VALUES ('42', 'deduct_add', '50', 'jin', '加赏扣费（%）/单');
INSERT INTO `sd_config` VALUES ('43', 'send_fee', '1', 'jin', '平台发布费/次');
INSERT INTO `sd_config` VALUES ('44', 'is_favorites', '0.8', 'jin', '收藏商品');
INSERT INTO `sd_config` VALUES ('45', 'is_shopping_trolley', '0.8', 'jin', '加入购物车');
INSERT INTO `sd_config` VALUES ('46', 'browse_task_fee', '0.8', 'jin', '浏览任务花费/单');
INSERT INTO `sd_config` VALUES ('47', 'min_take_interval', '15', 'base', '最小接单间隔');
INSERT INTO `sd_config` VALUES ('48', 'max_take_interval', '45', 'base', '最大接单间隔');
INSERT INTO `sd_config` VALUES ('49', 'default_take_interval', '33', 'base', '默认接单间隔');
INSERT INTO `sd_config` VALUES ('50', 'shop_upper_limit', '10', 'base', '每个平台店铺绑定上限');
INSERT INTO `sd_config` VALUES ('51', 'cancel_fee', '1', 'jin', '刷手自己取消任务扣费');
INSERT INTO `sd_config` VALUES ('52', 'withdraw_line', '10', 'withdraw', '本金提现底线');
INSERT INTO `sd_config` VALUES ('53', 'tao_task_count', '4', 'buy', '淘宝账号一星期接单数');
INSERT INTO `sd_config` VALUES ('54', 'pin_task_count', '5', 'buy', '拼多多账号一星期接单数');
INSERT INTO `sd_config` VALUES ('55', 'take_deposit', '1', 'buy', '买手接手任务扣费/完成返还');
INSERT INTO `sd_config` VALUES ('56', 'buy_upper_limit', '3', 'base', '每个平台绑定买手号上限');
INSERT INTO `sd_config` VALUES ('57', 'commission_line', '100', 'withdraw', '佣金提现底线');
INSERT INTO `sd_config` VALUES ('58', 'commission_ratio', '10', 'withdraw', '佣金提现手续比例（%）');
INSERT INTO `sd_config` VALUES ('60', 'com_discount', '20', 'jin', '佣金扣除（%）');

-- ----------------------------
-- Table structure for sd_empty_parcel_serve
-- ----------------------------
DROP TABLE IF EXISTS `sd_empty_parcel_serve`;
CREATE TABLE `sd_empty_parcel_serve` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `serve_fee` decimal(8,2) DEFAULT '0.00' COMMENT '服务费用',
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `parcel_weight` decimal(8,2) DEFAULT NULL COMMENT '包裹重量',
  `post_type` varchar(20) DEFAULT NULL COMMENT '快递类型',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `goods_name` varchar(50) DEFAULT '' COMMENT '商品名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='空包服务表';

-- ----------------------------
-- Records of sd_empty_parcel_serve
-- ----------------------------
INSERT INTO `sd_empty_parcel_serve` VALUES ('26', '3.50', '43', '0.20', '1', '1560827400', '');
INSERT INTO `sd_empty_parcel_serve` VALUES ('27', '3.50', '46', '0.20', '1', '1561080583', '');
INSERT INTO `sd_empty_parcel_serve` VALUES ('28', '3.50', '48', '0.20', '1', '1561083429', '');
INSERT INTO `sd_empty_parcel_serve` VALUES ('29', '3.50', '44', '0.20', '1', '1561098769', '商品名称');
INSERT INTO `sd_empty_parcel_serve` VALUES ('30', '3.50', '50', '0.20', '1', '1561098798', '商品名称');
INSERT INTO `sd_empty_parcel_serve` VALUES ('31', '3.50', '51', '0.20', '1', '1561341167', '商品名称');

-- ----------------------------
-- Table structure for sd_fee_info
-- ----------------------------
DROP TABLE IF EXISTS `sd_fee_info`;
CREATE TABLE `sd_fee_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `thousand_fee` decimal(8,2) DEFAULT '0.00' COMMENT '千人千面',
  `platform_fee` decimal(8,2) DEFAULT '0.00' COMMENT '平台返款服务费',
  `empty_parcel_fee` decimal(8,2) DEFAULT '0.00' COMMENT '空包费',
  `favorites_fee` decimal(8,2) DEFAULT '0.00' COMMENT '用户收藏加购',
  `top_fee` decimal(8,2) DEFAULT '0.00' COMMENT '置顶费',
  `add_fee` decimal(8,2) DEFAULT '0.00' COMMENT '加赏任务佣金',
  `comment_fee` decimal(8,2) DEFAULT '0.00' COMMENT '评论需求费用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='费用详情表';

-- ----------------------------
-- Records of sd_fee_info
-- ----------------------------
INSERT INTO `sd_fee_info` VALUES ('1', '20', '5.00', '1.00', '3.50', '0.00', '0.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('2', '21', '5.00', '1.00', '3.50', '0.00', '5.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('3', '22', '5.00', '1.00', '3.50', '0.00', '0.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('4', '23', '5.00', '1.00', '3.50', '0.00', '0.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('5', '24', '5.00', '1.00', '3.50', '0.00', '5.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('6', '25', '5.00', '1.00', '3.50', '0.00', '5.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('7', '26', '5.00', '1.00', '3.50', '0.00', '5.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('8', '27', '5.00', '1.00', '3.50', '0.00', '5.00', '0.50', '0.00');
INSERT INTO `sd_fee_info` VALUES ('9', '28', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('10', '29', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('11', '30', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('12', '31', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('13', '32', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('14', '33', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('15', '34', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('16', '35', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('17', '36', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('18', '37', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('19', '39', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('20', '40', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('21', '41', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('22', '42', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('23', '43', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('24', '44', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('25', '45', '0.00', '1.00', '0.00', '1.60', '0.00', '0.00', '0.00');
INSERT INTO `sd_fee_info` VALUES ('26', '46', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '11.00');
INSERT INTO `sd_fee_info` VALUES ('27', '48', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '11.00');
INSERT INTO `sd_fee_info` VALUES ('28', '49', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '11.00');
INSERT INTO `sd_fee_info` VALUES ('29', '50', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '11.00');
INSERT INTO `sd_fee_info` VALUES ('30', '51', '5.00', '1.00', '3.50', '0.00', '0.00', '1.00', '11.00');

-- ----------------------------
-- Table structure for sd_freeze
-- ----------------------------
DROP TABLE IF EXISTS `sd_freeze`;
CREATE TABLE `sd_freeze` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0' COMMENT '用户id',
  `note` varchar(255) DEFAULT '' COMMENT '冻结备注',
  `freeze_date` varchar(10) DEFAULT '0' COMMENT '冻结到期时间',
  `freeze_day` varchar(10) DEFAULT '' COMMENT '冻结天数',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='冻结表';

-- ----------------------------
-- Records of sd_freeze
-- ----------------------------
INSERT INTO `sd_freeze` VALUES ('4', '5', '', '1560500397', '3天', '1560241197');
INSERT INTO `sd_freeze` VALUES ('5', '5', '', '1560500414', '3天', '1560241214');
INSERT INTO `sd_freeze` VALUES ('6', '5', '', '1560500422', '3天', '1560241222');

-- ----------------------------
-- Table structure for sd_freeze_jin
-- ----------------------------
DROP TABLE IF EXISTS `sd_freeze_jin`;
CREATE TABLE `sd_freeze_jin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `son_task_id` int(10) DEFAULT '0' COMMENT '子任务id',
  `freeze_cash_pledge` decimal(8,2) DEFAULT '0.00' COMMENT '冻结本金',
  `freeze_commission` decimal(8,2) DEFAULT '0.00' COMMENT '冻结佣金',
  `user_id` int(10) DEFAULT NULL,
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `is_withdraw` tinyint(1) DEFAULT '0' COMMENT '是否已提现（0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='冻结金额表';

-- ----------------------------
-- Records of sd_freeze_jin
-- ----------------------------
INSERT INTO `sd_freeze_jin` VALUES ('1', '13', '0.00', '0.00', '1', '1560839564', '0');
INSERT INTO `sd_freeze_jin` VALUES ('2', '13', '0.00', '0.00', '1', '1560839646', '0');
INSERT INTO `sd_freeze_jin` VALUES ('3', '13', '5.00', '0.00', '1', '1560840185', '0');

-- ----------------------------
-- Table structure for sd_introduce
-- ----------------------------
DROP TABLE IF EXISTS `sd_introduce`;
CREATE TABLE `sd_introduce` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `note` text COMMENT '文案',
  `update_at` varchar(10) DEFAULT '' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='介绍文案';

-- ----------------------------
-- Records of sd_introduce
-- ----------------------------
INSERT INTO `sd_introduce` VALUES ('1', '<p><img src=\"/ueditor/php/upload/image/20190613/1560412781.jpg\" title=\"1560412781.jpg\" alt=\"_CBK63AEZ2U[ZB6$~4DA}JN.jpg\"/>大撒撒的</p>', '1560412787');

-- ----------------------------
-- Table structure for sd_member
-- ----------------------------
DROP TABLE IF EXISTS `sd_member`;
CREATE TABLE `sd_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `invite_code` varchar(8) DEFAULT '' COMMENT '邀请码',
  `ue_account` varchar(20) DEFAULT '' COMMENT '账号（手机号）',
  `ue_jin` decimal(8,2) DEFAULT '0.00' COMMENT '虚拟币',
  `ue_password` varchar(50) DEFAULT '' COMMENT '登录密码',
  `qq_no` varchar(20) DEFAULT '' COMMENT 'QQ号',
  `type` tinyint(1) DEFAULT '1' COMMENT '身份类型(1商家2刷手)',
  `create_at` varchar(10) DEFAULT '' COMMENT '注册时间',
  `access_token` varchar(50) DEFAULT '' COMMENT '令牌',
  `login_at` varchar(50) DEFAULT '' COMMENT '登录时间',
  `pid` int(10) DEFAULT '0' COMMENT '上级id',
  `vip` varchar(10) DEFAULT '' COMMENT 'vip到期时间',
  `commission` decimal(8,2) DEFAULT '0.00' COMMENT '佣金',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sd_member
-- ----------------------------
INSERT INTO `sd_member` VALUES ('1', 'QV8L735R', 'tst', '5643.50', '30e7ca3ed4f3063a1ffa6d780b292ed1', '', '2', '', '8c5a9938ea93f5dedeec110eab845f57', '1561946729', '0', '', '12.00');
INSERT INTO `sd_member` VALUES ('5', 'L4M08JJV', '15811111112', '81.94', '72a0d68fd82688692bfecea349883627', '1783486028', '2', '', '', '', '1', '', '0.00');
INSERT INTO `sd_member` VALUES ('6', 'VHM739V4', '15811111113', '0.00', '72a0d68fd82688692bfecea349883627', '1783486028', '1', '', '', '', '1', '', '0.00');

-- ----------------------------
-- Table structure for sd_order
-- ----------------------------
DROP TABLE IF EXISTS `sd_order`;
CREATE TABLE `sd_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` varchar(25) DEFAULT '0' COMMENT '店铺旺旺id',
  `buy_id` varchar(25) DEFAULT '0' COMMENT '买手旺旺id',
  `goods_id` int(10) DEFAULT '0' COMMENT '商品id',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `tao_order_no` varchar(50) DEFAULT '' COMMENT '淘宝订单号',
  `post_no` varchar(50) DEFAULT '' COMMENT '快递号',
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `user_id` int(10) DEFAULT '0' COMMENT '商家ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='订单表';

-- ----------------------------
-- Records of sd_order
-- ----------------------------
INSERT INTO `sd_order` VALUES ('1', '111', '旺旺', '27', '412752452', '', '', '12', '1');
INSERT INTO `sd_order` VALUES ('2', '111', 'www', '28', '1560934777', '', '', '51', '1');
INSERT INTO `sd_order` VALUES ('3', '111', 'www', '28', '1561115362', '', '', '55', '1');

-- ----------------------------
-- Table structure for sd_package
-- ----------------------------
DROP TABLE IF EXISTS `sd_package`;
CREATE TABLE `sd_package` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `month` tinyint(10) DEFAULT '0' COMMENT '月',
  `price` decimal(15,2) DEFAULT '0.00' COMMENT '价格',
  `discount` varchar(10) DEFAULT '' COMMENT '折扣备注',
  `sort` int(10) DEFAULT '0',
  `created_at` int(10) DEFAULT '0',
  `is_del` tinyint(2) DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COMMENT='套餐表';

-- ----------------------------
-- Records of sd_package
-- ----------------------------
INSERT INTO `sd_package` VALUES ('5', '1', '30.00', '  ', '0', '1559112792', '1');
INSERT INTO `sd_package` VALUES ('6', '2', '60.00', '8折', '5', '1559119758', '0');
INSERT INTO `sd_package` VALUES ('7', '2', '66.00', '3折', '44', '1559121582', '0');
INSERT INTO `sd_package` VALUES ('8', '4', '555.00', '撒旦撒', '0', '1560423178', '1');

-- ----------------------------
-- Table structure for sd_platform_flow
-- ----------------------------
DROP TABLE IF EXISTS `sd_platform_flow`;
CREATE TABLE `sd_platform_flow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `jin` decimal(8,2) DEFAULT '0.00' COMMENT '金额',
  `jin_type` tinyint(1) DEFAULT '1' COMMENT '金额类型（1本金2佣金）',
  `algorithm` tinyint(1) DEFAULT '1' COMMENT '加减类型（1加2减）',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `flow_type` tinyint(1) DEFAULT '1' COMMENT '流水类别(1任务收入2佣金收入3提现收入4佣金转本金收入5购买会员6买手放弃任务7新买手赠送8任务置顶服务)',
  `user_id` int(10) DEFAULT '0' COMMENT '用户ID',
  `task_id` int(10) DEFAULT '0' COMMENT '任务ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='平台流水表';

-- ----------------------------
-- Records of sd_platform_flow
-- ----------------------------
INSERT INTO `sd_platform_flow` VALUES ('3', '1.60', '1', '1', '1561184525', '1', '1', '56');

-- ----------------------------
-- Table structure for sd_role
-- ----------------------------
DROP TABLE IF EXISTS `sd_role`;
CREATE TABLE `sd_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色表',
  `role_name` varchar(255) NOT NULL,
  `auth_id_list` varchar(255) NOT NULL COMMENT '权限集',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型（1表示总后台，2表示分后台）',
  `remake` varchar(150) DEFAULT '' COMMENT '备注',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- ----------------------------
-- Records of sd_role
-- ----------------------------
INSERT INTO `sd_role` VALUES ('1', '超级管理员', '*', '1', '', '1');

-- ----------------------------
-- Table structure for sd_son_task
-- ----------------------------
DROP TABLE IF EXISTS `sd_son_task`;
CREATE TABLE `sd_son_task` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `goods_info_id` int(10) DEFAULT '0' COMMENT '商品信息id',
  `user_id` int(10) DEFAULT '0' COMMENT '接收人的id',
  `create_at` varchar(10) DEFAULT '' COMMENT '发出时间',
  `shop_id` int(10) DEFAULT '0' COMMENT '商家id',
  `comment_info_id` int(10) DEFAULT '0' COMMENT '任务评论信息id',
  `accept_at` varchar(10) DEFAULT '' COMMENT '接受时间',
  `finish_at` varchar(10) DEFAULT '' COMMENT '完成时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（-4超时已放弃-3已放弃-2已撤销-1已取消0未放出1未接单2待操作3待返款发货4待评价5待确认6已完成）',
  `receiver_address` varchar(50) DEFAULT '' COMMENT '收货地址',
  `is_top` tinyint(1) DEFAULT '0' COMMENT '是否置顶（0否1是）',
  `start_at` varchar(10) DEFAULT '' COMMENT '放出时间',
  `is_wait_sale` tinyint(1) DEFAULT '0' COMMENT '是否等待预售（0否1是）',
  `browse_calendar_id` int(10) DEFAULT '0' COMMENT '浏览日程id',
  `task_type` tinyint(1) DEFAULT '1' COMMENT '任务类型(1淘宝任务2淘口令任务3预售任务4拼多多任务5浏览任务)',
  `shop_wang_id` varchar(20) DEFAULT '' COMMENT '绑定店铺id',
  `commission` decimal(8,2) DEFAULT '0.00' COMMENT '佣金（每单）',
  `real_commission` decimal(8,2) DEFAULT '0.00' COMMENT '给买手佣金',
  `add_service_fee` decimal(8,2) DEFAULT '0.00' COMMENT '额外服务费',
  `cash_pledge` decimal(8,2) DEFAULT '0.00' COMMENT '本金',
  `wangwang_id` varchar(10) DEFAULT '' COMMENT '旺旺id',
  `real_pay` decimal(8,2) DEFAULT '0.00' COMMENT '实际付款金额',
  `recall_at` varchar(10) DEFAULT '' COMMENT '撤销时间',
  `refund_at` varchar(10) DEFAULT '' COMMENT '返款时间',
  `comment_at` varchar(10) DEFAULT '' COMMENT '评论时间',
  `post_at` varchar(10) DEFAULT '' COMMENT '发货时间',
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`) USING HASH,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8 COMMENT='子任务表';

-- ----------------------------
-- Records of sd_son_task
-- ----------------------------

-- ----------------------------
-- Table structure for sd_task
-- ----------------------------
DROP TABLE IF EXISTS `sd_task`;
CREATE TABLE `sd_task` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0' COMMENT '商家id',
  `task_num` int(10) DEFAULT '0' COMMENT '任务总数',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `is_top` tinyint(1) DEFAULT '0' COMMENT '是否置顶（0否1是）',
  `every_cash_pledge` decimal(8,2) DEFAULT '0.00' COMMENT '本金(每单)',
  `every_commission` decimal(8,2) DEFAULT '0.00' COMMENT '基本佣金(每单)',
  `restrict_area` varchar(255) DEFAULT NULL COMMENT '限制的区域',
  `restrict_sex` tinyint(1) DEFAULT '0' COMMENT '限制性别(0不限1男2女)',
  `restrict_level` tinyint(1) DEFAULT '0' COMMENT '仅限钻级别的买号（0否1是）',
  `explain` varchar(255) DEFAULT '' COMMENT '备注说明',
  `task_type` tinyint(1) DEFAULT '1' COMMENT '任务类型(1淘宝任务2淘口令任务3预售任务4拼多多任务5浏览任务)',
  `platform_type` tinyint(1) DEFAULT '1' COMMENT '平台类型(1淘宝2天猫3拼多多)',
  `sum_fee` decimal(8,2) DEFAULT '0.00' COMMENT '总花费',
  `is_create_son` tinyint(1) DEFAULT '0' COMMENT '是否生成过子任务（0否1是）',
  `is_pay` tinyint(1) DEFAULT '0' COMMENT '是否支付过（0否1是）',
  `wait_sell_at` varchar(10) DEFAULT '' COMMENT '待售时间',
  `is_favorites` tinyint(1) DEFAULT '0' COMMENT '是否收藏商品（0否1是）',
  `is_shopping_trolley` tinyint(1) DEFAULT '0' COMMENT '是否加购物车',
  `shop_wang_id` int(10) DEFAULT '0' COMMENT '绑定店铺旺旺id',
  `add_service_fee` decimal(8,2) DEFAULT '0.00' COMMENT '额外服务费(每单)',
  `is_recall` tinyint(1) DEFAULT '0' COMMENT '是否撤销（0否1是）',
  PRIMARY KEY (`id`),
  KEY `shop_wang_id` (`shop_wang_id`) USING HASH,
  KEY `user_id` (`user_id`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='任务表';

-- ----------------------------
-- Records of sd_task
-- ----------------------------
INSERT INTO `sd_task` VALUES ('51', '1', '6', '1561341167', '0', '40.00', '10.50', '广东,天津,上海', '1', '1', '备注说明', '1', '1', '366.00', '0', '0', '', '0', '0', '111', '8.50', '0');

-- ----------------------------
-- Table structure for sd_task_comment_info
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_comment_info`;
CREATE TABLE `sd_task_comment_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '评论类别（1普通好评2指定文字好评3指定图片好评4指定视频好评）',
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `video` varchar(50) DEFAULT '' COMMENT '视频',
  `imgs` varchar(100) DEFAULT '' COMMENT '多图',
  `comment_ask` varchar(255) DEFAULT '' COMMENT '评论要求',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `specification` varchar(10) DEFAULT '' COMMENT '规格，如颜色尺码',
  `search_word` varchar(100) DEFAULT '' COMMENT '搜索关键词/淘口令',
  `than_word` varchar(25) DEFAULT '' COMMENT '货比词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8 COMMENT='评论要求表';

-- ----------------------------
-- Records of sd_task_comment_info
-- ----------------------------
INSERT INTO `sd_task_comment_info` VALUES ('139', '1', '51', '', '', '', '1561341167', '', '搜索词', '货比词');
INSERT INTO `sd_task_comment_info` VALUES ('140', '1', '51', '', '', '', '1561341167', '', '搜索词', '货比词');
INSERT INTO `sd_task_comment_info` VALUES ('141', '2', '51', '', '', '说明', '1561341167', '', '搜索词', '货比词');
INSERT INTO `sd_task_comment_info` VALUES ('142', '2', '51', '', '', '说明', '1561341167', '', '搜索词', '货比词');
INSERT INTO `sd_task_comment_info` VALUES ('143', '3', '51', '', 'http://baidu.com', '说明', '1561341167', '大小', '搜索词', '货比词');
INSERT INTO `sd_task_comment_info` VALUES ('144', '4', '51', 'http://baidu.com', 'http://baidu.com', '说明', '1561341167', '大小', '搜索词', '货比词');

-- ----------------------------
-- Table structure for sd_task_commission_fee
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_commission_fee`;
CREATE TABLE `sd_task_commission_fee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_type` tinyint(1) DEFAULT '1' COMMENT '任务类别(1淘宝任务2淘口令任务3预售任务4拼多多任务)',
  `start_price` decimal(8,2) DEFAULT '0.00' COMMENT '开始价格',
  `end_price` decimal(8,2) DEFAULT '0.00' COMMENT '结束价格',
  `commission_fee` decimal(8,2) DEFAULT '0.00' COMMENT '花费佣金',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除（0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='垫付区间表';

-- ----------------------------
-- Records of sd_task_commission_fee
-- ----------------------------
INSERT INTO `sd_task_commission_fee` VALUES ('1', '1', '0.00', '50.00', '10.00', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('2', '1', '50.01', '150.00', '10.00', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('3', '1', '150.01', '250.00', '16.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('4', '2', '0.00', '50.00', '11.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('5', '2', '50.01', '150.00', '13.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('6', '2', '150.01', '250.00', '15.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('7', '2', '250.01', '450.00', '17.70', '1');
INSERT INTO `sd_task_commission_fee` VALUES ('8', '3', '0.00', '50.00', '11.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('9', '3', '50.01', '150.00', '13.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('10', '3', '150.01', '250.00', '15.70', '0');
INSERT INTO `sd_task_commission_fee` VALUES ('11', '3', '250.01', '450.00', '17.70', '1');
INSERT INTO `sd_task_commission_fee` VALUES ('12', '4', '0.02', '50.00', '11.00', '0');

-- ----------------------------
-- Table structure for sd_task_goods_info
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_goods_info`;
CREATE TABLE `sd_task_goods_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(50) DEFAULT '' COMMENT '商品名',
  `goods_link` varchar(50) DEFAULT '' COMMENT '商品链接',
  `goods_img` varchar(50) DEFAULT '' COMMENT '商品主图',
  `real_price` decimal(8,2) DEFAULT '0.00' COMMENT '实际成交价格',
  `goods_count` int(10) DEFAULT '0' COMMENT '每单拍',
  `show_price` decimal(8,2) DEFAULT '0.00' COMMENT '展示价格',
  `searh_start_price` decimal(8,2) DEFAULT '0.00' COMMENT '搜索起始价',
  `searh_end_price` decimal(8,2) DEFAULT '0.00' COMMENT '搜索结束价',
  `goods_location` varchar(10) DEFAULT '' COMMENT '商品所在地',
  `order_message` varchar(255) DEFAULT '' COMMENT '商品留言',
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  `sell_num` int(10) DEFAULT '0' COMMENT '卖出数量',
  `is_post` tinyint(1) DEFAULT '1' COMMENT '是否包邮（0否1是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COMMENT='任务商品表';

-- ----------------------------
-- Records of sd_task_goods_info
-- ----------------------------
INSERT INTO `sd_task_goods_info` VALUES ('34', '商品名称', '商品链接', '商品主图', '20.00', '2', '20.00', '0.00', '0.00', '全国', '', '51', '1561341167', '666', '1');

-- ----------------------------
-- Table structure for sd_task_goods_info_副本
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_goods_info_副本`;
CREATE TABLE `sd_task_goods_info_副本` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) DEFAULT NULL COMMENT '对应任务的id',
  `goods_name` varchar(20) DEFAULT '' COMMENT '商品名称',
  `goods_link` varchar(50) DEFAULT NULL COMMENT '商品链接',
  `goods_no` varchar(10) DEFAULT NULL COMMENT '商品数字',
  `color` varchar(10) DEFAULT '' COMMENT '颜色',
  `size` varchar(10) DEFAULT NULL COMMENT '尺码',
  `single_price` decimal(8,2) DEFAULT NULL COMMENT '单品售价',
  `num` int(11) DEFAULT NULL COMMENT '每单拍件数',
  `page_show_price` decimal(8,2) DEFAULT NULL COMMENT '搜索页面展示价格',
  `weight` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '包裹重量',
  `goods_img` varchar(50) DEFAULT '' COMMENT '商品主图',
  `keyword_source` varchar(255) DEFAULT NULL COMMENT '关键字来源',
  `searh_start_price` decimal(8,2) DEFAULT '0.00' COMMENT '搜索起始价',
  `searh_end_price` decimal(8,2) DEFAULT '0.00' COMMENT '搜索结束价',
  `goods_location` varchar(10) DEFAULT NULL COMMENT '商品所在地',
  `is_postage` tinyint(1) DEFAULT '1' COMMENT '是否包邮(0否1是)',
  `create_at` varchar(10) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='任务商品信息表';

-- ----------------------------
-- Records of sd_task_goods_info_副本
-- ----------------------------

-- ----------------------------
-- Table structure for sd_task_imgs
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_imgs`;
CREATE TABLE `sd_task_imgs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `search_img` varchar(50) DEFAULT '' COMMENT '搜索框截图',
  `order_img` varchar(50) DEFAULT '' COMMENT '订单截图',
  `follow_img` varchar(50) DEFAULT '' COMMENT '店铺关注截图',
  `record_img` varchar(50) DEFAULT '' COMMENT '足迹截图',
  `favorites_img` varchar(50) DEFAULT '' COMMENT '收藏夹截图',
  `shopping_trolley_img` varchar(50) DEFAULT '' COMMENT '购物车截图',
  `task_id` int(10) DEFAULT '0',
  `create_at` varchar(10) DEFAULT '' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='任务上传图表';

-- ----------------------------
-- Records of sd_task_imgs
-- ----------------------------
INSERT INTO `sd_task_imgs` VALUES ('1', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', '51', '1231232132');
INSERT INTO `sd_task_imgs` VALUES ('2', 'http://www.xxx.com', '', 'http://www.xxx.com', 'http://www.xxx.com', '', '', '51', '');
INSERT INTO `sd_task_imgs` VALUES ('3', 'http://www.xxx.com', '', 'http://www.xxx.com', 'http://www.xxx.com', '', '', '63', '');
INSERT INTO `sd_task_imgs` VALUES ('4', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', 'http://www.xxx.com', '', '63', '1561085303');

-- ----------------------------
-- Table structure for sd_task_send_plan
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_send_plan`;
CREATE TABLE `sd_task_send_plan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) DEFAULT '0' COMMENT '任务id',
  `start_at` varchar(10) DEFAULT '' COMMENT '开始时间',
  `time_interval` int(10) DEFAULT '0' COMMENT '发布任务时隔（分钟）',
  `task_num` int(10) DEFAULT '0' COMMENT '任务单数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='任务放出计划表';

-- ----------------------------
-- Records of sd_task_send_plan
-- ----------------------------
INSERT INTO `sd_task_send_plan` VALUES ('56', '51', '1560844684', '2', '3');
INSERT INTO `sd_task_send_plan` VALUES ('57', '51', '1560844111', '2', '3');

-- ----------------------------
-- Table structure for sd_task_副本
-- ----------------------------
DROP TABLE IF EXISTS `sd_task_副本`;
CREATE TABLE `sd_task_副本` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `platform` int(10) DEFAULT NULL COMMENT '平台',
  `shop` int(10) DEFAULT NULL COMMENT '店铺',
  `task_cost` decimal(8,2) DEFAULT '0.00' COMMENT '刷单费用',
  `task_type` tinyint(1) DEFAULT NULL COMMENT '任务类型（1文字好评2直通车3图文好评4问答任务）',
  `task_num` tinyint(4) DEFAULT NULL COMMENT '刷单数量',
  `order_hint` varchar(255) DEFAULT '' COMMENT '下单提示',
  `order_ps` varchar(255) DEFAULT NULL COMMENT '订单留言',
  `task_step` tinyint(1) DEFAULT '1' COMMENT '任务步骤',
  `pc_num` tinyint(4) DEFAULT '0' COMMENT '电脑端单数',
  `phone_num` tinyint(4) DEFAULT '0' COMMENT '手机单数',
  `add_task_cost` decimal(8,2) DEFAULT '0.00' COMMENT '加赏任务佣金',
  `is_good_likes` tinyint(1) DEFAULT '0' COMMENT '是否优质好评（0否1是）',
  `status` tinyint(1) DEFAULT '0' COMMENT '任务状态(0未发布1已发布)',
  `create_at` varchar(10) DEFAULT '' COMMENT '发布时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='任务表';

-- ----------------------------
-- Records of sd_task_副本
-- ----------------------------

-- ----------------------------
-- Table structure for sd_top_up
-- ----------------------------
DROP TABLE IF EXISTS `sd_top_up`;
CREATE TABLE `sd_top_up` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0' COMMENT '商家id',
  `money` decimal(8,2) DEFAULT '0.00' COMMENT '金额',
  `create_at` varchar(10) DEFAULT '' COMMENT '提交时间',
  `bank` varchar(15) DEFAULT '' COMMENT '银行',
  `card_name` varchar(15) DEFAULT '' COMMENT '转出银行卡姓名',
  `card_no` varchar(50) DEFAULT '' COMMENT '转出银行卡号',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='充值提交表';

-- ----------------------------
-- Records of sd_top_up
-- ----------------------------
INSERT INTO `sd_top_up` VALUES ('1', '1', '22.00', '1560938143', '农业银行', 'wei', '21312312321');

-- ----------------------------
-- Table structure for sd_user
-- ----------------------------
DROP TABLE IF EXISTS `sd_user`;
CREATE TABLE `sd_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员表',
  `username` varchar(255) NOT NULL COMMENT '账号',
  `password` char(32) NOT NULL COMMENT '密码',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `role_id` int(11) NOT NULL COMMENT '角色id',
  `created_at` int(10) NOT NULL DEFAULT '0' COMMENT '时间',
  `last_login` int(10) NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（0冻结1启用）',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sd_user
-- ----------------------------
INSERT INTO `sd_user` VALUES ('1', 'admin', '0ebaa80e24fb73edc51af9ca013e516f', '管理员', '1', '1530845318', '0', '1');

-- ----------------------------
-- Table structure for sd_user_minutiae
-- ----------------------------
DROP TABLE IF EXISTS `sd_user_minutiae`;
CREATE TABLE `sd_user_minutiae` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '类型（1支付任务2佣金转本金3自行取消任务扣费4任务退还5充值6退还邮费7商家撤销任务退回8提现9购买会员10买手接单）',
  `note` varchar(255) DEFAULT '' COMMENT '信息',
  `num` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT '数量',
  `created_at` int(10) DEFAULT NULL,
  `after_num` decimal(15,2) DEFAULT '0.00' COMMENT '结余',
  `from` tinyint(1) DEFAULT '1' COMMENT '资金类型（1本金2佣金）',
  `algorithm` tinyint(1) DEFAULT '1' COMMENT '加减类型（1加2减）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COMMENT='收支明细表';

-- ----------------------------
-- Records of sd_user_minutiae
-- ----------------------------
INSERT INTO `sd_user_minutiae` VALUES ('1', '5', '5', '人工充值', '6.66', '1560244054', '6.66', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('2', '5', '5', '人工充值', '6.66', '1560244072', '13.32', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('4', '5', '5', '人工充值', '6.66', '1560244246', '33.30', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('5', '5', '5', '人工充值', '6.66', '1560244275', '39.96', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('6', '5', '5', '人工充值', '6.66', '1560244285', '46.62', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('7', '5', '5', '人工充值', '6.66', '1560244339', '53.28', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('8', '5', '5', '人工充值', '6.66', '1560244406', '59.94', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('9', '5', '5', '人工充值', '22.00', '1560244471', '81.94', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('10', '1', '5', '人工充值', '2.88', '1560244771', '2.88', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('11', '1', '1', '支付任务,任务编号：39', '-196.20', '1560769553', '2.88', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('12', '1', '1', '支付任务,任务编号：39', '-196.20', '1560769720', '2.88', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('13', '1', '1', '支付任务,任务编号：39', '-196.20', '1560770051', '0.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('14', '1', '6', '退还邮费,任务编号：13', '10.00', '1560839646', '10.00', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('15', '1', '6', '退还邮费,任务编号：13', '5.00', '1560840185', '15.00', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('16', '1', '7', '撤销任务退回,任务编号：16', '30.00', '1560847248', '45.00', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('17', '1', '7', '撤销浏览任务退回10单,总任务编号：44', '24.00', '1560852376', '69.00', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('18', '1', '9', '购买会员1个月', '-30.00', '1560911308', '39.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('19', '1', '9', '购买会员1个月', '-30.00', '1560911396', '9.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('20', '1', '10', '接单扣除,任务ID:51', '-1.00', '1560934777', '7.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('21', '1', '8', '账户本金提现', '-10.00', '1560941627', '5535.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('22', '1', '8', '账户本金提现', '-10.00', '1560941687', '5525.00', '1', '2');
INSERT INTO `sd_user_minutiae` VALUES ('23', '1', '2', '佣金转本金', '-100.00', '1560942451', '0.00', '2', '1');
INSERT INTO `sd_user_minutiae` VALUES ('24', '1', '2', '来自佣金', '90.00', '1560942451', '5625.00', '1', '1');
INSERT INTO `sd_user_minutiae` VALUES ('25', '1', '5', '后台充值', '10.00', '1561114922', '10.00', '2', '1');
INSERT INTO `sd_user_minutiae` VALUES ('26', '1', '5', '后台充值', '1.00', '1561114961', '11.00', '2', '1');
INSERT INTO `sd_user_minutiae` VALUES ('27', '1', '10', '接单扣除佣金,任务ID:55', '-1.00', '1561115362', '10.00', '2', '2');
INSERT INTO `sd_user_minutiae` VALUES ('28', '1', '10', '任务完成返还,任务ID:56', '1.00', '1561184295', '11.00', '2', '1');
INSERT INTO `sd_user_minutiae` VALUES ('29', '1', '10', '任务完成返还,任务ID:56', '1.00', '1561184525', '12.00', '2', '1');
INSERT INTO `sd_user_minutiae` VALUES ('30', '1', '4', '任务取消退还,任务编号：63', '18.50', '1561186687', '5643.50', '1', '1');

-- ----------------------------
-- Table structure for sd_withdraw
-- ----------------------------
DROP TABLE IF EXISTS `sd_withdraw`;
CREATE TABLE `sd_withdraw` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT '0' COMMENT '商家id',
  `money` decimal(8,2) DEFAULT '0.00' COMMENT '金额',
  `create_at` varchar(10) DEFAULT '' COMMENT '提交时间',
  `bind_bank_id` int(10) DEFAULT '0' COMMENT '银行',
  `check_at` varchar(10) DEFAULT '' COMMENT '审核时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0申请已提交1已提现）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='提现提交表';

-- ----------------------------
-- Records of sd_withdraw
-- ----------------------------
INSERT INTO `sd_withdraw` VALUES ('1', '1', '12.00', '455343', '1', '1561103000', '1');
INSERT INTO `sd_withdraw` VALUES ('2', '1', '10.00', '1560941598', '1', '1561103049', '1');
INSERT INTO `sd_withdraw` VALUES ('3', '1', '10.00', '1560941627', '1', '', '0');
INSERT INTO `sd_withdraw` VALUES ('4', '1', '10.00', '1560941687', '1', '', '0');
