<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 0:18
 */

namespace app\common\logic;
use app\common\BaseModel;
use app\common\entity\UpgradeOrder as upgradeOrderEntity;
use app\common\model\NodeLevel;
use app\common\model\Statistics;
use app\common\model\UpgradeOrder as upgradeOrderModel;
use app\common\model\Member as MemberModel;
use app\common\model\ReflectCurrency;
use app\common\model\TurnoverLog;
use app\common\model\Statistics as statisticsModel;
use app\engine\service\Transaction as OtherClass;
use app\common\model\UpgradeOrder;
use think\Db;
use think\Exception;

class NodeOrder extends BaseModel
{
    protected $upgradeOrderEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->upgradeOrderEntity = new upgradeOrderEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){
        $map = "1=1";
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->upgradeOrderEntity->setReceiptNo($this->requestData['search']);
            $map = "(order_no like %{$this->requestData['search']}% OR receipt_no like %{$this->requestData['search']}%) ";
            $map_member = "nickname like %{$this->requestData['search']}%";
            $memberList = MemberModel::findAll($map_member,'id');
            $ids = '';
            foreach ($memberList as $value) {
                $ids += $value['id'] . ',';
            }
            $ids = tirm($ids, ',');
            $map .= " or user_id in ($ids)";
        }
        $list = upgradeOrderModel::pageList($map,'*',$limit,'created_at desc');

        $list->each(function($item, $key){
            $imgs_list = explode(',',$item['imgs']);
            $item['imgs_list'] = $imgs_list;
            $nickname = MemberModel::findOne(['id'=>$item['user_id']],'nickname,phone');
            $item['nickname'] = empty($nickname['nickname'])?'未知':$nickname['nickname'];
            $item['phone'] = empty($nickname['phone'])?'':$nickname['phone'];
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function updateStatus(){
        try {
            if (!array_key_exists('id', $this->requestData))
                return $this->failReturn('请选择数据');
            if (!array_key_exists('status', $this->requestData))
                return $this->failReturn('请选择操作类型');
            $this->upgradeOrderEntity->setStuats($this->requestData['status']);
            $info = upgradeOrderModel::findOne(['id' => $this->requestData['id']]);
            if (!$info)
                return $this->failReturn('数据不存在');
            $map['id'] = $this->requestData['id'];
            if($this->requestData['status']==1) {//通过
                $user = MemberModel::findOne(['id' => $info['user_id']]);

                if ($user['node_level'] == $info['level'])
                    return $this->failReturn('用户已经升级到该等级');
                $level = NodeLevel::findOne(['level' => $info['level'], 'type' => 1]);
                $stock = bcsub($level['total_people'],$level['num']);
                if (!$level)
                    return $this->failReturn('等级无效');
                if ($stock <= 0)
                    return $this->failReturn('该等级已达到顶峰');
            }
            Db::startTrans();

            $res = upgradeOrderModel::updateDatas($this->upgradeOrderEntity->params(), $map);
            if (!$res) {
                Db::rollback();
                return $this->failReturn('修改失败');
            }

            if ($this->requestData['status'] == 1) {
                $res4 = MemberModel::updateDatas(['is_buy_node'=>1,'node_level'=>$info['level'],'is_node'=>1],['id'=>$info['user_id']]);
                $res2 = MemberModel::where(['id'=>$info['user_id']])->setInc('freeze_aih2',$level['gift_aih']);
                $res3 = TurnoverLog::addTurnoverLog($info['user_id'],25,1,$level['gift_aih'],1,0,'购买节点人');
                statisticsModel::updateValueByName(2,$level['gift_aih'],$info['user_id'],'购买节点人赠送');
                $res6 = NodeLevel::where(['level'=>$info['level']])->setInc('num',1);
                if(!$res2||!$res3||!$res4||!$res6) {
                    Db::rollback();
                    return $this->failReturn('操作失败');
                }
                $data = [
                    'p_uid'=>$user['pid'], //上级id
                    'identity'=>$info['level'],//身份
                ];
                $ress = OtherClass::user_inspect($info['user_id'],$data);
                $rel = json_decode($ress,true);
                if($rel['code']==0){
                    Db::rollback();
                    return $ress;
                }
            }
            Db::commit();
            return $this->successReturn('修改成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }
}