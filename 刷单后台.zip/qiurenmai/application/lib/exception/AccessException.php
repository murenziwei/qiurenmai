<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/27
 * Time: 11:45
 */

namespace app\lib\exception;


class AccessException extends BaseException
{
    public $code = 0;
    public $message = '用户权限不足';
    public $errorCode = 20001;

}