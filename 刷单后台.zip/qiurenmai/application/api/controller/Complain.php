<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-05 18:04:56
 */
namespace app\api\controller;

use think\Db;
use app\api\validate\Complain as ComplainVali;

class Complain extends Base
{
    public function complainList(){
        $user_id = $this ->user["id"];
        $list = Db::name("complain") ->alias("t1")
                                     ->join("sd_son_task t2","t1.son_task_id=t2.id")
                                     ->where(["t2.shop_id"=>$user_id])
                                     ->field("t1.type,t1.note,t1.img1,t1.img2,t1.create_at,t1.status,t2.user_id,t1.son_task_id")
                                     ->order("t1.create_at desc")
                                     ->paginate(config("app.page_num"))
                                     ->toArray();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }

    //商家投诉
    public function addComplain(){
        $data = input();
        $validate = new ComplainVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $user_id = $this ->user["id"];
        $son_task = Db::name("son_task") ->where(["id"=>$data["son_task_id"],"shop_id"=>$user_id]) ->find();
        if(empty($son_task)){
            exit(ajaxReturn([],0,"任务未找到"));
        }
        $data["create_at"] = time();
        unset($data["access_token"]);
        $res = Db::name("complain") ->insert($data);
        if($res){
            exit(ajaxReturn([],1,"申诉提交成功"));
        }else{
            exit(ajaxReturn([],0,"申诉提交失败"));
        }
    }
}