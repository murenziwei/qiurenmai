<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/26
 * Time: 15:14
 */

namespace app\common\entity;


class Config extends BaseEntity
{
    public $id;
    public $name;
    public $value;
    public $inc_type;
    public $desc;

    /**
     * @param mixed $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $name
     */
    public function setName(string $name)
    {
        $this->name = $name;
    }

    /**
     * @param mixed $value
     */
    public function setValue(string $value)
    {
        $this->value = $value;
    }

    /**
     * @param mixed $inc_type
     */
    public function setIncType(string $inc_type)
    {
        $this->inc_type = $inc_type;
    }

    /**
     * @param mixed $desc
     */
    public function setDesc(string $desc)
    {
        $this->desc = $desc;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * @return mixed
     */
    public function getIncType()
    {
        return $this->inc_type;
    }

    /**
     * @return mixed
     */
    public function getDesc()
    {
        return $this->desc;
    }


}