<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-04 14:25:10
 */
namespace app\api\controller;


class Mobile
{
    protected $account = "qcds-hy";
    protected $password = "qcds123";
    protected $http = "http://mt.yusms.com/send.do";

    public function sendMsg($Mobile,$code){
        $content = "验证码".$code."，有效期15分钟。您正在进行身份验证，如非本人操作，建议立即更改账户密码。";
        $url = $this ->http."?Account=".$this ->account."&Password=".$this ->password."&Mobile=".$Mobile."&Content=".$content."&Exno=0&Fmt=json";
        $json = curl_get($url);
        return json_decode($json,true);
    }
}