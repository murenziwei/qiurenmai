<?php
namespace app\api\validate;

use think\Validate;

class Goods extends Validate
{
    protected $rule = [
        'goods_name'  => 'require|max:50',
        'goods_link' => 'require',
        //'goods_img' => 'require|max:50',
        'real_price' => 'require|float',
        'goods_count' => 'require|number',
        'show_price' => 'require|float',
        'searh_start_price' => 'number',
        'searh_end_price' => 'number',
        'goods_location' => 'max:10',
        'sell_num' => 'number',
        'is_post' => 'number|between:0,1'
    ];

    protected $field = [
        'goods_name'  => '商品名称',
        'goods_link' => '商品链接',
        //'goods_img' => '商品主图',
        'real_price' => '实际价格',
        'goods_count' => '商品数量',
        'show_price' => '展示价格',
        'searh_start_price' => '搜索区间价格',
        'searh_end_price' => '搜索区间价格',
        'goods_location' => '商品所在地',
        'sell_num' => '付款人数',
        'is_post' => '是否包邮'
    ];

}