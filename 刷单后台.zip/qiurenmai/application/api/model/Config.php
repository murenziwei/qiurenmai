<?php
namespace app\api\model;

use think\Model;
use think\Db;

class Config extends Model
{
    //获取配置字段
    public static function getConf($type="",$field=""){
        if(empty($type)){
            $list = Db::name("config") ->select();
        }else{
            $list = Db::name("config") ->where("inc_type",$type) ->select();
        }
        if(empty($list)){
            exit(ajaxReturn([],0,"配置列表为空"));
        }
        $data = [];
        foreach($list as $v){
            $data[$v["key"]] = $v["value"];
        }
        if(empty($field)){
            return $data;
        }else{
            if(isset($data[$field])){
                return $data[$field];
            }else{
                exit(ajaxReturn([],0,"字段不存在"));
            }
        }
    }
    //计算佣金价格
    public static function getCommission($type,$cash_pledge){
        $commission_fee = Db::name("task_commission_fee") ->where(["task_type"=>$type,"is_del"=>0]) ->where("start_price","lt",$cash_pledge) ->where("end_price","gt",$cash_pledge) ->value("commission_fee");
        if(empty($commission_fee)){
            exit(ajaxReturn([],0,"花费佣金未找到"));
        }
        return $commission_fee;
    }
}