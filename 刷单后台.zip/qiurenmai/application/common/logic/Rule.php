<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/8
 * Time: 15:53
 */
namespace app\common\logic;
use app\common\BaseModel;
use app\common\model\Rule as ruleModel;
use app\common\entity\Rule as ruleEntity;

class Rule extends BaseModel
{
    protected $ruleEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->ruleEntity = new ruleEntity();
    }




    public function saveData(){
        
    }
}