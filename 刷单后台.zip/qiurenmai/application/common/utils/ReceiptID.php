<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/16
 * Time: 15:04
 */

namespace app\common\utils;


class ReceiptID
{

    /**
     * 创建新账号
     * @param string $password = "00008888"
     * @return string
     */
    public static function newAccount($length=30)
    {
        return '0x'.self::getRandStr($length);
    }

    /**
     * 生成唯一请求id
     * @return String
     */
    public static function generate(){
        // 使用session_create_id()方法创建前缀
//        session_start();
//        var_dump(session_create_id());
        $prefix = session_regenerate_id();
        // 使用uniqid()方法创建唯一id
        $request_id = strtoupper(md5(uniqid($prefix, true)));var_dump($request_id);exit;
        // 格式化请求id
        return '0x'.self::format($request_id);
    }

    /**
     * 格式化请求id
     * @param String $request_id 请求id
     * @param Array $format  格式
     * @return String
     */
    private static function format($request_id, $format='8,4,4,4,12'){
        $tmp = array();
        $offset = 0;
        $cut = explode(',', $format);
        // 根据设定格式化
        if($cut){
            foreach($cut as $v){
                $tmp[] = substr($request_id, $offset, $v);
                $offset += $v;
            }
        }
        // 加入剩余部分
        if($offset<strlen($request_id)){
            $tmp[] = substr($request_id, $offset);
        }
        return implode('-', $tmp);
    }

    private static function getRandStr($length){
        $str='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $len=strlen($str)-1;
        $randstr='';
        for($i=0;$i<$length;$i++){
            $num=mt_rand(0,$len);
            $randstr .= $str[$num];
        }
        return $randstr;
    }
}