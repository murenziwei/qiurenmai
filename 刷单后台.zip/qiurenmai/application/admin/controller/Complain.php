<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;

class Complain extends Base
{
    public function index(){
        $list = Db::name("complain") ->alias("t1")
                                     ->join("sd_son_task t2","t1.son_task_id=t2.id")
                                     ->field("t1.*,t2.user_id as appellee")
                                     ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    public function doCkComp(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $res = Db::name("complain") ->where(["id"=>$id]) ->update(["status"=>1]);
        if($res !== false){
            $this ->success("处理成功");
        }else{
            $this ->error("处理失败");
        }
    }
}