<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

//生成随机字符串（一般用于生成订单号）
function getRandChar($length)
{
    $str = null;
    $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
    $max = strlen($strPol) - 1;

    for ($i = 0;
         $i < $length;
         $i++) {
        $str .= $strPol[rand(0, $max)];
    }

    return $str;
}

/**
 * 对象 转 数组
 * @param object $obj 对象
 * @return array
 */
function object_to_array($obj) {
    $obj = (array)$obj;
    foreach ($obj as $k => $v) {
        if (gettype($v) == 'resource') {
            return;
        }
        if (gettype($v) == 'object' || gettype($v) == 'array') {
            $obj[$k] = (array)object_to_array($v);
        }
    }
    return $obj;
}

function backslashesReplace($str)
{
    return str_replace('\\','/',$str);
}

/**
 * 返回符合条件的键值数组
 * @param $a1 用于比较的条件
 * @param $a2 目标源数据
 * @return mixed 返回符合条件的键值数组
 */
function arrayKeyExistsValue($a1,$a2)
{
    foreach ($a2 as $k=>$p){
        if (!array_key_exists($k,$a1)) unset($a2[$k]);
    }
    return $a2;
}

/**
 * CURL请求
 * @param $url 请求url地址
 * @param $method 请求方法 get post
 * @param null $postfields post数据数组
 * @param array $headers 请求header信息
 * @param bool|false $debug  调试开启 默认false
 * @return mixed
 */
function httpRequest($url, $method="GET", $postfields = null, $headers = array(), $debug = false) {
    $method = strtoupper($method);
    $ci = curl_init();
    /* Curl settings */
    curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
    curl_setopt($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0");
    curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, 60); /* 在发起连接前等待的时间，如果设置为0，则无限等待 */
    curl_setopt($ci, CURLOPT_TIMEOUT, 7); /* 设置cURL允许执行的最长秒数 */
    curl_setopt($ci, CURLOPT_RETURNTRANSFER, true);
    switch ($method) {
        case "POST":
            curl_setopt($ci, CURLOPT_POST, true);
            if (!empty($postfields)) {
                $tmpdatastr = is_array($postfields) ? http_build_query($postfields) : $postfields;
                curl_setopt($ci, CURLOPT_POSTFIELDS, $tmpdatastr);
            }
            break;
        default:
            curl_setopt($ci, CURLOPT_CUSTOMREQUEST, $method); /* //设置请求方式 */
            break;
    }
    $ssl = preg_match('/^https:\/\//i',$url) ? TRUE : FALSE;
    curl_setopt($ci, CURLOPT_URL, $url);
    if($ssl){
        curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
        curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, FALSE); // 不从证书中检查SSL加密算法是否存在
    }
    //curl_setopt($ci, CURLOPT_HEADER, true); /*启用时会将头文件的信息作为数据流输出*/
    curl_setopt($ci, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ci, CURLOPT_MAXREDIRS, 2);/*指定最多的HTTP重定向的数量，这个选项是和CURLOPT_FOLLOWLOCATION一起使用的*/
    curl_setopt($ci, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ci, CURLINFO_HEADER_OUT, true);
    /*curl_setopt($ci, CURLOPT_COOKIE, $Cookiestr); * *COOKIE带过去** */
    $response = curl_exec($ci);
    $requestinfo = curl_getinfo($ci);
    $http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);
    if ($debug) {
        echo "=====post data======\r\n";
        var_dump($postfields);
        echo "=====info===== \r\n";
        print_r($requestinfo);
        echo "=====response=====\r\n";
        print_r($response);
    }
    curl_close($ci);
//    return $response;
    return array($http_code, $response,$requestinfo);
}

function checkPassword($string){
//    if(preg_match("/^1[34578]{1}\d{9}$/",$mobile)){
    if(preg_match("/^[A-Za-z0-9_]{6,12}$/",$string)){
        return true;
    }else{
        return false;
    }
}

function checkMobile($mobile){
//    if(preg_match("/^1[34578]{1}\d{9}$/",$mobile)){
    if(preg_match("/^[\d]{6,11}$/",$mobile)){
        return true;
    }else{
        return false;
    }
}

function checkEmail($email){
    if(preg_match("/([a-z0-9]*[-_\.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[\.][a-z]{2,3}([\.][a-z]{2})?/i",$email)){
        return true;
    }else{
        return false;
    }
}

/**
 * 富文本图片域名拼接
 * @param $content
 */
function preg_match_all_img(&$content)
{
    preg_match_all("/<img(.*)src=\"([^\"]+)\"[^>]+>/isU", $content, $matches);
    if (!empty($matches)) {
        $img = $matches[2];
    } else {
        $img = "";
    }
    if (!empty($img)) {
        $host_url = "http://" . $_SERVER['SERVER_NAME'];
        $patterns = array();
        $replacements = array();
        foreach ($img as $imgItem) {
            $final_imgUrl = $host_url . $imgItem;
            $replacements[] = $final_imgUrl;
            $img_new = "/" . preg_replace("/\//i", "\/", $imgItem) . "/";
            $patterns[] = $img_new;
        }
        ksort($patterns);
        ksort($replacements);
        $content = preg_replace($patterns, $replacements, $content);
    }
    preg_match_all_video($content);
}

function preg_match_all_video(&$content)
{
    preg_match_all("/<video(.*)src=\"([^\"]+)\"[^>]+>/isU", $content, $matches);
    if (!empty($matches)) {
        $img = $matches[2];
    } else {
        $img = "";
    }
    if (!empty($img)) {
        $host_url = "http://" . $_SERVER['SERVER_NAME'];
        $patterns = array();
        $replacements = array();
        foreach ($img as $imgItem) {
            $final_imgUrl = $host_url . $imgItem;
            $replacements[] = $final_imgUrl;
            $img_new = "/" . preg_replace("/\//i", "\/", $imgItem) . "/";
            $patterns[] = $img_new;
        }
        ksort($patterns);
        ksort($replacements);
        $content = preg_replace($patterns, $replacements, $content);
    }
}

/**
 * 获取邀请码
 * @param int $lenght
 * @return string11
 */
function init_code(int $lenght=8) {
    $code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $rand = $code[rand(0,25)]
        .strtoupper(dechex(date('m')))
        .date('d').substr(time(),-5)
        .substr(microtime(),2,5)
        .sprintf('%02d',rand(0,99));
    for(
        $a = md5( $rand, true ),
        $s = '0123456789ABCDEFGHIJKLMNOPQRSTUV',
        $d = '',
        $f = 0;
        $f < $lenght;
        $g = ord( $a[ $f ] ),
        $d .= $s[ ( $g ^ ord( $a[ $f + 8 ] ) ) - $g & 0x1F ],
        $f++
    );
    return $d;
}

function get_random($len=3){
    //range 是将10到99列成一个数组
    $numbers = range (10,99);
    //shuffle 将数组顺序随即打乱
    shuffle ($numbers);
    //取值起始位置随机
    $start = mt_rand(1,10);
    //取从指定定位置开始的若干数
    $result = array_slice($numbers,$start,$len);
    $random = "";
    for ($i=0;$i<$len;$i++){
        $random = $random.$result[$i];
    }
    return $random;
}

//获取协议
function get_domain(){
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    return $protocol.$_SERVER['SERVER_NAME'];
}

/**
 * 二维数组按指定字段排序
 * @param array $data 二维数组（关联数组）
 * @param string $field 排序字段
 * @param string $direction 排序方式
 * @return mixed
 */
function many_array_sort(&$data, $field, $direction = 'SORT_DESC',$field2='')
{
    $temp = array();
    foreach ($data as $uniqid => $item) {
        foreach ($item as $k => $val) {
            $temp[$k][$uniqid] = $val;
        }
    }
    if(empty($field2)){
        array_multisort($temp[$field], constant($direction), $data);
    }else {
        array_multisort($temp[$field], constant($direction), $temp[$field2], constant($direction), $data);
    }
}

//获取富文本中前80个字符数
function get_plain_text($content)
{
    $html_string = htmlspecialchars_decode($content);
    //将空格替换成空
    $content = str_replace(" ", "", $html_string);
    //函数剥去字符串中的HTML、XML以及PHP的标签,获取纯文本内容
    $contents = strip_tags($content);
    //返回字符串中的前60字符串长度的字符
    $text = mb_substr($contents, 0, 80, "utf-8");
    return $text;
}


/*
    * 根据二维数组某个字段的值查找数组
   */
function filter_by_value ($array, $index, $value){
    $newarray = [];
    if(is_array($array) && count($array)>0)
    {
        foreach(array_keys($array) as $key){
            $temp[$key] = $array[$key][$index];

            if ($temp[$key] == $value){
                $newarray[$key] = $array[$key];
            }
        }
    }
    return array_values($newarray);
}
/**
 * @文章列表搜索
 * @2017年4月25日15:13:52
 */
function arrList($arrs,$keywords=NULL,$type=array('title')){
    $result = [];
    foreach ($arrs as $key => $searchData) {
        $arr = array();
        foreach($searchData as $values=>$v ) {
            for ($i=0;$i<count($type);$i++){
                if ($values==$type[$i]){
                    array_push($arr, $values);
                }
            }
        }
        for ($a=0;$a<count($arr);$a++){
            if (strpos($searchData[$arr[$a]],$keywords)!==false) {
                $result[] = $searchData;
            }
        }
    }
    return $result;
}

/**
 * 加密手机中间四位数
 * @param $tel
 * @return mixed
 */
function encryptTel($tel) {
    $new_tel = preg_replace('/(\d{3})\d{4}(\d{4})/', '$1****$2', $tel);
    return $new_tel;
}


function encode_file_contents($filename){
    $type=strtolower(substr(strrchr($filename,'.'),1));var_dump(is_file($filename));
    if ('php' == $type && is_file($filename) && is_writable($filename)) { // 如果是PHP文件 并且可写 则进行压缩编码
        $contents = file_get_contents($filename); // 判断文件是否已经被编码处理
        $contents = php_strip_whitespace($filename);
        // 去除PHP头部和尾部标识
        $headerPos = strpos($contents,'<?php');
        $footerPos = strrpos($contents,'?>');
        $contents = substr($contents, $headerPos + 5, $footerPos - $headerPos);
        $encode = base64_encode(gzdeflate($contents)); // 开始编码
        $encode = '<?php'."\n eval(gzinflate(base64_decode("."'".$encode."'".")));\n\n?>";
        return file_put_contents($filename, $encode);
    }else{
        return false;
    }
}

function encode_file_contents1($filename){
    $T_k1 = RandAbc(); //随机密匙1
    $T_k2 = RandAbc(); //随机密匙2
    $vstr = file_get_contents($filename);
    $v1 = base64_encode($vstr);
    $c = strtr($v1, $T_k1, $T_k2); //根据密匙替换对应字符。
    $c = $T_k1.$T_k2.$c;
    $q1 = "O00O0O";
    $q2 = "O0O000";
    $q3 = "O0OO00";
    $q4 = "OO0O00";
    $q5 = "OO0000";
    $q6 = "O00OO0";
    $s = '$'.$q6.'=urldecode("%6E1%7A%62%2F%6D%615%5C%76%740%6928%2D%70%78%75%71%79%2A6%6C%72%6B%64%679%5F%65%68%63%73%77%6F4%2B%6637%6A");$'.$q1.'=$'.$q6.'{3}.$'.$q6.'{6}.$'.$q6.'{33}.$'.$q6.'{30};$'.$q3.'=$'.$q6.'{33}.$'.$q6.'{10}.$'.$q6.'{24}.$'.$q6.'{10}.$'.$q6.'{24};$'.$q4.'=$'.$q3.'{0}.$'.$q6.'{18}.$'.$q6.'{3}.$'.$q3.'{0}.$'.$q3.'{1}.$'.$q6.'{24};$'.$q5.'=$'.$q6.'{7}.$'.$q6.'{13};$'.$q1.'.=$'.$q6.'{22}.$'.$q6.'{36}.$'.$q6.'{29}.$'.$q6.'{26}.$'.$q6.'{30}.$'.$q6.'{32}.$'.$q6.'{35}.$'.$q6.'{26}.$'.$q6.'{30};eval($'.$q1.'("'.base64_encode('$'.$q2.'="'.$c.'";eval(\'?>\'.$'.$q1.'($'.$q3.'($'.$q4.'($'.$q2.',$'.$q5.'*2),$'.$q4.'($'.$q2.',$'.$q5.',$'.$q5.'),$'.$q4.'($'.$q2.',0,$'.$q5.'))));').'"));';

    $s = '<?php '."\n".$s."\n".' ?>';
    return file_put_contents($filename, $s);

}

function RandAbc($length = "") { // 返回随机字符串
    $str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    return str_shuffle($str);
}

/**
 * @param array $data
 * @param int $code
 * @param string $message
 * @return \think\response\Json
 */
function ajaxReturn($data = [],$code = 1,$message = 'success')
{
    header('Content-Type:application/json; charset=utf-8');
    if (!is_array($data) || empty($data)){
        return json_encode(['data'=>array(),'code'=>$code,'message'=>$message]);
    }
    if(array_key_exists('message',$data)){
        if(array_key_exists('status',$data)){
            return json_encode(['data'=>array(),'code'=>$data['status'],'message'=>$data['message']]);
        }else{
            return json_encode(['data'=>array(),'code'=>0,'message'=>$data['message']]);
        }
    }
    return json_encode(['data'=> !array_key_exists(0,$data) ? array($data) : $data,'code'=>$code,'message'=>$message]);
}

//二维数组去重
function assoc_unique($arr, $key) {

$tmp_arr = array();

foreach ($arr as $k => $v) {

if (in_array($v[$key], $tmp_arr)) {//搜索$v[$key]是否在$tmp_arr数组中存在，若存在返回true

unset($arr[$k]);

} else {

$tmp_arr[] = $v[$key];

}

}

//sort($arr); //sort函数对数组进行排序

return $arr;

}

//搜索
function search($data){
    $where = [];
    if(!empty($data['id'])){
      $where[] = ['id','eq',$data["id"]];
   }
   return $where;
}

//curl
function curl_get($url){
   $info=curl_init();
   curl_setopt($info,CURLOPT_RETURNTRANSFER,true);
   curl_setopt($info,CURLOPT_HEADER,0);
   curl_setopt($info,CURLOPT_NOBODY,0);
   curl_setopt($info,CURLOPT_SSL_VERIFYPEER, false);
   curl_setopt($info,CURLOPT_SSL_VERIFYHOST, false);
   curl_setopt($info,CURLOPT_URL,$url);
   $output= curl_exec($info);
   curl_close($info);
   return $output;
}