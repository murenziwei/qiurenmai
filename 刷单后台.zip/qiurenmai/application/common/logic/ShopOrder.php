<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/10
 * Time: 12:41
 */

namespace app\common\logic;

use app\common\BaseModel;
use app\common\entity\Order as orderEntity;
use app\common\model\Shoporder as shopOrderModel;
use app\common\model\Shopgoods as shopGoodsModel;
use app\common\model\Member as memberModel;
use app\api\logic\Shopgoods as shopGoodsLogic;
use app\common\model\Attr as attrModel;
use app\common\utils\Excel;
use think\Exception;

class ShopOrder extends BaseModel
{
    public $orderEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->orderEntity = new orderEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){
        $search = [
            'search'=>'',
            'status'=>'',
            'start_date'=>'',
            'end_date'=>'',
            'end_date'=>'',
            'shopping_status'=>'',
            'p'=>1,
        ];
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->orderEntity->setOrderNo($this->requestData['search']);
            $map[] = ['order_no','like','%'.$this->requestData['search'].'%'];
            $search['search'] = $this->requestData['search'];
        }
        if(isset($this->requestData['status'])&&$this->requestData['status']!=''){
            $map[] = ['status','=',$this->requestData['status']];
            $search['status'] = $this->requestData['status'];
        }
        if(isset($this->requestData['shopping_status'])&&$this->requestData['shopping_status']!=''){
            $map[] = ['shopping_status','=',$this->requestData['shopping_status']];
            $search['shopping_status'] = $this->requestData['shopping_status'];
        }
        if(isset($this->requestData['start_date'])&&!empty($this->requestData['start_date'])){
            $map[] = ['created_at','>=',strtotime($this->requestData['start_date'])];
            $search['start_date'] = $this->requestData['start_date'];
        }
        if(isset($this->requestData['end_date'])&&!empty($this->requestData['end_date'])){
            $map[] = ['created_at','<=',strtotime($this->requestData['end_date'].' 23:59:59')];
            $search['end_date'] = $this->requestData['end_date'];
        }
        if(isset($this->requestData['p'])&&!empty($this->requestData['p'])){
            $search['p'] = $this->requestData['p'];
        }
        if(empty($map))
            $map = '1=1';

        $list = shopOrderModel::pageList($map,'id,order_no,goods_id,uid,status,money,total_fee,price,goods_name,num,
        consignee,address,phone,message,pay_time,logistics_name,logistics_code,shipping_time,confirm_time,freight,spec,
        created_at,shopping_status',$limit,'created_at desc');
        $list->each(function($item,$key){
            $goods_info = shopGoodsModel::findOne(['id'=>$item['goods_id']],'name,unit,img');
            $item['goods_pic'] = isset($goods_info['img'])?$goods_info['img']:'';
            $item['goods_unit'] = isset($goods_info['unit'])?$goods_info['unit']:'';
            $user_info = memberModel::findOne(['id'=>$item['uid']]);
            $item['nickname'] = isset($user_info['nickname'])?$user_info['nickname']:'';
            $item['account'] = isset($user_info['serial_no'])?$user_info['serial_no']:'';
            $item['user_phone'] = isset($user_info['phone'])?$user_info['phone']:'';
        });
        return array_merge(['list'=>$list,'count'=>$list->total(),'page'=>$list->render()],$search);
    }

    /*
     * 设置发货
     */
    public function setShip(){
        try{
            if(!array_key_exists('order_id',$this->requestData)||empty($this->requestData['order_id']))
                return $this->failReturn('请求参数错误');
            $order = shopOrderModel::findOne(['id'=>$this->requestData['order_id']],'id,logistics_name,logistics_code');
            if(!$order)
                return $this->failReturn('数据不存在');
            if(!array_key_exists('logistics_name',$this->requestData)||empty($this->requestData['logistics_name']))
                return $this->failReturn('物流名称不能为空');
            if(!array_key_exists('logistics_code',$this->requestData)||empty($this->requestData['logistics_code']))
                return $this->failReturn('发货单号不能为空');
            $this->orderEntity->setLogisticsName($this->requestData['logistics_name']);
            $this->orderEntity->setLogisticsCode($this->requestData['logistics_code']);
            if(empty($order['logistics_code'])) {
                $this->orderEntity->setShippingTime(time());
                $this->orderEntity->setShoppingStatus(1);
            }
            $res = shopOrderModel::updateDatas($this->orderEntity->params(),['id'=>$this->requestData['order_id']]);
            if(!$res)
                return $this->failReturn('操作失败');
            return $this->successReturn('操作成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 获取订单详情
     * @return string|\think\response\Json
     */
    public function getDetail(){
        try{
            if(!array_key_exists('order_id',$this->requestData)||empty($this->requestData['order_id']))
                return $this->failReturn('参数错误');
            $field = "id,order_no,goods_id,uid,status,money,total_fee,price,goods_name,num,
        consignee,address,phone,message,pay_time,logistics_name,logistics_code,shipping_time,confirm_time,freight,spec,shopping_status,created_at";
            $order = shopOrderModel::findOne(['id'=>$this->requestData['order_id']],$field);
            if(!$order)
                return $this->failReturn('数据不存在');
            $data = $order->toArray();
            $goods_info = shopGoodsModel::findOne(['id'=>$data['goods_id']],'name,unit,img');
            $data['goods_pic'] = isset($goods_info['img'])?$goods_info['img']:'';
            $data['goods_unit'] = isset($goods_info['unit'])?$goods_info['unit']:'';
            $user_info = memberModel::findOne(['id'=>$data['uid']]);
            $data['nickname'] = isset($user_info['nickname'])?$user_info['nickname']:'';
            $data['account'] = isset($user_info['serial_no'])?$user_info['serial_no']:'';
            $data['user_phone'] = isset($user_info['phone'])?$user_info['phone']:'';
            //获取商品数据
            $attr = json_decode($data['spec'],true);
            $attr_id_list = [];
            foreach ($attr as $item) {
                array_push($attr_id_list, $item['attr_id']);
            }
            $attr_list = attrModel::getAttrListByAttrIds($attr_id_list);
            $data['attr_list'] = $attr_list;
            return $this->successReturn('获取数据成功',$data);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 导出excel
     */
    public function excelExport(){
        $page_size = 10;
        $headArr = ['ID','订单号','商品名','规格','下单用户id','下单用户手机','支付金额','商品总价','商品单价','订单运费','购买数量',
            '收货人','收货地址','收货人电话','买家留言','物流名称','发货单号','订单状态','下单时间','发货状态'];
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->orderEntity->setOrderNo($this->requestData['search']);
            $map[] = ['order_no','like','%'.$this->requestData['search'].'%'];
        }
        if(isset($this->requestData['status'])&&$this->requestData['status']!=''){
            $map[] = ['status','=',$this->requestData['status']];
        }
        if(isset($this->requestData['shopping_status'])&&$this->requestData['shopping_status']!=''){
            $map[] = ['shopping_status','=',$this->requestData['shopping_status']];
        }
        if(isset($this->requestData['start_date'])&&!empty($this->requestData['start_date'])){
            $map[] = ['created_at','>=',strtotime($this->requestData['start_date'])];
        }
        if(isset($this->requestData['end_date'])&&!empty($this->requestData['end_date'])){
            $map[] = ['created_at','<=',strtotime($this->requestData['end_date'].' 23:59:59')];
        }
        if(empty($map))
            $map = '1=1';
        if(isset($this->requestData['type'])&&!empty($this->requestData['type'])) {
            $type = $this->requestData['type'];
        }else{
            $type = 1;
        }
        $field = "id,order_no,goods_name,'' as attr_str,uid,'' as user_phone,money,total_fee,price,freight,num,
        consignee,address,phone,message,message,logistics_name,logistics_code,status,
        DATE_FORMAT(FROM_UNIXTIME(created_at),'%Y-%m-%d %H:%i:%s') as created_at,spec,goods_id,shopping_status";
        if($type==1){
            $limit = $page_size*($this->requestData['p']-1);
            $list = shopOrderModel::where($map)->field($field)->limit($limit,$page_size)->order('created_at desc')->select();
        }elseif($type==2){
            $list = shopOrderModel::where($map)->field($field)->order('created_at desc')->select();
        }
        if(!empty($list)){
            $list = $list->toArray();
        }else{
            $list = [];
        }
        $status_list = [
            '未付款','已付款','已完成','已取消','已退款','待退款'
        ];
        $shopping_status_list = ['待发货','已发货','已收货'];
        foreach ($list as $k => &$val){
            $user_info = memberModel::findOne(['id'=>$val['uid']]);
            $val['user_phone'] = isset($user_info['phone'])?$user_info['phone']:'';
            //获取商品数据
            $attr = json_decode($val['spec'],true);
            $attr_id_list = [];
            foreach ($attr as $item) {
                array_push($attr_id_list, $item['attr_id']);
            }
            $attr_list = attrModel::getAttrListByAttrIds($attr_id_list);
            $attr_str = '';
            foreach ($attr_list as $key => $v){
                $attr_str .= $v['attr_group_name'].'：'.$v['attr_name'].'/';
            }
            $val['attr_str'] = mb_substr($attr_str,0,mb_strlen($attr_str,'utf-8')-1,'utf-8');
            $val['status'] = $status_list[$val['status']];
            $val['shopping_status'] = $shopping_status_list[$val['shopping_status']];
            unset($val['goods_id']);
            unset($val['spec']);
        }
        $data = [
            'head_list' => $headArr,
            'list' => $list,
        ];
        Excel::orderExport($data);
    }
}