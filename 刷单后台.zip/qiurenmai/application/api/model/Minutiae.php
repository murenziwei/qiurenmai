<?php
namespace app\api\model;

use think\Model;
use think\Db;

class Minutiae extends Model
{
    public static function insertMinu($user_id,$type,$note,$num,$after_num,$from=1,$algorithm=1){
        $data = ["user_id"=>$user_id,"type"=>$type,"note"=>$note,"num"=>$num,"created_at"=>time(),"after_num"=>$after_num,"from"=>$from,"algorithm"=>$algorithm];
        Db::name("user_minutiae") ->insert($data);
    }

    public static function platformFlow($jin,$user_id,$task_id,$flow_type,$jin_type=1,$algorithm=1){
        $data = ["jin"=>$jin,"jin_type"=>$jin_type,"algorithm"=>$algorithm,"create_at"=>time(),"flow_type"=>$flow_type,"user_id"=>$user_id,"task_id"=>$task_id];
        Db::name("platform_flow") ->insert($data);
    }

    public static function getComiss($comment_info_id,$conf){
        if(!$comment_info_id){
            exit("评论ID错误");
        }
        $commentType = Db::name("task_comment_info") ->where("id",$comment_info_id) ->value("type");
        if(!$commentType){
            exit("评论类型未找到");
        }
        switch ($commentType) {
            case 1://普通好评
                $comment_fee = $conf["common_comment"];
                break;
            case 2://文字好评
                $comment_fee = $conf["word_comment"];
                break;
            case 3://图片好评
                $comment_fee = $conf["img_comment"];
                break;
            case 4://视频好评
                $comment_fee = $conf["video_comment"];
                break;
            default:
                $comment_fee = 0;
                break;
        }
        return $comment_fee;
    }
}