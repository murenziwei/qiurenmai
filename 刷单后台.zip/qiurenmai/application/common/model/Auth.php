<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/8
 * Time: 15:30
 */

namespace app\common\model;


class Auth extends BaseDao
{
    public static function getList(){
        $lists = self::where(['is_delete'=>0])->column('*','auth_id');
        $children = array();
        foreach ($lists as $value) {
            //思路：每次遍历后（遍历一次跳到下一条记录）把记录的pid做下标，把auth_id做value值，这样同pid的记录就会放在下标为pid的数组里面①$children[0][1],②$children[1][2]
            $children[$value['pid']][] = $value['auth_id'];
        }
        $data = [
            'list'=>$lists,
            'children'=>$children,
        ];
        return $data;
    }

    public function getParamsAttr($value){
        return json_decode($value,true);
    }
}