<?php
namespace app\api\model;
use app\common\model\BaseDao;
use app\common\utils\ReceiptID;
use think\Model;
use think\Db;

class Member extends BaseDao
{
    public function getAvatarAttr($value){
        if(empty($value)){
            return get_domain().'/20190520175231.png';
        }
        return $value;
    }
    /**
     * 获取QDC收款地址
     * @return String
     */
    public static function getReceiptNo(){
        $receipt_no = ReceiptID::newAccount();
        $res = self::findOne(['ue_address'=>$receipt_no]);
        if($res)
            $receipt_no = self::getReceiptNo();
        return $receipt_no;
    }

    /**
     * 获取PDC收款地址
     * @return String
     */
    public static function getPReceiptNo(){
        $receipt_no = ReceiptID::newAccount();
        $res = self::findOne(['ue_pd_address'=>$receipt_no]);
        if($res)
            $receipt_no = self::getPReceiptNo();
        return $receipt_no;
    }

    /**
     * 获取分享码
     * @return \string11
     */
    public static function getInvitationCode(){
        $invitation_code = init_code();
        $res = self::findOne(['invite_code'=>$invitation_code]);
        if($res)
            $invitation_code = self::getInvitationCode();
        return $invitation_code;
    }

    public static function getSerialNo(){
        $serial_no = get_random();
        $res = self::findOne(['serial_no'=>$serial_no]);
        if($res)
            $serial_no = self::getSerialNo();
        return $serial_no;
    }

    /**
     * 判断手机号码是否有效
     * @param $phone
     * @param int $user_id
     * @return bool
     */
    public static function checkMobile($phone,$user_id=0){
        $map = [
            'ue_phone'=>$phone,
        ];
        if($user_id!=0){
            $map['id'] = ['neq',$user_id];
        }
        $res = self::findOne($map);
        if($res){
            return true;
        }
        return false;
    }

    /**
     * 检查收款地址是否有效
     * @param $from
     * @param $receipt_no
     * @return bool
     */
    public static function checkReceiptNo($from,$receipt_no){
        if($from==1){
            $map['ue_address'] = $receipt_no;
        }else{
            $map['ue_pd_address'] = $receipt_no;
        }
        $res = self::findOne($map);
        if($res){
            return $res;
        }
        return false;
    }

    /**
     * 获取用户余额
     * @param $from
     * @param $user_id
     * @return mixed
     */
    public static function getUserMoney($from,$user_id){
        if($from==1){
            $field = 'ue_qdc';
        }else{
            $field = 'ue_pdc';
        }
        $money = self::where(['id'=>$user_id])->value($field);
        return $money;
    }

    /**
     * 获取好友列表（直推）
     * @param $user_id
     * @param int $limit
     * @return array|\PDOStatement|string|\think\Collection
     */
    public static function getPushPageList($user_id,$limit=10){
        $map = ['pid'=>$user_id];
        $field = "id as user_id,avatar,ue_account,ue_name,ue_phone,p_num,DATE_FORMAT(FROM_UNIXTIME(ue_reg_time),'%Y-%m-%d %H:%i:%s') as created_at";
        $list = self::paginates($map,$field,$limit,'created_at desc,id desc');
        foreach ($list as $k => &$val){
            if($val['p_num']==0){
                $val['is_vip'] = 0;
            }else{
                $val['is_vip'] = 1;
            }
//            unset($val['created_at']);
            unset($val['update_at']);
        }
        return $list;
    }

    /**
     * 获取团队人数
     * @param $user_id
     * @param int $level
     * @return int
     */
    public static function getTeamCount($user_id,&$level=1){
        if(!is_array($user_id))
            $user_ids[] = $user_id;
        else
            $user_ids = $user_id;
        $push_user_ids = self::whereIn('pid',$user_ids)->column('id');
        $team_count = 0;
        if(empty($push_user_ids))
            return $team_count;

        if($level==1){
            $level++;
            $team_count += self::getTeamCount($push_user_ids,$level);
        }elseif($level<=6){
            $level++;
            $team_count = count($push_user_ids);
            $team_count += self::getTeamCount($push_user_ids,$level);
        }
        return $team_count;
    }

    //结余
    public static function afterRes($user_id,$sum_fee,$add_or_del=1,$field="ue_jin"){

        $ue_jin = Db::name("member") ->where(["id"=>$user_id]) ->value($field);
        if(empty($ue_jin)){
            exit(ajaxReturn([],0,"用户余额未找到"));
        }
        if($add_or_del == 1){
            $after_num = $sum_fee + $ue_jin;
        }else{
            if($sum_fee > $ue_jin){
                exit(ajaxReturn([],0,"余额不足"));
            }
            $after_num = $ue_jin - $sum_fee;
        }
        Db::name("member") ->where(["id"=>$user_id]) ->update([$field=>$after_num]);
        return $after_num;
    }
}