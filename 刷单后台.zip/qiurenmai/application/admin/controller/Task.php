<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;

class Task extends Base
{
    public function index(){
        $data = input();
        $where = [];
        if(!empty($data['id'])){
          $where[] = ['t1.id','eq',$data["id"]];
       }

        $list = Db::name("son_task") ->alias("t1")
                                     ->join("sd_bind_shop t2","t1.shop_wang_id = t2.wangwang_id")
                                     ->where("t1.status","not between","-4,-1")
                                     ->where("t1.task_type","neq",5)
                                     ->where($where)
                                     ->field("t1.id,t2.shop_name,t1.status,t1.start_at")
                                     ->order("id desc")
                                     ->paginate(15,false,$data);
        $this ->assign("list",$list);
        $search_id = !empty($data['id'])?$data['id']:'';
        $this->assign('search_id',$search_id);
        return $this ->fetch();
    }

    //修改任务信息
    public function editTask(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $data = Db::name("son_task") ->where(["id"=>$id]) ->field("id,real_pay") ->find();
        if(empty($data)){
            $this ->error("数据获取失败");
        }
        $this ->assign("data",$data);
        return $this ->fetch();
    }

    public function doEditTask(){
        $id = input("post.id");
        $real_pay = input("post.real_pay");
        if(!is_numeric($id) || !is_numeric($real_pay)){
            $this ->error("参数有误");
        }
        $res = Db::name("son_task") ->where(["id"=>$id]) ->update(["real_pay"=>$real_pay]);
        if($res !== false){
            $this ->success("修改成功");
        }else{
            $this ->error("修改失败");
        }
    }
}