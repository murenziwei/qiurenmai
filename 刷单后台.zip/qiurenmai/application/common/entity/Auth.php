<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/8
 * Time: 15:34
 */

namespace app\common\entity;


class Auth extends BaseEntity
{
    public $auth_id;
    public $auth_name;
    public $rules;
    public $pid;
    public $is_delete;
    public $type;

    /**
     * @return mixed
     */
    public function getAuthId()
    {
        return $this->auth_id;
    }

    /**
     * @param mixed $auth_id
     */
    public function setAuthId(int $auth_id)
    {
        $this->auth_id = $auth_id;
    }

    /**
     * @return mixed
     */
    public function getAuthName()
    {
        return $this->auth_name;
    }

    /**
     * @param mixed $auth_name
     */
    public function setAuthName(string $auth_name)
    {
        $this->auth_name = $auth_name;
    }

    /**
     * @return mixed
     */
    public function getRules()
    {
        return $this->rules;
    }

    /**
     * @param mixed $rules
     */
    public function setRules(string $rules)
    {
        $this->rules = $rules;
    }

    /**
     * @return mixed
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @param mixed $pid
     */
    public function setPid(int $pid)
    {
        $this->pid = $pid;
    }

    /**
     * @return mixed
     */
    public function getIsDelete()
    {
        return $this->is_delete;
    }

    /**
     * @param mixed $is_delete
     */
    public function setIsDelete(int $is_delete)
    {
        $this->is_delete = $is_delete;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param mixed $type
     */
    public function setType(int $type)
    {
        $this->type = $type;
    }


}