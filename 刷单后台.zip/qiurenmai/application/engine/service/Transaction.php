<?php
/**
 * Created by PhpStorm.
 * User: xiao
 * Date: 2019/1/11
 * Time: 1:28
 */

namespace app\engine\service;


use app\common\BaseModel;
use app\common\model\Config;
use think\Db;
use think\Exception;
use think\Log;

class Transaction
{
    //托管
    /**
     * @param $user_id
     * @param $data
     * @return string|\think\response\Json
     * @throws \think\Exception
     * 用户身份录入
     */
    public static function user_inspect($user_id, $data)
    {
        $base = new BaseModel();
        Db::startTrans();
        Try {
            if (Db::table('tp_utrusteeship')->where(['uid' => $user_id])->count()) {
                Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->update($data);
            } else {
                $data['uid'] = $user_id;
                Db::table('tp_utrusteeship')->insert($data);
            }
            Db::commit();//事务提交
            return $base->successReturn('success', Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->find());
        } catch (\Exception $e) {
            Db::rollback();//事务回滚
            return $base->failReturn('请联系程序员。', $e->getMessage());
        }
    }

    /**
     * @param $user_id
     * @param $currency
     * @param $number
     * @param string $sql
     * @return string|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 用户增币减币 user_id=1，currency=aih，number=1，sql=setInc，within=0，abroad=0，day=90
     */
    public static function user_recharge($user_id, $currency, $number, $sql = 'setInc', $within = '', $abroad = '', $day = '90', $authority = true)
    {
//        Db::table('tp_utrusteeship')->where('uid','eq',$user_id)->setInc('aih',$number);
//        return;
        $base = new BaseModel();
        if ($sql != 'setInc' && $sql != 'setDec') {
            return $base->failReturn('请使用setInc或setDec。' . $sql);
        }
        if ($sql != 'setInc') {
            $pay = Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->value($currency);
            if ($pay < $number) {
                return $base->failReturn('余额不足');
            }
        }
        Db::startTrans();
        Try {
            if ($sql == 'setDec') {
                if ($within == '' || $abroad == '') {
                    return $base->failReturn('请联系程序员。');
                }
                $check = Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->value($currency . '_time');
                if ($check <= date("Y-m-d h:i:s")) {
                    $num = $number - $number * ($within / 100);
                } else {
                    $num = $number - $number * ($abroad / 100);
                }
            } else {
                $num = '0';
                if ($day == '') {
                    return $base->failReturn('请联系程序员。');
                }
                if ($authority) {
                    Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->update([$currency . '_time' => date("Y-m-d h:i:s", strtotime('+' . $day . ' day'))]);
                }
            }
//            Db::table('tp_utrusteeship')->where('uid','eq',$user_id)->setInc('aih',$number);
            Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->$sql($currency, $number);
//            return $add;
            Db::commit();//事务提交
            return $base->successReturn('success', ['userinfo' => Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->find(), 'number' => $num ? $num : $number]);
        } catch (\Exception $e) {
            Db::rollback();//事务回滚
            return $base->failReturn('请联系程序员。' . $e, $e->getMessage());
        }
    }

    /**
     * @param $user_id
     * @param $currency
     * @param $percent
     * @param $Generation
     * @param $two_generation
     * @param $three_generation
     * @param $Infinite
     * @param $identitys
     * @param $identitys_name
     * @return string|\think\response\Json
     * 托管日利息计算
     */
    public static function user_interest($user_id, $currency, $percent, $Generation, $two_generation, $three_generation, $Infinite, $identitys, $identitys_name)
    {
        $user_list = Db::table('tp_utrusteeship')->where('uid', 'eq', $user_id)->value($currency);
        if ($currency != 'aih') {
            $config = Config::tpCache('base');
            $Todays_price = $config['issue_price_usdt'];//当天usdt价格
            $Todays_pricea = $config['issue_price'];//当天aih价格
            $data[] = [
                'uid' => $user_id,
                'currency' => $currency,
                'y_number' => $user_list,
                'operation' => '0',
                'percent' => $percent,
                'number' => $user_list * $Todays_price * ($percent / 100) / $Todays_pricea,
                'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * $Todays_price * ($percent / 100) / $Todays_pricea,
            ];
        } else {
            $data[] = [
                'uid' => $user_id,
                'currency' => $currency,
                'y_number' => $user_list,
                'operation' => '0',
                'percent' => $percent,
                'number' => $user_list * ($percent / 100),
                'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100),
            ];
        }
        $base = new BaseModel();
        $that = new Transaction();
        $res = $that->check_user($user_id);
        if (count($res) > 0) {
            foreach ($res as $k => $v) {
                $x = [
                    'uid' => $res[$k]['uid'],
                    'currency' => $currency,
                    'y_number' => $res[$k][$currency],
                    'operation' => '0',
                ];
                if ($k <= '2') {
                    switch ($k) {
                        case '0':
                            $y = [
                                'percent' => $Generation,
                                'number' => ($user_list * ($percent / 100)) * ($Generation / 100),
                                'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份返利：' . ($user_list * ($percent / 100)) * ($Generation / 100) . '--当天返利比例：' . $Generation . '%',
                            ];
                            break;
                        case '1':
                            $y = [
                                'percent' => $two_generation,
                                'number' => ($user_list * ($percent / 100)) * ($two_generation / 100),
                                'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份返利：' . ($user_list * ($percent / 100)) * ($two_generation / 100) . '--当天返利比例：' . $two_generation . '%',
                            ];
                            break;
                        case '2':
                            $y = [
                                'percent' => $three_generation,
                                'number' => ($user_list * ($percent / 100)) * ($three_generation / 100),
                                'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份返利：' . ($user_list * ($percent / 100)) * ($three_generation / 100) . '--当天返利比例：' . $three_generation . '%',
                            ];
                            break;
                    }
                } else if ($k > '2' && $k <= '9') {
                    $y = [
                        'percent' => $Infinite,
                        'number' => ($user_list * ($percent / 100)) * ($Infinite / 100),
                        'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份返利：' . ($user_list * ($percent / 100)) * ($Infinite / 100) . '--当天返利比例：' . $Infinite . '%',
                    ];
                } else {
                    if ($res[$k]['identity']) {
                        $y = [
                            'percent' => $identitys[$res[$k]['identity'] - 1],
                            'number' => ($user_list * ($percent / 100)) * ($identitys[$res[$k]['identity'] - 1] / 100),
                            'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份(' . $identitys_name[$res[$k]['identity'] - 1] . '身份) 返利：' . ($user_list * ($percent / 100)) * ($identitys[$res[$k]['identity'] - 1] / 100) . '--当天返利比例：' . $identitys[$res[$k]['identity'] - 1] . '%',
                        ];
                    } else {
                        $x['operation'] = '1';
                        $y = [
                            'percent' => $Infinite,
                            'number' => ($user_list * ($percent / 100)) * ($Infinite / 100),
                            'remarks' => '用户ID：' . $user_id . '，当天' . date("Y-m-d h:i:s") . '利息为:' . $user_list * ($percent / 100) . '--' . ($k + 1) . '代身份，因暂无管家身份返利无效--当天返利比例：' . $Infinite . '%',
                        ];
                    }
                }
                $z = array_merge($x, $y);
                if ($z['number'] >= '0.00001') {
                    $data[count($data)] = $z;
                    continue;
                } else {
                    break;
                }
            }
        }
        Db::startTrans();
        Try {
            Db::table('tp_interest')->insertAll($data);
            Db::commit();//事务提交
            return $base->successReturn('success');
        } catch (\Exception $e) {
            Db::rollback();//事务回滚
            return $base->failReturn('请联系程序员。', $e->getMessage());
        }
    }

//    public static function user_interest($user_id,$currency,$percent,$Generation,$two_generation,$three_generation,$Infinite,$identitys,$identitys_name){
//        $user_list = Db::table('tp_utrusteeship')->where('uid','eq',$user_id)->value($currency);
//        $data[] = [
//            'uid'=>$user_id,
//            'currency'=>$currency,
//            'y_number'=>$user_list,
//            'operation'=>'0',
//            'number'=>$user_list*($percent/100),
//            'percent'=>$percent,
//            'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100),
//        ];
//        $base = new BaseModel();
//        $that = new Transaction();
//        if ($currency != 'aih'){
//            $config = Config::tpCache('base');
//            $Todays_price = $config['issue_price_usdt'];//当天usdt价格
//            $Todays_pricea = $config['issue_price'];//当天aih价格
//            $data[] = [
//                'uid'=>$user_id,
//                'currency'=>$currency,
//                'y_number'=>$user_list,
//                'operation'=>'0',
//                'percent'=>$percent,
////                100 * usdt价格*20%利润＝ 每天的利息除以aih的价格 那就等于usdt的利息
//                'number'=> $user_list*$Todays_price * ($percent/100) / $Todays_pricea,
//                'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*$Todays_price * ($percent/100) / $Todays_pricea,
//            ];
//        }
//        $res = $that->check_user($user_id);
//        if(count($res)>0){
//            foreach ($res as $k=>$v){
//                $x =  [
//                    'uid'=>$res[$k]['uid'],
//                    'currency'=>$currency,
//                    'y_number'=>$res[$k][$currency],
//                    'operation'=>'0',
//                ];
//                if ($k <= '2'){
//                    switch($k){
//                        case '0':
//                            $y =  [
//                                'number'=>($user_list*($percent/100))*($Generation/100),
//                                'percent'=>$Generation,
//                                'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份返利：'.($user_list*($percent/100))*($Generation/100).'--当天返利比例：'.$Generation.'%',
//                            ];
//                            break;
//                        case '1':
//                            $y =  [
//                                'number'=>($user_list*($percent/100))*($two_generation/100),
//                                'percent'=>$two_generation,
//                                'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份返利：'.($user_list*($percent/100))*($two_generation/100).'--当天返利比例：'.$two_generation.'%',
//                            ];
//                            break;
//                        case '2':
//                            $y =  [
//                                'number'=>($user_list*($percent/100))*($three_generation/100),
//                                'percent'=>$three_generation,
//                                'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份返利：'.($user_list*($percent/100))*($three_generation/100).'--当天返利比例：'.$three_generation.'%',
//                            ];
//                            break;
//                    }
//                }else if ($k > '2' && $k <= '9'){
//                    $y =  [
//                        'number'=>($user_list*($percent/100))*($Infinite/100),
//                        'percent'=>$Infinite,
//                        'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份返利：'.($user_list*($percent/100))*($Infinite/100).'--当天返利比例：'.$Infinite.'%',
//                    ];
//                }else{
//                    if ($res[$k]['identity']){
//                        $y =  [
//                            'number'=>($user_list*($percent/100))*($identitys[$res[$k]['identity']-1]/100),
//                            'percent'=>$identitys[$res[$k]['identity']-1],
//                            'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份('.$identitys_name[$res[$k]['identity']-1].'身份) 返利：'.($user_list*($percent/100))*($identitys[$res[$k]['identity']-1]/100).'--当天返利比例：'.$identitys[$res[$k]['identity']-1].'%',
//                        ];
//                    }else{
//                        $x['operation']='1';
//                        $y =  [
//                            'number'=>($user_list*($percent/100))*($Infinite/100),
//                            'percent'=>$Infinite,
//                            'remarks'=>'用户ID：'.$user_id.'，当天'.date("Y-m-d h:i:s").'利息为:'.$user_list*($percent/100).'--'.($k+1).'代身份，因暂无管家身份返利无效--当天返利比例：'.$Infinite.'%',
//                        ];
//                    }
//                }
//                $z = array_merge($x,$y);
//                if ($z['number'] >='0.00001'){
//                    $data[count($data)] = $z;
//                    continue;
//                }else{
//                    break;
//                }
//            }
//        }
//        Db::startTrans();
//        Try {
//            Db::table('tp_interest')->insertAll($data);
//            Db::commit();//事务提交
//            return $base->successReturn('success');
//        } catch (\Exception $e) {
//            Db::rollback();//事务回滚
//            return $base->failReturn('请联系程序员。',$e->getMessage());
//        }
//    }
    //循环上级返回数组
    public function check_user($oid, $data = [])
    {
        $x = Db::table('tp_utrusteeship')->where(['uid' => $oid])->find();
        if ($x['p_uid'] == '' || $x['p_uid'] <= '0') {
            return $data;
        }
        $y = Db::table('tp_utrusteeship')->where(['uid' => $x['p_uid']])->find();
        if ($y) {
            $data[count($data)] = $y;
            return $this->check_user($y['uid'], $data);
        }
        return $data;
    }
}