<?php
//配置文件
use think\facade\Env;
$params = require_once Env::get('CONFIG_PATH').'api'.DIRECTORY_SEPARATOR.'params.php';
return [
    'url_route_must'		=>  true,
    'token'       =>[
        'expire_in'=>24*3600*7,
        'token_salt'=>'GsKupMFTAVLQmDD4ZlpAYQWRcaAh9q70',
    ],
    'sms_temp'=>[
        'img_prefix'=>''
    ],
    'params'    =>  $params,
    "page_num"  =>   1
];