<?php
/**
 * Created by PhpStorm.
 * Login: Administrator
 * Date: 2018/3/27
 * Time: 11:21
 */

namespace app\common\utils;


use think\facade\Env;

class File
{
    public  $rule = ['size'=>856780,'ext'=>'jpg,png,gif'];
    public  $file;
    public  $fileName = 'image';
    public  $config = [
        "SIZE" => 2*1024*1024,
        "EXT" => array(".jpg" ,".png" ,".jpeg" ,".gif"),
        "PATH" => "/public/uploads/",
    ];
    public $errcode = [
        "000001"     =>     "文件超过指定大小！",
        "000002"     =>     "文件读取失败！",
    ];
    public function fileName($fileName){
        if ($fileName) $this->fileName = $fileName;
        return $this->file = request()->file($this->fileName);
    }

    public function upload($fileName,$dir=''){
        $file = $this->fileName($fileName);
        if($file){
            $path =  Env::get('ROOT_PATH').'/public' . DIRECTORY_SEPARATOR . 'uploads';
            if ($dir) $path = Env::get('ROOT_PATH').'/public/'. $dir;
            $info = $file->validate($this->rule)->move($path);
            if($info){
                return '/uploads/'.$dir.backslashesReplace($info->getSaveName());
            }
            $this->getError($file);
        }
        return [];
    }

    public function uploads($fileName,$dir=''){
        $files = $this->fileName($fileName);
        $saveName = [];
        foreach($files as $file){
            $path =  Env::get('ROOT_PATH').'/public' . DIRECTORY_SEPARATOR . 'uploads';
            if ($dir) $path = Env::get('ROOT_PATH').'/public/'.$dir;
            $info = $file->validate($this->rule)->move($path);
            if($info){
                $saveName[] =  '/uploads/'.$dir.backslashesReplace($info->getSaveName());
            }else{
                $this->getError($file);
            }
        }
        return $saveName;
    }

    public function getError($file){
        $data = json_encode(['data'=>[],'code'=>0,'message'=>$file->getError()]);
        exit($data);
    }

    /**
     * [uploadUserAvatarUrl 上传文件]
     * @return [type]            [description]
     * @author D.Chen
     */
    public function uploadStream($fileName){
        $request = json_decode(file_get_contents("php://input") , true);
        if(empty($request))
            $request = $_POST;
        $base64_tmp = $request[$fileName];
        $img_path   = $this->updateImages($base64_tmp,$this->config);
        if($img_path == -1)
            return ['code'=>0,'msg'=>'文件超过指定大小'];
        if($img_path == -2)
            return ['code'=>0,'msg'=>'文件读取失败'];
        $avatar_url = substr($img_path ,7);
        return ['code'=>1,'msg'=>'上传成功','path'=>$avatar_url];
    }

    /**
     * [ctrlHandle 保存上传文件]
     * @param  [array]  $config  [上传文件的配置项]
     * @param  [string] $tmp     [文件流，base64解密]
     * @return [type]            [description]
     * @author D.Chen
     */
    private function updateImages($tmp ,$config = array()){
         if(strlen($tmp) > $config['SIZE'])
              return -1;
        $tmp = str_replace('data:image/png;base64,', '', $tmp);
        $tmp = str_replace('data:image/jpeg;base64,', '', $tmp);
        $tmp = str_replace('data:image/jpg;base64,', '', $tmp);
        $tmp = str_replace('data:image/gif;base64,', '', $tmp);
         $file_flow = base64_decode($tmp);
//         $file_flow = $tmp;
         $save_path = $config['PATH'] . date("Ymd",time());
         if(!file_exists(Env::get('ROOT_PATH').$save_path)){
              mkdir(Env::get('ROOT_PATH').$save_path , 0775);
         }
        $save_name = time() . ".png";
        $file_save_path = $save_path . "/" .$save_name;
        $res = file_put_contents(Env::get('ROOT_PATH').$file_save_path,$file_flow);
        if(!$res)
            return -2;
//        $fp = fopen(Env::get('ROOT_PATH').$file_save_path ,"wb");
//        $write = fwrite($fp ,$file_flow);
//        if(!$write)
//            return -2;
//        fclose($fp);
        return $file_save_path;
    }

}