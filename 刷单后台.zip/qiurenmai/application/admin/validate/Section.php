<?php
namespace app\admin\validate;

use think\Validate;

class Section extends Validate
{
    protected $rule = [
        'task_type'  => 'require|number|between:1,4',
        'start_price' => 'require|float',
        'end_price' => 'require|float',
        'commission_fee' => 'require|float'
    ];


    protected $field = [
        'task_type'  => '任务类型',
        'start_price' => '价格区间',
        'end_price' => '价格区间',
        'commission_fee' => '佣金费用'
    ];
}