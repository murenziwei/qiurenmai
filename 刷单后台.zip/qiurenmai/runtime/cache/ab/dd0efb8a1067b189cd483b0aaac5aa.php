<?php
//000000604800
 exit();?>
{"user":{"id":1,"uid":"","ue_account":"tst","cash_pledge":"0.00","ue_phone":"tst","qq_no":"","email":"","type":null,"create_at":"","last_login_at":"","bank_card":"","status":0,"access_token":""},"access_token":"9f19ba262f3743b37a0e7bbddf1f7b17","expire_in":604800,"refresh_token":"4e10d21b2266ee52032d7f61243333aa","timestamp":1559701219,"scope":""}