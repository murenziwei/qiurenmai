<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/8
 * Time: 17:12
 */
return [
    'type'     => 'page\Page',
    'var_page' => 'p',
];