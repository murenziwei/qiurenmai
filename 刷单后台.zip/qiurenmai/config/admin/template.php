<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/7
 * Time: 15:43
 */
return [
    //常量
    'tpl_replace_string'    =>  [
        '__STATIC__'    =>  '/static',
        '__CSS__'    =>  '/static/css',
        '__JS__'    =>  '/static/js',
        '__LAYUI__'    =>  '/static/lib/layui',
    ],
    //模板布局
    'layout_on'     =>  false,
    'layout_name'   =>  'layout/layout',
];