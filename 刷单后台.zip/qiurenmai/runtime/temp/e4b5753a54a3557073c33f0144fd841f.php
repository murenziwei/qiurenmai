<?php /*a:1:{s:76:"D:\phpstudy\PHPTutorial\WWW\shuadan\application\admin\view\config\index.html";i:1559125677;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.0</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/static/css/font.css">
    <link rel="stylesheet" href="/static/css/xadmin.css">
    <script type="text/javascript" src="/static/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="/static/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/static/js/xadmin.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<div class="x-nav">
      <span class="layui-breadcrumb">
        <a href="">首页</a>
        <a href="">配置设置</a>
      </span>
    <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right" href="javascript:location.replace(location.href);" title="刷新">
        <i class="layui-icon" style="line-height:30px">ဂ</i></a>
</div>
<div class="x-body">
    <form action="" method="post" class="layui-form layui-form-pane">

        <div style="width: 80%;display: flex;flex-wrap:wrap;align-items: center;">

            <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <div class="layui-form-item" >
                <label for="one_commission_ratio" class="layui-form-label" title="<?php echo htmlentities($vo['desc']); ?>" style="width: 200px;">
                    <span class="x-red">*</span><?php echo htmlentities($vo['desc']); ?>
                </label>
                <div class="layui-input-inline" style="width: 250px;">
                    <input type="text" id="<?php echo htmlentities($vo['id']); ?>" name="<?php echo htmlentities($vo['id']); ?>" value="<?php echo htmlentities($vo['value']); ?>" required="" lay-verify="number"
                           autocomplete="off" class="layui-input">
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>


        </div>
        <div class="layui-form-item">

            <button class="layui-btn" type="button" lay-submit="" lay-filter="add">保存</button>
        </div>

    </form>
</div>
<script>
    layui.use(['form','layer'], function(){
        $ = layui.jquery;
        var form = layui.form
            ,layer = layui.layer;

        //自定义验证规则
        form.verify({
            price:function (value) {
                if (!(/^[1-9]\d|0.[0-9]{2}$/.test(value))) {
                    return '格式不正确';
                }
            },
        });

        //监听提交
        form.on('submit(add)', function(data){
            console.log(data.field);

            $.ajax({
                type:"post",
                data:data.field,
                url:'<?php echo url("admin/Config/setConfig"); ?>',
                dataType:'json',
                success:function(json){
                    if(json.code==1) {
                        //发异步，把数据提交给php
                        layer.alert(json.message, {icon: 6}, function () {
                            location.reload(); //刷新父页面
                            // 获得frame索引
                            var index = parent.layer.getFrameIndex(window.name);
                            //关闭当前frame
                            parent.layer.close(index);
                        });
                        return false;
                    }else{
                        layer.alert(json.message, {icon: 2},function () {
                            // 获得frame索引
                            var index = parent.layer.getFrameIndex(window.name);
                            //关闭当前frame
                            parent.layer.close(index);
                        });
                        return false;
                    }
                }
            });

        });


    });
</script>
</body>

</html>