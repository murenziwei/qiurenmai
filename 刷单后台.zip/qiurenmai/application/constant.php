<?php
/**
 * 常量定义.
 */
define('TIMESTAMP',time());
// 定义host
define('__ROOT__',"http://".$_SERVER['HTTP_HOST']);



