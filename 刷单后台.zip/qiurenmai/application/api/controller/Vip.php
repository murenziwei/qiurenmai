<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-06-22 11:30:16
 */
namespace app\api\controller;

use think\Db;
use app\api\model\Minutiae;
use app\api\model\Member as MemberModel;

class Vip extends Base
{
    //购买vip界面
    public function vipUI(){
        //$user_id = $this ->user["id"];
        // $member = Db::name("member") ->where(["id"=>$user_id]) ->field("ue_account,vip") ->find();
        // if(empty($member)){
        //     exit(ajaxReturn([],0,'获取用户失败'));
        // }
        // $member["due_date"] = time() - $member["vip"];
        $package = Db::name("package") ->order("sort") ->field("id,month,price,discount") ->select();
        if(empty($package)){
            exit(ajaxReturn([],0,'获取数据失败'));
        }
        exit(ajaxReturn($package,1,'获取数据成功'));
    }

    //购买vip
    public function buyVip(){
        $id = input("id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $package = Db::name("package") ->where(["id"=>$id]) ->field("month,price") ->find();
        if(empty($package)){
            exit(ajaxReturn([],0,'获取套餐失败'));
        }
        $user_id = $this ->user["id"];
        $user_vip = Db::name("member") ->where(["id"=>$user_id]) ->value("vip");
        Db::startTrans();
        try{
            $after_num = MemberModel::afterRes($user_id,$package["price"],0,"commission");
            //写记录
            Minutiae::insertMinu($user_id,9,"购买会员".$package["month"].'个月',-$package["price"],$after_num,1,2);
            if(empty($user_vip)){
                $vip = time()+60*60*24*30*$package["month"];
            }else{
                $vip = $user_vip+60*60*24*30*$package["month"];
            }
            Db::name("member") ->where("id",$user_id) ->update(["vip"=>$vip]);
            //平台流水
            Minutiae::platformFlow($package["price"],$user_id,0,5,2);
            Db::commit();
            exit(ajaxReturn([],1,'购买成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }
}