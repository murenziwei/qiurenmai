<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/12
 * Time: 15:05
 */

namespace app\common\logic;

use app\common\BaseModel;
use app\common\model\Receivables as receivablesModel;
use app\common\entity\Receivables as receivablesEntity;

class Receivables extends BaseModel
{
    public $receivablesEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->receivablesEntity = new receivablesEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){

        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $map[] = ['receivables','like','%'.$this->requestData['search'].'%'];
        }
        if(isset($this->requestData['type'])&&!empty($this->requestData['type'])){
            $map[] = ['type','=',$this->requestData['type']];
        }
        if(empty($map))
            $map = "1=1";
        $list = receivablesModel::pageList($map,'*',$limit,'created_at desc');
        $list->each(function($item,$key){
            if($item['type']==1){
                $item['type_name'] = 'aih';
            }elseif($item['type']==2){
                $item['type_name'] = 'usdt';
            }elseif($item['type']==3){
                $item['type_name'] = 'eth';
            }elseif($item['type']==4){
                $item['type_name'] = 'btc';
            }
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function saveData(){
        if(!array_key_exists('receivables',$this->requestData)||empty($this->requestData['receivables']))
            return $this->failReturn('收款地址不能为空');
        if(!array_key_exists('type',$this->requestData)||empty($this->requestData['type']))
            return $this->failReturn('请选择类型');
        $this->receivablesEntity->setReceivables($this->requestData['receivables']);
        $this->receivablesEntity->setType($this->requestData['type']);
        if(array_key_exists('id',$this->requestData)&&!empty($this->requestData['id'])) {
            $check_rel = receivablesModel::checkReceivables($this->requestData['receivables'],$this->requestData['id']);
            if($check_rel)
                return $this->failReturn('收款地址已存在');
            $res = receivablesModel::updateDatas($this->receivablesEntity->params(), ['id' => $this->requestData['id']]);
        }else {
            $check_rel = receivablesModel::checkReceivables($this->requestData['receivables']);
            if($check_rel)
                return $this->failReturn('收款地址已存在');
            $this->receivablesEntity->setCreatedAt(time());
            $res = receivablesModel::createData($this->receivablesEntity->params());
        }
        if(!$res)
            return $this->failReturn('操作失败');
        return $this->successReturn('操作成功');
    }
}