<?php
/**
 * Created by PhpStorm.
 * User: xiao
 * Date: 2019/1/11
 * Time: 1:27
 */

namespace app\engine\service;

use app\common\BaseModel;
use think\Db;
use think\Request;
use think\Validate;

class Trusteeship {
//    交易
    /**
     * @param $data
     * @param $ratio
     * @param $user_num
     * @return string|\think\response\Json
     * 挂卖挂卖
     */
    public static function Hang_Business($data,$ratio,$user_num,$idratio){
        $rule = [
            'u_id|用户信息'=>'require',
            'currency|币种'=>'require',//币种 0.1.2.3
            'number|交易数量'=>'require',
            'price|交易价格'=>'require',
            'pay_mode|交易模式'=>'require',
            'receivables|收款账号'=>'require',//收款账号
        ];
        $base = new BaseModel();
        return $base->failReturn('系统维护中.');
        $validate = new Validate($rule);
        if (!$validate->check($data)) {
            return $base->failReturn($validate->getError());
        }
        $data['actual_number'] = $data['number']+($data['number'] * $ratio/100);//手续费
        $user_list = Db::table('tp_utrusteeship')->where('uid','eq',$data['u_id'])->value('identity');
        if ($user_list =='3' || $user_list =='4'){
            $data['actual_number'] = $data['number']+($idratio/100 * ($data['number'] * $ratio/100));//手续费
        }
//        return $data['actual_number'];
        if($data['attribute']==1) {
            if ($user_num < $data['actual_number'])
                return $base->failReturn('账户余额不足.');
            $list = Db::table('tp_transaction')->where('u_id','eq',$data['u_id'])->where('attribute','eq','1')->order('add_time desc')->find();
            if ($list){
                //如果有挂卖记录
                if ($list['state'] != '4'){
                    if ($list['state'] <= '3'){
                        return $base->failReturn('请完成上一笔交易后再次下单.');
                    }else if ($list['state'] != '100') {
                        return $base->failReturn('请完成上一笔交易后再次下单.');
                    }
                }
//            return $base->failReturn(date("Y-m-d H:i:s",strtotime($list['complete_time']."+7 day")));
                if ($list['state'] == '4' && $list['complete_time']<date("Y-m-d H:i:s",strtotime($list['complete_time']."+7 day"))){
                    return $base->failReturn('请等待上笔交易7天后再进行挂卖操作.');
                }
            }
        }

        if (Db::table('tp_transaction')->insertGetId($data))
            return $base->successReturn('提交成功',['actual_number'=>$data['actual_number'],'currency'=>$data['currency']]);
        return $base->failReturn('提交失败.请稍后尝试.');
    }

    /**
     * @param $user_id
     * @param $type
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 我的交易
     */
    public static function Business_list($user_id,$type){
        $base = new BaseModel();
        $data = Db::table('tp_transaction')->where(['u_id'=>$user_id])->select();
        if ($type)
            $data = Db::table('tp_transaction')->where(['us_id'=>$user_id])->select();
        return $base->successReturn('success',$data);
    }

    /**
     * @param $type
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 挂买挂卖列表数据
     */
    public static function Pay_list($type){
        $base = new BaseModel();
        $data = Db::table('tp_transaction')->where(['attribute'=>$type,'state'=>'0'])->select();
        return $base->successReturn('success',$data);
    }
    /**
     * @param $type
     * @return \think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 自动取消订单 定时
     */
    public static function Pay_cancel(){
        $data = Db::table('tp_transaction')->where('end_time','<=',date("Y-m-d h:i:s"))->field(['u_id','us_id','currency','actual_number','attribute'])->select();
        return $data;
    }

    public static function Anti_cancel($oids){
        $base = new BaseModel();
        $state = '100';
        $map['oid'] = array('in',$oids);
        if (Db::table('tp_transaction')->where($map)->update(['state'=>$state]))
            return $base->successReturn('取消成功.');
        return $base->failReturn('请刷新页面');
    }
    /**
     * @param $oid
     * @return string|\think\response\Json
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 数据详情
     */
    public static function Pay_details($oid){
        $base = new BaseModel();
        $data = Db::table('tp_transaction')->where('oid','eq',$oid)->find();
        if (!$data)
            return $base->failReturn('订单信息不存在');
        $data['Unit_Price'] = round($data['price']/$data['number'], 4);
        $data['OUnit_Price'] = round($data['actual_number']/$data['number'], 4);
        return $base->successReturn('success',$data);
    }

    /**
     * @param $oid
     * @return mixed
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * 查询改扣的多少币
     */
    public static function check_number($oid){
        $data = Db::table('tp_transaction')->where('oid','eq',$oid)->find();
        return $data['actual_number'];
    }

    /**
     * @param $oid
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     * 取消订单
     */
    public static function My_cancel($oid,$user_id){
        $base = new BaseModel();
        $state = '100';
        $data = Db::table('tp_transaction')->where(['u_id'=>$user_id,'oid'=>$oid,'state'=>'0'])->find();
        $price = '0';
        if ($data['attribute'])
            $price = $data['actual_number'];
        if (Db::table('tp_transaction')->where(['u_id'=>$user_id,'oid'=>$oid,'state'=>'0'])->update(['state'=>$state]))
            return $base->successReturn('取消成功.',['actual_number'=>$price,'currency'=>$data['currency']]);
        return $base->failReturn('请刷新页面');
    }
    /**
     * @param $oid
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     * 凭证错误
     */
    public static function My_voucher($oid,$user_id){
        $base = new BaseModel();
        if (Db::table('tp_transaction')->where(['u_id'=>$user_id,'oid'=>$oid])->update(['state'=>'3']))
            return $base->successReturn('操作成功.');
        return $base->failReturn('请刷新页面');
    }
    /**
     * @param $oid
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     * 完成
     */
    public static function My_complete($oid,$user_id){
        $base = new BaseModel();
        $data = Db::table('tp_transaction')->where(['u_id'=>$user_id,'oid'=>$oid,'state'=>'0'])->find();
        if (Db::table('tp_transaction')->where(['u_id'=>$user_id,'oid'=>$oid])->update(['state'=>'4','complete_time'=>date("Y-m-d h:i:s")]))
            return $base->successReturn('操作成功.',['number'=>$data['number'],'currency'=>$data['currency']]);
        return $base->failReturn('请刷新页面');
    }
    /**
     * @param $oid
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     * 上传凭证
     */
    public static function My_upload($oid,$user_id,$list){
        $base = new BaseModel();
        if (count($list)<=0)
            return $base->failReturn('请上传凭证');
        if (Db::table('tp_transaction')->where(['us_id'=>$user_id,'oid'=>$oid])->update(['state'=>'2','voucher'=>json_encode($list,JSON_UNESCAPED_UNICODE)]))
            return $base->successReturn('上传成功.');
        return $base->failReturn('请刷新页面');
    }
    /**
     * @param $oid
     * @param $type
     * @param $user_id
     * @param string $receivables
     * @return string|\think\response\Json
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     * 提交我要买我要卖
     */
    public static function My_Transaction($oid,$type,$user_id,$receivables='',$pay_mode=''){
        $base = new BaseModel();
        $state = '1';
        $data = Db::table('tp_transaction')->where('oid','eq',$oid)->find();
        if (!$data)
            return $base->failReturn('暂无该订单.');
        if ($data['state']!='0')
            return $base->failReturn('请不要重复操作.');
        if($type=='1'){
            if (!$receivables)
                return $base->failReturn('请提交转账账号.');
            if (!$pay_mode)
                return $base->failReturn('请提交转账方式.');
            $res =[
                'us_id'=>$user_id,
                'pay_mode'=>$pay_mode,//0挂买卖者选择 1微信 2支付宝 3银行卡
                'state' => $state,
                'receivables' => $receivables,
                'end_time' => date("Y-m-d h:i:s",strtotime('+7 day')),
                'order_time'=>date("Y-m-d H:i:s")
            ];
            if (Db::table('tp_transaction')->where('oid','eq',$oid)->update($res)){
                return $base->successReturn('success',['actual_number'=>$data['actual_number'],'currency'=>$data['currency']]);
            }
        }else if ($type=='0'){
            $res['state'] = $state;
            $res['us_id'] = $user_id;
            $res['end_time'] = date("Y-m-d h:i:s",strtotime('+7 day'));
            $res['order_time'] =date("Y-m-d H:i:s");
            if (Db::table('tp_transaction')->where('oid','eq',$oid)->update($res)){
                return $base->successReturn('success',['pay_mode'=>$data['pay_mode'],'receivables'=>$data['receivables']]);
            }
        }
        return $base->failReturn('错误参数.');
    }
}