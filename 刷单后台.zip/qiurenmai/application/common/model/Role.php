<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/8
 * Time: 15:30
 */

namespace app\common\model;


class Role extends BaseDao
{
    public static function getList(){
        $sql = "select t1.*,t2.auth_name,group_concat(t2.auth_name) as all_auth from sd_role t1
          left join sd_auth t2 on find_in_set(t2.auth_id,t1.auth_id_list) group by t1.role_id";
        $list = self::query($sql);
        $total = self::countData([],'role_id');
        return ['list'=>$list,'count'=>$total];
    }
}