<?php
namespace app\admin\validate;

use think\Validate;

class Package extends Validate
{
    protected $rule = [
        'month'  => 'require|number|between:1,100',
        'price' => 'require|float',
        'discount' => 'max:10',
        'sort' => 'require|number'
    ];


    protected $field = [
        'month'  => '月数',
        'price' => '价格',
        'discount' => '备注',
        'sort' => '排序'
    ];
}