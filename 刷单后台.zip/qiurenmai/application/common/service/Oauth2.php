<?php
namespace app\common\service;
use app\lib\exception\TokenException;
use think\Exception;
use \think\facade\Cache;
use app\lib\exception\ExceptionHandler;
use think\Db;


class Oauth2
{
    private static $Token;
    public static $expire_in;
    public static $refresh_token;
    public function __construct()
    {
        self::$Token = db("token");
        self::$expire_in = config('app.token.expire_in');
        self::$refresh_token = rand();
    }

    /**
     * 生成令牌
     * @param $user
     * @return array
     */
    public static function generateToken($user)
    {
        $randChar = getRandChar(32);
        $timestamp = $_SERVER['REQUEST_TIME'];
        $tokenSalt = config('app.token.token_salt');
        $token = md5($randChar . $timestamp . $tokenSalt);//加上账号

        return self::saveToCache($token,$user,md5($randChar),$timestamp);
    }
    /**
     * 生成二级密码令牌
     * @param $user
     * @return array
     */
    public static function secondToken($user)
    {
        $randChar = getRandChar(32);
        $timestamp = $_SERVER['REQUEST_TIME'];
        $tokenSalt = config('app.token.token_salt');
        $token = md5($randChar . $timestamp . $tokenSalt);//加上账号
        return self::saveToCache2($token,$user,md5($randChar),$timestamp);
    }
    /**
     * 获取token
     * @param $access_token
     * @return array
     * @throws TokenException
     */
    private function getCurrentTokenVar($access_token)
    {
        $token = Db::name("member") ->where(["access_token",$access_token]) ->value("access_token");
        if (!$token){
            throw new TokenException([
                'message' => '访问过期',
                'errorCode' => 10001
            ]);
        }else {
            return $token;
        }
    }
    public function getUserInfoByToken($access_token)
    {
        try{
            $currentTokenVar = $this->getCurrentTokenVar($access_token);
            $this->verifyToken($access_token,$currentTokenVar['access_token']);
            return $currentTokenVar;
        }catch (ExceptionHandler $e){
            return [
                'data' => array(),
                'code' => -1,
                'message' => $e->getMessage(),
                'errorCode' => $e->errorCode
            ];
        }

    }
    public function getSecondToken($access_token)
    {
        $currentTokenVar = $this->getCurrentTokenVar($access_token);
        $this->verifyToken($access_token,$currentTokenVar['second_token']);
        return $currentTokenVar;


    }
    /**
     * 写入缓存
     * @param $token
     * @param $user
     * @param $randChar
     * @param $timestamp
     * @return array
     * @throws TokenException
     */
    private static function saveToCache($token,$user,$randChar,$timestamp)
    {
        $values = [
            'user'=>$user,
            'access_token'=>$token,
            'expire_in'=>self::$expire_in,
            'refresh_token'=>$randChar,
            'timestamp'=>$timestamp,
            'scope' => ''
        ];
        // $result = cache($token, json_encode($values), self::$expire_in);
        //令牌插入数据库
        $result = Db::name("member") ->where(["id" => $user["id"]]) ->update(["access_token"=>$token,"login_at"=>(time()+self::$expire_in)]);
        if (!$result){
            throw new TokenException([
                'message' => '服务器异常',
                'errorCode' => 10002
            ]);
        }
        return $values;
    }
    /**
     * 写入二级缓存
     * @param $token
     * @param $user
     * @param $randChar
     * @param $timestamp
     * @return array
     * @throws TokenException
     */
    private static function saveToCache2($token,$user,$randChar,$timestamp)
    {
        $values = [
            'user'=>$user,
            'second_token'=>$token,
            'expire_in'=>self::$expire_in,
            'refresh_token'=>$randChar,
            'timestamp'=>$timestamp,
            'scope' => ''
        ];
        $result = cache($token, json_encode($values), self::$expire_in);
        if (!$result){
            throw new TokenException([
                'message' => '服务器异常',
                'errorCode' => 10002
            ]);
        }
        return $values;
    }
    /**
     * 更新令牌
     * @param $refresh_token
     * @param $access_token
     * @return array
     * @throws TokenException
     */
    public function refreshToken($refresh_token,$access_token)
    {
        $token = $this->getCurrentTokenVar($access_token);
        if (!$token || $token['refresh_token'] != $refresh_token){
            throw new TokenException([
                'message' => '登陆过期',
                'errorCode' => 10003
            ]);
         }
        Cache::rm($access_token);
        $user = $this->generateToken($token['user']);
        unset($user['user']);
        return $user;
    }

    /**
     * 验证token
     * @param $clientToken
     * @param $serverToken
     * @throws TokenException
     */
    public function verifyToken($clientToken,$serverToken)
    {
        if ($clientToken != $serverToken) {
            throw new TokenException([
                'message'=>'请求不合法',
                'errorCode'=>10004
            ]);
        }
    }

    /**
     * 验证签名请求时效性
     * 应用场景：主要用于验证sign签名请求时效性，防止他人中途截获签名信息尝试模拟请求，
     * 应该注意的是，请求延时或服务器和较大区域性时差可能会影响到用户的正常请求。
     * @param $signTimestamp
     * @throws TokenException
     *
     */
    public static function validateTime($signTimestamp)
    {
        $currentTimestamp = $_SERVER['REQUEST_TIME'];
        //sign签名时间timestamp+30秒和当前时间比较小于0为请求超时
        if ($signTimestamp + 30 - $currentTimestamp < 0) {
            throw new TokenException([
                'message'=>'请求超时',
                'errorCode'=>10005
            ]);
        }
    }
}