<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\9 0009
 * Time: 11:46
 */

namespace app\api\logic;

use app\common\BaseModel;
use app\api\entity\Login as loginEntity;
use app\common\entity\Member as memberEntity;
use app\api\model\Member as memberModel;
use app\common\model\MemberThaw as memberThawModel;
use app\common\model\UserMinutiae as userMinutiaeModel;
use app\common\model\SmsTemp as smsTempModel;
use app\common\service\Oauth2 as oauthService;
use PHPQRCode\QRcode;
use think\Db;
use think\Exception;
use think\facade\Cache;
use app\common\model\Config as configModel;
use Flc\Dysms\Client;
use Flc\Dysms\Request\SendSms;


class Member extends BaseModel
{
    public $loginEntity;
    public $memberEntity;

    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->memberEntity = new memberEntity();
    }

    /**
     * 注册
     * @return string|\think\response\Json
     */
    public function register(){
        try{
            if(!array_key_exists('phone',$this->requestData))
                return $this->failReturn('手机号码必填');
            $check_res =memberModel::checkMobile($this->requestData['phone']);
            if($check_res)
                return $this->failReturn('手机号码已被注册');
            $check_mobile = json_decode($this->checkBindMobile('',true), true);
            if ($check_mobile['code'] != 1) {
                return $this->failReturn($check_mobile['message']);
            }
            if(!array_key_exists('password',$this->requestData)||empty($this->requestData['password']))
                return $this->failReturn('密码必填');
            if(!checkPassword($this->requestData['password']))
                return $this->failReturn('密码格式6-12位字母或数字');
            $this->memberEntity->setUePhone($this->requestData['phone']);
            $this->memberEntity->setUeAccount($this->requestData['phone']);
            $this->memberEntity->setUeName($this->requestData['phone']);
            $this->memberEntity->setUePassword($this->requestData['password']);
            if($this->memberEntity->getUePassword()!==$this->requestData['en_password'])
                return $this->failReturn('两次密码不一致');
            if(!array_key_exists('pay_paw',$this->requestData)||empty($this->requestData['pay_paw']))
                return $this->failReturn('交易密码必填');
            if(!checkPassword($this->requestData['pay_paw']))
                return $this->failReturn('交易密码格式6-12位字母或数字');
            $this->memberEntity->setUePayPsw($this->requestData['pay_paw']);
            //邀请码
            if(!array_key_exists('invitation_code',$this->requestData)||empty($this->requestData['invitation_code']))
                return $this->failReturn('邀请码必填');
            $pid = memberModel::findOne(['code'=>strtoupper($this->requestData['invitation_code'])]);
            if(!$pid)
                return $this->failReturn('邀请码无效');
            $this->memberEntity->setPid($pid['id']);
            $this->memberEntity->setTrackPidList($pid['track_pid_list'].','.$pid['id']);
//            $this->memberEntity->setPid(0);
//            $this->memberEntity->setTrackPidList(0);

            //设置QDC收款地址
            $this->memberEntity->setUeAddress(memberModel::getReceiptNo());
            $this->memberEntity->setUePdAddress(memberModel::getReceiptNo());

            $this->memberEntity->setCode(memberModel::getInvitationCode());


            Db::startTrans();
            $time = time();
            $data = $this->memberEntity->params();
            $data['ue_password'] = md5(md5($data['ue_password']).config('app.salf'));
            $data['ue_pay_psw'] = md5(md5($data['ue_pay_psw']).config('app.salf'));
            $data['ue_reg_time'] = $time;
            $data['created_at'] = $time;
            $data['pid'] = isset($data['pid'])?$data['pid']:0;
            $data['track_pid_list'] = isset($data['track_pid_list'])?$data['track_pid_list']:0;

            $res = memberModel::createData($data);
            if($res!==false){
                Db::commit();
                $user = memberModel::findOne(['id' => $res['id']]);
                unset($user['ue_password']);
                unset($user['ue_pay_psw']);
                $user['ue_phone'] = encryptTel($user['ue_phone']);
                return $this->successReturn(
                    '注册成功',
                    (new oauthService())->generateToken($user)
                );
            }
            Db::rollback();
            return $this->failReturn('注册失败');
        }catch (Exception $e){
            Db::rollback();
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 登录
     * @return string|\think\response\Json
     */
    public function login(){
        try {
            $this->loginEntity = new loginEntity();
            if (array_key_exists('account', $this->requestData)) {
                $this->loginEntity->setUsername($this->requestData['account']);
            } else {
                return $this->failReturn('账号不能为空');
            }
            if (array_key_exists('password', $this->requestData)) {
                $this->loginEntity->setPassword($this->requestData['password']);
            } else {
                return $this->failReturn('密码不能为空');
            }
//        $map = $this->loginEntity->params();
            $map['ue_account'] = $this->loginEntity->getUsername();
            $map['ue_password'] = MD5(md5($this->loginEntity->getPassword()) . config('app.salf'));
            $user = memberModel::findOne($map);
            if (empty($user))
                return $this->failReturn('账号或者密码不正确');

            $is_freeze = Db::name("freeze") ->where("user_id",$user["id"]) ->where("freeze_date","gt",time())->field("note,freeze_day") ->find();
            if(!empty($is_freeze)){
                exit(ajaxReturn($is_freeze,0,"账号已被冻结"));
            }
            unset($user['ue_password']);
            //$user['ue_phone'] = encryptTel($user['ue_phone']);

            return $this->successReturn(
                '登陆成功',
                (new oauthService())->generateToken($user)
            );
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 忘记密码
     * @return string|\think\response\Json
     */
    public function forgetPassword(){
        try {
            $check_mobile = json_decode($this->checkBindMobile(), true);
            if ($check_mobile['code'] != 1) {
                return $this->failReturn($check_mobile['message']);
            }
            if (!array_key_exists('password', $this->requestData) || empty($this->requestData['password']))
                return $this->failReturn('密码必填');
            $this->memberEntity->setUePassword($this->requestData['password']);
            if ($this->memberEntity->getUePassword() !== $this->requestData['en_password'])
                return $this->failReturn('两次密码不一致');
            $map = $this->memberEntity->params();
            unset($map['ue_password']);

            $res = memberModel::updateDatas(['ue_password' => md5(md5($this->requestData['password']) . config('app.salf'))], $map);
            if ($res !== false) {
                return $this->successReturn('修改成功');
            }
            return $this->failReturn('修改失败');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 退出登录
     * @return \think\response\Json
     */
    public function logout(){
        Cache::rm($this->requestData['access_token']);
        return $this->successReturn(
            '退出成功'
        );
    }

    /**
     * 重置登录密码
     * @return string|\think\response\Json
     */
    public function savePassword(){
        try {
            if (!array_key_exists('old_password', $this->requestData) || empty($this->requestData['old_password']))
                return $this->failReturn('旧密码必填');
            if (!array_key_exists('password', $this->requestData) || empty($this->requestData['password']))
                return $this->failReturn('新密码必填');
            $this->memberEntity->setUePassword($this->requestData['password']);
            $user = memberModel::findOne(['id' => $this->user['id']]);
            $old_password = md5(md5($this->requestData['old_password']) . config('app.salf'));
            if ($user['ue_password'] != $old_password)
                return $this->failReturn('旧密码不正确');
            $data['ue_password'] = md5(md5($this->memberEntity->getUePassword()) . config('app.salf'));
            if ($old_password == $data['ue_password'])
                return $this->failReturn('新旧密码不能一致');
            $res = memberModel::updateDatas($data, ['id' => $user['id']]);
            if (!$res)
                return $this->failReturn('修改失败');
            Cache::rm($this->requestData['access_token']);
            return $this->successReturn('修改成功,请重新登录');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 重置交易密码
     * @return string|\think\response\Json
     */
    public function savePayPassword(){
        try {
            $check_mobile = json_decode($this->checkBindMobile(), true);
            if ($check_mobile['code'] != 1) {
                return $this->failReturn($check_mobile['message']);
            }
            $user = memberModel::findOne(['id' => $this->user['id']]);
            if (!array_key_exists('password', $this->requestData) || empty($this->requestData['password']))
                return $this->failReturn('新密码必填');
            $this->memberEntity->setUePayPsw($this->requestData['password']);
            if ($this->memberEntity->getUePayPsw() !== $this->requestData['en_password'])
                return $this->failReturn('两次密码不一致');
            $data['ue_pay_psw'] = md5(md5($this->memberEntity->getUePayPsw()) . config('app.salf'));
            $res = memberModel::updateDatas($data, ['id' => $user['id']]);
            if (!$res)
                return $this->failReturn('修改失败');
            return $this->successReturn('修改成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 获取用户资料
     * @return string|\think\response\Json
     */
    public function getDetail(){
        try {
            $user = memberModel::findOne(['id' => $this->user['id']]);
            if (!$user)
                return $this->failReturn('用户信息不存在');
            unset($user['ue_password']);
            unset($user['ue_pay_psw']);
            //$user['ue_phone'] = encryptTel($user['ue_phone']);
            return $this->successReturn('获取数据成功', $user);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 获取我的推荐码
     * @return string
     */
    public function getSpread(){
        try{
            $config = configModel::tpCache('base');
            $download_url = $config['download_url'];
            QRcode::png($download_url, false, 'M', 8, 1, true);
            $content = ob_get_contents();
            ob_end_clean();
            $data['qrcode_url'] = "data:image/jpeg;base64," . base64_encode($content);
            $data['code'] = $this->user['code'];
            return $this->successReturn('获取数据成功', $data);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 编辑用户信息
     * @return string|\think\response\Json
     */
    public function saveProfile(){
        try {
            if (array_key_exists('avatar', $this->requestData)) {
                if (empty($this->requestData['avatar'])) {
                    return $this->failReturn('头像不能为空');
                }
                $this->memberEntity->setAvatar($this->requestData['avatar']);
            }
            if (array_key_exists('nickname', $this->requestData)) {
                if (empty($this->requestData['nickname'])) {
                    return $this->failReturn('昵称不能为空');
                }
                $this->memberEntity->setUeName($this->requestData['nickname']);
            }
            $data = $this->memberEntity->params();
            if (empty($data))
                return $this->failReturn('未进行任何修改');
            $map = ['id' => $this->user['id']];
            $res = memberModel::updateDatas($data, $map);
            if (!$res)
                return $this->failReturn('修改失败');
            return $this->successReturn('修改成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 获取用户解冻列表
     * @return string|\think\response\Json
     */
    public function memberThaw(){
        try{
            if (!array_key_exists('page', $this->requestData)||empty($this->requestData['page']))
                $this->requestData['page'] = 1;
            if (!array_key_exists('page_size', $this->requestData)||empty($this->requestData['page_size']))
                $this->requestData['page_size'] = 10;
            $limit = ($this->requestData['page'] - 1) * $this->requestData['page_size'];

            $list = memberThawModel::getPageList($this->user['id'],$limit);
            return $this->successReturn('获取数据成功',$list);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 获取我的好友
     */
    public function getMyFriends(){
        try{
            $ordinary = memberModel::countData(['pid'=>$this->user['id'],'p_num'=>0],'id');
            $vip = memberModel::countData("pid={$this->user['id']} and p_num > 0",'id');
            $team = memberModel::getTeamCount($this->user['id']);
            if (!array_key_exists('page', $this->requestData)||empty($this->requestData['page']))
                $this->requestData['page'] = 1;
            if (!array_key_exists('page_size', $this->requestData)||empty($this->requestData['page_size']))
                $this->requestData['page_size'] = 10;
            $limit = ($this->requestData['page'] - 1) * $this->requestData['page_size'];
            $list = memberModel::getPushPageList($this->user['id'],$limit);
            foreach ($list as $k => &$val){
                $val['ue_phone'] = encryptTel($val['ue_phone']);
            }
            $data = [
                'ordinary_count'=>$ordinary,
                'vip_count'=>$vip,
                'team_count'=>$team,
                'list'=>$list,
            ];
            return $this->successReturn('获取数据成功',$data);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 解冻账号
     * @return string|\think\response\Json
     */
    public function doMemberThaw(){
        try{
            if (!array_key_exists('thaw_id', $this->requestData)||empty($this->requestData['thaw_id']))
                return $this->failReturn('数据无效');
            $thaw = memberThawModel::findOne(['id'=>$this->requestData['thaw_id'],'user_id'=>$this->user['id']]);
            if(!$thaw)
                return $this->failReturn('数据无效');
            if($thaw['status']!=1)
                return $this->failReturn('数据无效');
            $user = memberModel::findOne(['id'=>$this->user['id']]);
            if($user['ue_pdc']<$thaw['thaw_money'])
                return $this->failReturn('用户余额不足');
            Db::startTrans();
            $res1 = memberModel::where(['id'=>$this->user['id']])->setDec('ue_pdc',$thaw['thaw_money']);
            $res2 = memberModel::updateDatas(['ue_status'=>0],['id'=>$this->user['id']]);
            $res3 = memberThawModel::updateDatas(['status'=>2],['id'=>$this->requestData['thaw_id'],'user_id'=>$this->user['id']]);
            $res4 = userMinutiaeModel::addMinutiaeLog($this->user['id'],$res3['id'],2,11,$thaw['thaw_money'],2);
            $res = $res1&&$res2&&$res3&&$res4;
            if($res){
                Db::commit();
                return $this->successReturn('解冻成功');
            }
            Db::rollback();
            return $this->failReturn('解冻失败');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 发送验证码
     */
    public function validatePhone(){
        try{
            if (!array_key_exists('phone', $this->requestData)||empty($this->requestData['phone'])) {
                return $this->failReturn('请填写手机号码');
            }
            if (!checkMobile($this->requestData['phone'])) {
                return $this->failReturn('手机号码格式不正确');
            }
            $code = mt_rand(100000,999999);
            $config = configModel::tpCache('sms');
            $code_expire = $config['code_expire']*60;
            $sms_config['accessKeyId'] = $config['accessKeyId'];
            $sms_config['accessKeySecret'] = $config['accessKeySecret'];
            $client  = new Client($sms_config);
            $sendSms = new SendSms;
            $sendSms->setPhoneNumbers($this->requestData['phone']);

            $template = smsTempModel::findOne(['cat_id'=>1,'status'=>1]);
            $sendSms->setSignName($template['sign_name']);
            $sendSms->setTemplateCode($template['template_code']);
            $sendSms->setTemplateParam(['code' => "{$code}"]);
            $res = $client->execute($sendSms);
            if($res->Code=="OK") {
                Cache::set($this->requestData['phone'], $code, $code_expire);
                return $this->successReturn('发送成功');
            }
            return $this->failReturn('发送失败:错误码（'.$res->Code.'）,错误信息'.$res->Message);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    /**
     * 验证手机
     * @return string|\think\response\Json
     */
    public function checkBindMobile($prefix='',$is_new=false){
        try {
            if (!array_key_exists('phone', $this->requestData)||empty($this->requestData['phone'])) {
                return $this->failReturn('请填写手机号码');
            }
            if (!checkMobile($this->requestData['phone'])) {
                return $this->failReturn('手机号码格式不正确');
            }
            if(!array_key_exists('code',$this->requestData)||empty($this->requestData['code']))
                return $this->failReturn('验证码不能为空');
//            if(Cache::get($prefix.$this->requestData['phone'])!=$this->requestData['code'])
//                return $this->failReturn('验证码无效');
            $this->memberEntity->setUePhone($this->requestData['phone']);
            if(empty($this->user)){
                $user = memberModel::findOne(['ue_phone' => $this->requestData['phone']]);
                if ($user['ue_phone'] != $this->memberEntity->getUePhone()&&!$is_new)
                    return $this->failReturn('手机号码非绑定号码');
                if ($user['ue_phone'] == $this->memberEntity->getUePhone()&&$is_new)
                    return $this->failReturn('手机号码已被注册');
            }else{
                $user = memberModel::findOne(['id' => $this->user['id']]);
                if ($user['ue_phone'] != $this->memberEntity->getUePhone())
                    return $this->failReturn('手机号码非绑定号码');
            }
            return $this->successReturn('验证成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }
}