<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;

class Config extends Base
{
    //配置数据界面
    public function index(){
        $type = input('type');
        switch ($type) {
            case 1:
                $inc_type = "base";
                break;
            case 2:
                $inc_type = "jin";
                break;
            case 3:
                $inc_type = "withdraw";
                break;
            default:
                $this ->error("类型错误");
                break;
        }
        $list = Db::name('config') ->where("inc_type",$inc_type) ->select();
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    //执行配置设置
    public function setConfig(){
        $list = input('post.');
        // 启动事务
        Db::startTrans();
        try{
            foreach ($list as $k => $v) {
                if(!is_numeric($v)){
                    exit($this->ajaxReturn([],0,"请填写数字"));
                }
                Db::name('config') ->where(['id'=>$k]) ->update(['value'=>$v]);
            }
            Db::commit();
            exit($this->ajaxReturn([],1,'配置成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($this->ajaxReturn([],0,$e->getMessage()));
        }
    }
}
