<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use app\common\logic\User as userLogic;
use app\common\model\User as userModel;
use app\common\model\Role as roleModel;
use think\App;
use think\Controller;
use think\facade\Config;
use think\facade\Env;
use think\facade\Request;

class User extends Base
{
    protected $userLogic;
    public function __construct(App $app = null)
    {
        parent::__construct($app);
        $this->userLogic = new userLogic();
    }

    public function index(){
        $res = $this->userLogic->getPageList();
        $this->assign($res);
        $this->assign('empty','<tr><td colspan="6"></td></tr>');
        echo $this->fetch();
    }

    public function add(){
        if($this->request->isPost()){
            exit($this->userLogic->saveData());
        }
        $roleData = roleModel::select();
        $this->assign(['roleData'=>$roleData]);
        echo $this->fetch('edit');
    }

    public function upd($user_id){
        if($this->request->isPost()){
            exit($this->userLogic->saveData());
        }
        $userData = userModel::findOne(['user_id'=>$user_id]);
        $roleData = roleModel::select();
        $this->assign(['roleData'=>$roleData,'userData'=>$userData]);
        echo $this->fetch('upd');
    }

    public function del(){
        exit($this->userLogic->del());
    }

    public function updateStatus(){
        exit($this->userLogic->updateStatus());
    }
}