<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;

class Blacklist extends Base
{
    //拉黑列表
    public function index(){
        $list = Db::name('blacklist') ->where(["is_del"=>0]) ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    //添加拉黑界面
    public function addBlacklist(){
        return $this ->fetch();
    }

    //执行添加拉黑操作
    public function doAddBlacklist(){
        $data = input('post.');

        $this ->valiBlacklist($data);
        $data['block_at'] = time();
        $res = Db::name('blacklist') ->insert($data);
        if($res){
            exit($this->ajaxReturn([],1,"添加成功"));
        }else{
            exit($this->ajaxReturn([],0,"添加失败"));
        }

    }

    //删除操作
    public function doDelBlacklist(){
        $id = input("post.id");
        if(!is_numeric($id)){
            exit($this->ajaxReturn([],0,"参数错误"));
        }
        $is_del = Db::name('blacklist') ->where('id',$id) ->update(['is_del'=>1]);
        if($is_del){
            exit($this->ajaxReturn([],1,"删除成功"));
        }else{
            exit($this->ajaxReturn([],0,"删除失败"));
        }
    }

    //修改拉黑界面
    public function updBlacklist(){
        $id = input("get.id");
        if(!is_numeric($id)){
            exit($this->ajaxReturn([],0,"参数错误"));
        }
        $data = Db::name('blacklist') ->where(['id'=>$id,'is_del'=>0]) ->find();
        if(empty($data)){
            exit($this->ajaxReturn([],0,"数据获取失败"));
        }
        $this ->assign("data",$data);
        return $this ->fetch();
    }

    //执行修改拉黑
    public function doUpdBlacklist(){
        $data = input("post.");
        if(!is_numeric($data['id'])){
            exit($this->ajaxReturn([],0,"参数错误"));
        }
        $this ->valiBlacklist($data);
        $res = Db::name('Blacklist') ->where(['id'=>$data['id']]) ->update($data);
        if($res !== false){
            exit($this->ajaxReturn([],1,"修改成功"));
        }else{
            exit($this->ajaxReturn([],0,"修改失败"));
        }
    }

    //验证对应拉黑号
    private function valiBlacklist($data){
        switch ($data['type']) {
            case '1':
                if(!preg_match("/^\d{5,12}$/isu",$data['block_no'])){
                    exit($this->ajaxReturn([],0,"请填写QQ"));
                }
                break;
            case '2':
                if(!preg_match("/^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@([a-zA-Z0-9]+[-.])+([a-z]{2,5})$/ims",$data['block_no'])){
                    exit($this->ajaxReturn([],0,"请填写邮箱"));
                }
                break;
            case '3':
                if(!preg_match("/^1[34578]\d{9}$/",$data['block_no'])){
                    exit($this->ajaxReturn([],0,"请填写手机号"));
                }
                break;
            default:
                exit($this->ajaxReturn([],0,"参数错误"));
        }
    }
}