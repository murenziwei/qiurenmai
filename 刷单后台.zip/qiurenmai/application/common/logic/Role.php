<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/29
 * Time: 19:37
 */

namespace app\common\logic;

use app\common\model\Role as roleModel;
use app\common\model\Auth as authModel;
use app\common\entity\Role as roleEntity;
use app\common\BaseModel;
use think\Db;

class Role extends BaseModel
{
    protected $roleEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->roleEntity = new roleEntity();
    }

    public function updateStatus(){
        $this->roleEntity->setRoleId($this->requestData['role_id']);
        $info = roleModel::findOne($this->roleEntity->params());
        if(!$info)
            return $this->failReturn('数据不存在');
        if($info['status']==1){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        $res = roleModel::updateDatas($data,$this->roleEntity->params());
        if(!$res)
            return $this->failReturn('修改失败');
        return $this->successReturn('修改成功');
    }

    public function del(){
        if(!array_key_exists('role_id',$this->requestData)&&!empty($this->requestData['role_id']))
            return $this->failReturn('请选择角色');
        if(!is_array($this->requestData['role_id'])){
            $res = roleModel::deleteByKey(['role_id'=>$this->requestData['role_id']]);
        }else{
            $res = Db::table('__ROLE__')->delete($this->requestData['role_id']);
        }
        if ($res) {
            return $this->successReturn('删除成功');
        } else {
            return $this->failReturn('删除失败');
        }
    }

    public function saveData(){
        if(!array_key_exists('auth_id_list',$this->requestData))
            return $this->failReturn('请选择权限');
        $auth_id_list = implode(',', $this->requestData['auth_id_list']);
        if(!array_key_exists('role_name',$this->requestData))
            return $this->failReturn('角色名称不能为空');
        if(!array_key_exists('status',$this->requestData))
            $this->roleEntity->setStatus(1);
        else
            $this->roleEntity->setStatus($this->requestData['status']);
        $ids = authModel::where('auth_id','in',$this->requestData['auth_id_list'])->field('pid')->select()->toArray();
        $pids = array_column($ids,'pid');
        $pids = array_unique($pids);
        //
        $ids_1 = authModel::where('auth_id','in',$pids)->field('pid')->select()->toArray();
        $pids_1 = array_column($ids_1,'pid');
        $pids_1 = array_unique($pids_1);
        $this->requestData['auth_id_list'] = array_merge($this->requestData['auth_id_list'],$pids,$pids_1);
        $auth_id_list = implode(',', $this->requestData['auth_id_list']);
        $this->roleEntity->setAuthIdList($auth_id_list);
        $this->roleEntity->setRoleName($this->requestData['role_name']);
        if(array_key_exists('remake',$this->requestData)&&!empty($this->requestData['remake']))
            $this->roleEntity->setRemake($this->requestData['remake']);
        if(array_key_exists('role_id',$this->requestData)&&!empty($this->requestData['role_id']))
            $res = roleModel::updateDatas($this->roleEntity->params(),['role_id'=>$this->requestData['role_id']]);
        else
            $res = roleModel::createData($this->roleEntity->params());
        if(!$res)
            return $this->failReturn('操作失败');
        return $this->successReturn('操作成功');
    }
}