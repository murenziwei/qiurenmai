<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/8
 * Time: 15:34
 */

namespace app\common\entity;


class Role extends BaseEntity
{
    public $role_id;
    public $role_name;
    public $auth_id_list;
    public $type;
    public $remake;
    public $status;

    /**
     * @return mixed
     */
    public function getRoleId()
    {
        return $this->role_id;
    }

    /**
     * @param mixed $role_id
     * @return Role
     */
    public function setRoleId(int $role_id)
    {
        $this->role_id = $role_id;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getRoleName()
    {
        return $this->role_name;
    }

    /**
     * @param mixed $role_name
     * @return Role
     */
    public function setRoleName(string $role_name)
    {
        $this->role_name = $role_name;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getAuthIdList()
    {
        return $this->auth_id_list;
    }

    /**
     * @param mixed $auth_id_list
     * @return Role
     */
    public function setAuthIdList(string $auth_id_list)
    {
        $this->auth_id_list = $auth_id_list;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param mixed $type
     * @return Role
     */
    public function setType(int $type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getRemake()
    {
        return $this->remake;
    }

    /**
     * @param mixed $remake
     * @return Role
     */
    public function setRemake(string $remake)
    {
        $this->remake = $remake;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus(int $status)
    {
        $this->status = $status;
    }


}