<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/20
 * Time: 20:12
 */

namespace app\common\logic;

use app\common\BaseModel;
use app\common\model\Member as memberModel;
use think\Db;

class Hosting extends BaseModel
{

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }
    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){
        $map = "1=1";
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->memberEntity->setPhone($this->requestData['search']);
            $this->memberEntity->setSerialNo($this->requestData['search']);
            $map = "(phone like '%{$this->requestData['search']}%' OR serial_no like '%{$this->requestData['search']}%')";
        }
        if(isset($this->requestData['remake'])&&!empty($this->requestData['remake'])){
            $this->memberEntity->setRemake($this->requestData['remake']);
            if($map=="1=1"){
                $map = "remake like '%{$this->requestData['remake']}%'";
            }else{
                $map .= " AND remake like '%{$this->requestData['remake']}%'";
            }
        }
        $list = Db::table('tp_utrusteeship')->paginate(10);
//        $list->each(function($item,$key){
//            $info = memberModel::findOne(['id'=>$item['u_id']],'id,nickname,phone');
//            $item['u_nickname'] = !$info?'':$info['nickname'];
//            $item['u_phone'] = !$info?'':$info['phone'];
//            $info1 = memberModel::findOne(['id'=>$item['us_id']],'id,nickname,phone');
//            $item['us_nickname'] = !$info1?'':$info1['nickname'];
//            $item['us_phone'] = !$info1?'':$info1['phone'];
//        });
        $count = $list->total();
        $page = $list->render();
        if(!empty($list))
            $list = $list->toArray();
        else
            return ['list'=>[],'count'=>$count,'page'=>$page];
        $list = $list['data'];
        foreach ($list as $k => &$val){
            $info = memberModel::findOne(['id'=>$val['uid']],'id,nickname,phone');
            $val['u_nickname'] = !$info?'':$info['nickname'];
            $val['u_phone'] = !$info?'':$info['phone'];
        }
        return ['list'=>$list,'count'=>$count,'page'=>$page];
    }
}