<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-05 11:20:34
 */
namespace app\api\controller;

use think\Db;
use app\api\model\Config as ConfigModel;
use app\api\model\Member as MemberModel;
use app\api\model\Minutiae;
use app\api\validate\OrderImg;
use app\api\model\Task as TaskModel;

class Dotask extends Base
{
    //任务列表
    public function filtTask(){
        $data = input();
        $where = [];
        //选择平台
        if(!empty($data['task_type']) && is_numeric($data['task_type'])){
          $where[] = ['t1.task_type','eq',$data['task_type']];
       }
        if(!empty($data['platform_type']) && is_numeric($data['platform_type'])){
          $where[] = ['t1.platform_type','eq',$data['platform_type']];
       }
       $list = Db::name("task") ->alias("t1")
                        ->join("sd_task_goods_info t3","t1.id=t3.task_id")
                        ->where(["t1.is_recall"=>0])
                         ->where($where)
                         ->where("exists(SELECT t2.real_commission from sd_son_task t2 where t2.task_id=t1.id AND t2.status=1)")
                         ->order("t1.is_top desc,t1.id desc")//置顶
                        ->field("t1.id,t1.task_num,t1.shop_wang_id,t3.goods_count,t1.every_cash_pledge,t1.task_num,t1.every_commission")
                        ->paginate(config("app.page_num"))
                        ->toArray();
        $user_id = $this ->user["id"];
        foreach($list["data"] as &$v){
            $count = Db::name("son_task") ->where(["task_id"=>$v["id"]]) ->where("status","neq",1) ->count();
             $v["real_commission"] = Db::name("son_task") ->where(["task_id"=>$v["id"]]) ->value("real_commission");
             $is_accept = Db::name("son_task") ->where(["task_id"=>$v["id"],"user_id"=>$user_id]) ->find();
            if(empty($is_accept)){
                $v["status"] = 0;
            }else{
                $v["status"] = 1;
            }
            $v["take_rate"] = (int)(($v["task_num"] - $count)/$v["task_num"]*100)."%";
        }
        exit(ajaxReturn($list,1,'获取数据成功'));
    }

    //接取任务
    public function takeTask(){
        $task_id = input("id");
        $wang_id = input("wang_id");
        if(!is_numeric($task_id) || empty($wang_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $son_task = Db::name("son_task") ->where(["task_id"=>$task_id,"status"=>1]) ->field("id,shop_id,task_type,shop_wang_id,task_id,goods_info_id") ->find();
        if(empty($son_task)){
            exit(ajaxReturn([],0,'子任务未找到'));
        }
        $conf = ConfigModel::getConf("buy");
        //判断是否有条件可以接
        $this ->isTake($son_task,$conf,$wang_id);
        $user_id = $this ->user["id"];
        Db::startTrans();
        try{

            $after_num = MemberModel::afterRes($user_id,$conf["take_deposit"],2,"commission");
            //写记录
            Minutiae::insertMinu($user_id,10,'接单扣除佣金,任务ID:'.$son_task["id"],-$conf["take_deposit"],$after_num,2,2);
            //浏览任务不生成订单详情
            if($son_task["task_type"] != 5){
                $this ->insertOrder($son_task["shop_wang_id"],$wang_id,$son_task["goods_info_id"],"","",$son_task["id"],$son_task["shop_id"]);
            }

            $res = Db::name("son_task") ->where(["id"=>$son_task["id"],"status"=>1]) ->update(["user_id"=>$user_id,"accept_at"=>time(),"wangwang_id"=>$wang_id,"status"=>2]);
            if($res){
                Db::commit();
                exit(ajaxReturn([],1,'接单成功'));
            }else{
                exit(ajaxReturn([],0,'接单失败'));
            }
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }
    //订单表插入
    private function insertOrder($shop_id,$buy_id,$goods_id,$tao_order_no,$post_no,$task_id,$user_id){
        $data = ["shop_id"=>$shop_id,"buy_id"=>$buy_id,"goods_id"=>$goods_id,"create_at"=>time(),"tao_order_no"=>$tao_order_no,"post_no"=>$post_no,"task_id"=>$task_id,"user_id"=>$user_id];
        Db::name("order") ->insert($data);
    }

    //判断是否有条件可以接
    private function isTake($son_task,$conf,$wang_id){
        //判断他手头没任务
        $user_id = $this ->user["id"];
        $type = Db::name("member") ->where(["id"=>$user_id]) ->value("type");
        if($type != 2){
            exit(ajaxReturn([],0,'身份不是买手'));
        }
        $is_free = Db::name("son_task") ->where(["user_id"=>$user_id]) ->where("status","between","1,3") ->find();
        if(!empty($is_free)){
            exit(ajaxReturn([],0,'手头还有任务未完成'));
        }

        //是否被拉黑
        $is_block = Db::name("blacklist") ->where(["user_id"=>$son_task["shop_id"],"block_id"=>$user_id,"is_del"=>0]) ->find();
        if(!empty($is_block)){
            exit(ajaxReturn([],0,'你已被该商家拉黑'));
        }
        //不是浏览任务，要限制单数

        if($son_task["task_type"] != 5){
            $count = Db::name("son_task") ->where(["user_id"=>$user_id]) ->whereTime('accept_at', 'week') ->count();
            if($son_task["task_type"] == 4){
                //拼多多
                $line = $conf["pin_task_count"];
            }else{
                //淘宝
                $line = $conf["tao_task_count"];
            }
            if($count >= $line){
                exit(ajaxReturn([],0,'已超过次数'));
            }
        }
        //商家设置的接单间隔
        $interval = Db::name("bind_shop") ->where(["wangwang_id"=>$son_task["shop_wang_id"]]) ->value("take_interval");
        if(empty($interval)){
            exit(ajaxReturn([],0,'商家间隔未找到'));
        }
        $is_recent = Db::name("son_task") ->where(["user_id"=>$user_id,"shop_wang_id"=>$son_task["shop_wang_id"]]) ->where("accept_at","egt",time()-$interval)->find();
        if(!empty($is_recent)){
            exit(ajaxReturn([],0,'近期已接过该商家的单'));
        }
        //千人千面
        $buy_no = Db::name("bind_buy_no") ->where(["wang_id"=>$wang_id,"user_id"=>$user_id,"status"=>1]) ->field("province,sex,platform_type,is_level") ->find();
        if(empty($buy_no)){
            exit(ajaxReturn([],0,'未找到旺旺信息'));
        }
        $restrict = Db::name("task") ->where(["id"=>$son_task["task_id"]]) ->field("restrict_area,restrict_sex,restrict_level,platform_type") ->find();
        if(empty($restrict)){
            exit(ajaxReturn([],0,'未找到主任务'));
        }
        if($restrict["platform_type"] != $buy_no["platform_type"]){
            exit(ajaxReturn([],0,'平台不符合'));
        }
        //性别
        if($restrict["restrict_sex"] != 0 && $buy_no["sex"] != $restrict["restrict_sex"]){
            exit(ajaxReturn([],0,'因性别限制接不了任务'));
        }
        //钻级别
        if($restrict["restrict_level"] == 1 && $buy_no["is_level"] == 0){
            exit(ajaxReturn([],0,'只有钻级别才能截取'));
        }
        //区域限制
        $area = explode(",",$restrict["restrict_area"]);
        if(in_array($buy_no["province"],$area)){
            exit(ajaxReturn([],0,'因区域限制接不了任务'));
        }

    }

    //刷手放弃订单
    public function abandonTask(){
        $son_task_id = input("id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];

        Db::startTrans();
        try{
            Minutiae::platformFlow(1,$user_id,$son_task_id,6,2);
            $res = Db::name("son_task") ->where(["id"=>$son_task_id,"status"=>2,"user_id"=>$user_id]) ->update(["status"=>1,"user_id"=>'']);
            if($res){
                Db::commit();
                exit(ajaxReturn([],1,'放弃成功'));
            }else{
                exit(ajaxReturn([],0,'放弃失败'));
            }
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
    }

    //任务流程动态数据
    public function taskData(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $data = Db::name("son_task") ->alias("t1")
                                     ->join("sd_task t2","t1.task_id=t2.id")
                                     ->join("sd_task_goods_info t4","t1.goods_info_id=t4.id")
                                     ->where(["t1.id"=>$son_task_id,"t1.user_id"=>$user_id])
                                     ->field("t1.is_wait_sale,t1.status,t1.id,t1.wangwang_id,t1.task_type,t1.real_commission,t2.platform_type,t2.explain,t2.shop_wang_id,t2.is_favorites,t2.is_shopping_trolley,t4.goods_name,t4.goods_count,t4.show_price,t4.searh_start_price,t4.searh_end_price,t4.goods_location,t4.goods_img,t4.real_price,t4.goods_img,t1.comment_info_id")
                                     ->find();

        if(empty($data)){
            exit(ajaxReturn([],0,'获取失败'));
        }
        $comment_info = Db::name("task_comment_info") ->where(["id"=>$data["comment_info_id"]]) ->field("than_word,search_word,specification") ->find();
        $shop_name = Db::name("bind_shop") ->where(["wangwang_id"=>$data["shop_wang_id"]]) ->value("shop_name");

        exit(ajaxReturn(compact('data','comment_info','shop_name'),1,'获取成功'));
    }
    //等待预售时间下单
    public function toWaitSelf(){
        $data = input("post.");
        if(!isset($data["task_id"]) || !is_numeric($data["task_id"])){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $validate = new OrderImg();
        if (!$validate ->scene("wait") ->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $user_id = $this ->user["id"];
        Db::startTrans();
        try{

            $res = Db::name("son_task") ->where(["id"=>$data["task_id"],"user_id"=>$user_id,"status"=>2,"task_type"=>3]) ->update(["is_wait_sale"=>1]);
            if($res){
                unset($data["access_token"]);
                Db::name("task_imgs") ->insert($data);
                Db::commit();
                exit(ajaxReturn([],1,'操作成功'));
            }else{
                exit(ajaxReturn([],0,'操作失败'));
            }

        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //下单上传截图
    public function uploadImgs(){
        $data = input("post.");

        if(!isset($data["task_id"]) || !is_numeric($data["task_id"])){
            exit(ajaxReturn([],0,'参数有误'));
        }

        $user_id = $this ->user["id"];
        $task_type = Db::name("son_task") ->where(["id"=>$data["task_id"],"user_id"=>$user_id,"status"=>2]) ->value("task_type");
        if(empty($task_type)){
            exit(ajaxReturn([],0,'获取任务失败'));
        }
        $validate = new OrderImg();
        if (!$validate ->scene("type".$task_type) ->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        if($task_type == 5){
            $status = 5;
        }else{
            $status = 3;
        }
        Db::startTrans();
        try{
            Db::name("order") ->where(["task_id"=>$data["task_id"]]) ->update(["tao_order_no"=>$data["order_no"]]);
            Db::name("son_task") ->where(["id"=>$data["task_id"]]) ->update(["status"=>$status,"real_pay"=>$data["real_pay"]]);
            unset($data["access_token"]);
            unset($data["order_no"]);
            unset($data["real_pay"]);
            $data["create_at"] = time();
            if($task_type == 3){
                Db::name("task_imgs") ->where(["task_id"=>$data["task_id"]]) ->update($data);
            }else{
                Db::name("task_imgs") ->insert($data);
            }

            Db::commit();
            exit(ajaxReturn([],1,'操作成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //评论
    public function doComment(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $data = Db::name("son_task") ->alias("t1")
                             ->join("sd_task_comment_info t2","t1.comment_info_id=t2.id")
                             ->where(["t1.id"=>$son_task_id,"t1.user_id"=>$user_id])
                             ->field("t1.id,t1.wangwang_id,t1.status,t2.type,t2.comment_ask,t2.imgs,t2.video")
                             ->find();
        $data["imgs"] = explode(",",$data["imgs"]);
        if(empty($data)){
            exit(ajaxReturn([],0,'获取成功'));
        }
        exit(ajaxReturn($data,1,'获取成功'));
    }

    //确定评论
    public function confComment(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $res = Db::name("son_task") ->where(["id"=>$son_task_id,"user_id"=>$user_id,"status"=>4]) ->update(["status"=>5,"comment_at"=>time()]);
        if($res){
             exit(ajaxReturn([],1,'确认成功'));
        }else{
             exit(ajaxReturn([],0,'确认失败'));
        }
    }
}