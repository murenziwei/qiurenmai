<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-06-17 16:28:38
 */
namespace app\api\controller;

use think\Db;
use app\api\Validate\Task as TaskVali;
use app\api\Validate\Goods as GoodsVali;
use app\api\Validate\Comment as CommentVali;
use app\api\Validate\SendPlan as SendPlanVali;
use app\api\Validate\EmptyPar as EmptyParVali;
use app\api\Validate\CalendarPar as CalendarParVali;
use app\api\model\Config as ConfigModel;
use app\api\model\Minutiae;
use app\api\model\Member as MemberModel;

class Task extends Base
{
    public function tst(){
        return $this ->user["id"];
    }
    //添加任务
    public function addTask(){
        $data = input("data");
        $data = json_decode($data,true);
        //halt($data);
        $this ->insertTaskInfo($data);
    }

    //支付
    public function payTask(){
        //任务id
        $id = input("get.id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $user_id = $this ->user["id"];
        $sum_fee = Db::name("task") ->where(["id"=>$id,"user_id"=>$user_id,"is_pay"=>0]) ->value("sum_fee");
        if(empty($sum_fee)){
            exit(ajaxReturn([],0,"花费获取失败"));
        }

        Db::startTrans();
        try{
            $after_num = MemberModel::afterRes($user_id,$sum_fee,0);
            Db::name("task") ->where(["id"=>$id]) ->update(["is_pay"=>1]);
            //写记录
            Minutiae::insertMinu($user_id,1,"支付任务,任务编号：".$id,-$sum_fee,$after_num);
            Db::commit();
            exit(ajaxReturn([],1,'支付成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }
    //任务插入私类
    private function insertTaskInfo($data){

        //判断预售任务有没有预售时间
        if($data["task"]["task_type"] == 3 && !isset($data["task"]["wait_sell_at"])){
            exit(ajaxReturn([],0,"预售任务有没有预售时间"));
        }
        //判断用户名下是否有这个店铺
        $user_id = $this ->user["id"];
        $this ->valiShop($data);

        //----------------------------开始验证------------------------------
        //任务信息
        $validate = new TaskVali();
        if (!$validate->check($data["task"])) {
            exit(ajaxReturn([],0,$validate->getError()));
        }


        //商品
        $validate = new GoodsVali();
        if (!$validate->check($data["goods"])) {
            exit(ajaxReturn([],0,$validate->getError()));
        }

        //空包服务
        if(array_key_exists("empty_parcel_serve",$data["task"])){
            $validate = new EmptyParVali();
            if (!$validate ->check($data["task"]["empty_parcel_serve"])) {
                exit(ajaxReturn([],0,$validate->getError()));
            }
        }

        //配置信息
        $conf = ConfigModel::getConf("jin");
        //计算每单花费与本金
        $calculateRes = $this ->calculateFee($conf,$data);

        $data["task"]["task_num"] = 0;
        $comment_fee = 0;

        if($data["task"]["task_type"] == 5 && array_key_exists("browse_calendar",$data)){
            //任务日程表
            $validate = new CalendarVali();
            foreach($data["browse_calendar"] as &$v){
                if (!$validate->check($v)) {
                    exit(ajaxReturn([],0,$validate->getError()));
                }
                $v["task_num"] = 0;
                for($i = 0;$i < $v["day_count"];$i++){
                    foreach($v["calendar"] as $sk => $sv){
                        if(!is_numeric($sk) || !is_numeric($sv) || $sk > 23){
                            exit(ajaxReturn([],0,"日程表格式错误"));
                        }
                        //每个日程表单数
                        $v["task_num"] += $sv;
                        //任务总数
                        $data["task"]["task_num"] += $sv;
                        //累加好评花费
                        $calculateRes["sum_fee"] += ($conf["browse_task_fee"] * $sv["task_num"]);
                    }
                }
                if($v["task_num"] == 0){
                    exit(ajaxReturn([],0,"每个日程表单数不能为0"));
                }
                $v["calendar"] = json_encode($v["calendar"]);
            }
        }elseif($data["task"]["task_type"] != 5 && array_key_exists("comment",$data)){
            //评论配置
            $validate = new CommentVali();
            foreach($data["comment"] as $k => $v){
                //好评部分
                switch ($k) {
                    case 1://普通好评
                        $scene = "common";
                        break;
                    case 2://文字好评
                        $scene = "word";
                        break;
                    case 3://图片好评
                        $scene = "img";
                        break;
                    case 4://视频好评
                        $scene = "video";
                        break;
                    default:
                        exit(ajaxReturn([],0,"好评类型错误"));
                        break;
                }
                foreach ($v as $sk => $sv) {
                    if (!$validate->scene($scene)->check($sv)) {
                        exit(ajaxReturn([],0,$validate->getError()));
                    }
                    //任务总数
                    $data["task"]["task_num"] ++;
                    //累加好评花费
                    $comment_fee += ($conf[$scene."_comment"]);
                }
            }
        }else{
             exit(ajaxReturn([],0,"任务设置参数错误"));
        }
        //如果任务单数等于0
        if($data["task"]["task_num"] == 0){
            exit(ajaxReturn([],0,"任务单数不能为0"));
        }

        if($data["task"]["task_type"] == 1 || $data["task"]["task_type"] == 2){
            //放出计划
            if(array_key_exists("plan",$data["task"])){
                //放出计划数量
                $send_plan_count = 0;

                $validate = new SendPlanVali();
                foreach($data["task"]["plan"] as $k => $v){
                    if (!$validate ->check($v)) {
                        exit(ajaxReturn([],0,$validate->getError()));
                    }
                    $send_plan_count += $v["task_num"];
                }
                //检查计划数量是否与评论要求数量一致
                if($data["task"]["task_num"] != $send_plan_count){
                    exit(ajaxReturn([],0,"计划与评论要求数量不一致"));
                }
            }
        }


        //----------------------------结束验证------------------------------

        //插入
        Db::startTrans();
        try{
            //算总花费
            $data["task"]["every_cash_pledge"] = $calculateRes["cash_pledge"];
            $data["task"]["every_commission"] = $calculateRes["every_commission"];
            $data["task"]["add_service_fee"] = $calculateRes["add_service_fee"];
            $data["task"]["cash_pledge"] = $calculateRes["cash_pledge"] * $data["task"]["task_num"];
            $data["task"]["sum_fee"] = $calculateRes["sum_fee"] * $data["task"]["task_num"] + $conf["send_fee"] + $comment_fee;
            //置顶
            $top_fee = 0;
            if(array_key_exists("is_top",$data["task"]) && $data["task"]["is_top"]){
                $data["task"]["sum_fee"] += $conf["task_top"];
                $top_fee = $conf["task_top"];
            }
            $data["task"]["create_at"] = time();
            $data["task"]["user_id"] = $user_id;
            //halt($calculateRes["sum_fee"].'/'.$data["task"]["task_num"].'/'.$conf["send_fee"].'/'.$comment_fee);
            $task_id = $this ->insertTask($data);

            //费用详情
            $this ->insertFeeInfo($task_id,$calculateRes["thousand_fee"],$calculateRes["platform_fee"],$calculateRes["empty_parcel_fee"],$calculateRes["favorites_fee"],$calculateRes["add_fee"],$top_fee);

            $data["goods"]["create_at"] = time();
            $data["goods"]["task_id"] = $task_id;
            Db::name("task_goods_info") ->insert($data["goods"]);

            if($data["task"]["task_type"] == 5){
                foreach($data["browse_calendar"] as $k => &$v){
                    $v["task_id"] = $task_id;
                    for($i = 0;$i < $v["day_count"];$i++){
                        $v["start_at"] += (60*60*24 * $i);
                        Db::name("browse_calendar") ->insert($v);
                    }
                }
            }else{
                foreach($data["comment"] as $k => &$v){
                    foreach ($v as $sk => $sv) {
                        $sv["task_id"] = $task_id;
                        $sv["create_at"] = time();
                        $sv["type"] = $k;
                        Db::name("task_comment_info") ->insert($sv);
                    }
                }
            }

            //空包服务
            if(array_key_exists("empty_parcel_serve",$data["task"])){
                $data["task"]["empty_parcel_serve"]["serve_fee"] = $conf["empty_post"];
                Db::name("empty_parcel_serve") ->insert($data["task"]["empty_parcel_serve"]);
            }

            //不是浏览任务
            if($data["task"]["task_type"] == 1 || $data["task"]["task_type"] == 2){
                //放出计划
                if(array_key_exists("plan",$data["task"])){
                    foreach($data["task"]["plan"] as $k => &$v){
                        $v["task_id"] = $task_id;
                        $v["start_at"] = time();
                        //$v["unsent_task_num"] = $v["task_num"];
                        Db::name("task_send_plan") ->insert($v);
                    }
                }else{
                    $data = ["task_id"=>$task_id,"task_num"=>$data["task"]["task_num"],"start_at"=>time()];
                    //,"unsent_task_num"=>$data["task"]["task_num"]
                    Db::name("task_send_plan") ->insert($data);
                }
            }


            Db::commit();
            exit(ajaxReturn([],1,'提交成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //验证商家
    private function valiShop($data){
        $bind_shop = Db::name("bind_shop") ->where(["user_id"=>$this ->user["id"],"wangwang_id"=>$data["task"]["shop_wang_id"]]) ->field("platform_type") ->find();
        if(empty($bind_shop)){
            exit(ajaxReturn([],0,"店铺旺旺id错误"));
        }
        //判断店铺平台类型是否符合任务平台类型
        if($bind_shop["platform_type"] != $data["task"]["platform_type"]){
            exit(ajaxReturn([],0,"店铺平台类型不符合任务平台类型"));
        }
    }

    private function insertFeeInfo($task_id,$thousand_fee,$platform_fee,$empty_parcel_fee,$favorites_fee,$add_fee,$top_fee){
        $data = ["task_id"=>$task_id,"thousand_fee"=>$thousand_fee,"platform_fee"=>$platform_fee,"empty_parcel_fee"=>$empty_parcel_fee,"favorites_fee"=>$favorites_fee,"add_fee"=>$add_fee,"top_fee"=>$top_fee];
        Db::name("fee_info") ->insert($data);
    }

    //计算每单花费与本金
    private function calculateFee($conf,$data){
        $res = [];
        //本金(每单)
        $res["cash_pledge"] = $data["goods"]["real_price"] * $data["goods"]["goods_count"];
        //如果不包邮
        if(array_key_exists("is_post",$data["goods"]) && $data["goods"]["is_post"] == 0){
            $res["cash_pledge"] += $conf["not_post"];
        }
        //总花费(每单)（加上每单佣金花费）
        $res["every_commission"] = ConfigModel::getCommission($data["task"]["task_type"],$res["cash_pledge"]);
        // $res["sum_fee"] = $res["cash_pledge"] + $res["every_commission"];
        $res["add_fee"] = 0;
        //加赏佣金
        if(array_key_exists("add",$data["task"]) && $data["task"]["add"] != 0){
            //平台先扣除一部分
            $res["add_fee"] = $data["task"]["add"];
            $deduct_add = floor($data["task"]["add"] * ($conf["deduct_add"]/100)*100)/100;
            $add = $data["task"]["add"] - $deduct_add;

            //$res["sum_fee"] += $add;
            $res["every_commission"] += $add;
        }

        $res["platform_fee"] = $conf["send_fee"];
        //空包费用
        $res["empty_parcel_fee"] = 0;
        //空包服务
        if(array_key_exists("empty_parcel_serve",$data["task"])){
            $res["empty_parcel_fee"] = $conf["empty_post"];
        }

        //千人千面
        $res["thousand_fee"] = 0;
        if(array_key_exists("restrict_area",$data["task"])){
            $res["thousand_fee"] += $conf["restrict_area"];
        }
        if(array_key_exists("restrict_sex",$data["task"])){
            $res["thousand_fee"] += $conf["restrict_sex"];
        }
        if(array_key_exists("restrict_level",$data["task"])){
            $res["thousand_fee"] += $conf["restrict_level"];
        }
        //浏览任务
        $res["favorites_fee"] = 0;
        if(array_key_exists("is_favorites",$data["task"])){
            $res["favorites_fee"] += $conf["is_favorites"];
        }
        if(array_key_exists("is_shopping_trolley",$data["task"])){
            $res["favorites_fee"] += $conf["is_shopping_trolley"];
        }
        //额外服务费
        $res["add_service_fee"] = $res["empty_parcel_fee"] + $res["thousand_fee"] + $res["favorites_fee"];
        //总花费（本金+佣金+额外服务费）
        $res["sum_fee"] = $res["cash_pledge"] + $res["every_commission"] + $res["add_service_fee"];
        //halt($res["sum_fee"].'/'.$res["cash_pledge"].'/'.$res["every_commission"].'/'.$res["add_service_fee"]);
        return $res;
    }

    private function insertTask($data){
        $res = [
            "task_type"=>$data["task"]["task_type"],
            "is_top"=>$data["task"]["is_top"],
            'restrict_area'=>$data["task"]["restrict_area"],
            'restrict_sex'=>$data["task"]["restrict_sex"],
            'restrict_level'=>$data["task"]["restrict_level"],
            'explain'=>$data["task"]["explain"],
            'shop_wang_id'=>$data["task"]["shop_wang_id"],
            "every_cash_pledge"=>$data["task"]["every_cash_pledge"],
            "every_commission"=>$data["task"]["every_commission"],
            "add_service_fee"=>$data["task"]["add_service_fee"],
            "sum_fee"=>$data["task"]["sum_fee"],
            "create_at"=>$data["task"]["create_at"],
            "user_id"=>$data["task"]["user_id"],
            "task_num"=>$data["task"]["task_num"]
        ];
        if(array_key_exists("is_favorites",$data["task"])){
            $res['is_favorites'] = $data["task"]["is_shopping_trolley"];
        }
        if(array_key_exists("is_shopping_trolley",$data["task"])){
            $res["is_shopping_trolley"] = $data["task"]["is_shopping_trolley"];
        }
        return Db::name("task") ->insertGetId($res);
    }

    //垫付任务管理
    public function taskIndex(){
        $user_id = $this ->user["id"];
        $list = Db::name("task") ->alias("t1")
                                 ->join("sd_task_goods_info t2","t1.id=t2.task_id")
                                 ->where(["t1.user_id"=>$user_id])
                                 ->where("t1.task_type","neq",5)
                                 ->field("t1.id,t1.create_at,t1.task_num,t1.is_top,t1.shop_wang_id,t2.goods_name,t2.goods_img")
                                 ->select();
         foreach($list as &$v){
            $v["status6"] = Db::name("son_task") ->where(["task_id"=>$v["id"],"status"=>6]) ->count();
            if($v["status6"] == $v["task_num"]){
                for($i = 1;$i <= 5;$i++){
                    $v["status".$i] = 0;
                }
                $v["is_finish"] = 1;
            }else{
                for($i = 1;$i <= 5;$i++){
                    $v["status".$i] = Db::name("son_task") ->where(["task_id"=>$v["id"],"status"=>$i]) ->count();
                }
                $v["is_finish"] = 0;
            }

         }
        exit(ajaxReturn($list,1,'获取数据成功'));
    }

    //垫付任务详情
    public function taskInfo(){
        $task_id = input("id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn($list,0,'参数有误'));
        }
        $data = Db::name("task") ->alias("t1")
                                 ->join("sd_task_goods_info t2","t1.id=t2.task_id")
                                 ->join("sd_bind_shop t3","t1.shop_wang_id=t3.id")
                                 ->where(["t1.id"=>$task_id])
                                 //->where("t1.task_type","neq",5)
                                 ->field("t2.goods_name,t2.goods_img,t2.goods_link,t1.task_type,t2.is_post,t3.shop_name,t2.searh_start_price,t2.searh_end_price,t2.goods_location,t1.restrict_area,t1.explain,t1.restrict_sex,t1.restrict_level")
                                 ->find();
        if(empty($data)){
            exit(ajaxReturn([],0,'数据获取失败'));
        }
        $data["empty_parcel"] = Db::name("empty_parcel_serve") ->where("task_id",$task_id) ->field("post_type,parcel_weight") ->find();
        $data["comment_info"] = Db::name("task_comment_info") ->where("task_id",$task_id) ->field("search_word") ->select();
        $data["send_plan"] = Db::name("task_send_plan") ->where("task_id",$task_id) ->field("start_at,time_interval,task_num") ->select();
        exit(ajaxReturn($data,1,'获取数据成功'));
    }

    //任务返款管理
    public function refTaskInfo(){
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->alias("t1")
                                     ->join("sd_order t2","t1.id=t2.task_id")
                                     ->where(["t1.user_id"=>$user_id,"t1.status"=>3])
                                     ->where("t1.task_type","neq",5)
                                     ->field("t1.id,t1.shop_wang_id,t1.task_id,t1.create_at,t1.search_img,t1.order_img,t1.cash_pledge,t1.task_type,t1.wangwang_id,t1.user_id,t2.id as order_id,t2.tao_order_no")
                                     ->select();
        exit(ajaxReturn($list,1,'获取数据成功'));
    }

    //确认返款
    public function confRefund(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $son_task = Db::name("son_task") ->where(["user_id"=>$user_id,"status"=>3,"id"=>$son_task_id]) ->where("task_type","neq",5) ->field("user_id,cash_pledge,real_pay,commission,shop_id") ->find();
        if(empty($son_task)){
            exit(ajaxReturn([],0,'押金获取失败'));
        }
        if($son_task["cash_pledge"] < $son_task["real_pay"]){
            exit(ajaxReturn([],0,'实际付款超过押金'));
        }
        Db::startTrans();
        try{
            Db::name("son_task") ->where(["id"=>$son_task_id]) ->update(["status"=>4,"finish_at"=>time()]);
            //插入冻结金额表
            $this ->insertFreeze($son_task_id,$son_task["real_pay"],$son_task["commission"],$user_id);
            //把剩下的本金退给商家
            $surplus = $son_task["cash_pledge"]-$son_task["real_pay"];
            if($surplus != 0){
                $after_num = MemberModel::afterRes($user_id,$sum_fee);
                //写记录
                Minutiae::insertMinu($son_task["shop_id"],6,"退还邮费,任务编号：".$son_task_id,$surplus,$after_num);
            }
            Db::commit();
            exit(ajaxReturn([],1,'支付成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //插入冻结表
    private function insertFreeze($son_task_id,$freeze_cash_pledge,$freeze_commission,$user_id){
        $data = ["son_task_id"=>$son_task_id,"freeze_cash_pledge"=>$freeze_cash_pledge,"freeze_commission"=>$freeze_commission,"user_id"=>$user_id,"create_at"=>time()];
        Db::name("freeze_jin") ->insert($data);
    }

    //显示垫付(进行中/完成)订单
    public function underwayTask(){
        $user_id = $this ->user["id"];
        $where = [];
        $type = input("post.type");
        if($type == 1){
            $where[] = ['t1.status',"between","2,5"];
        }elseif($type == 2){
            $where[] = ["t1.status","eq","6"];
        }else{
            exit(ajaxReturn($list,0,'参数错误'));
        }

        $list = Db::name("son_task") ->ailas("t1")
                                     ->join("task_goods_info t2","t1.goods_info_id=t2.id")
                                     ->where(["shop_id"=>$user_id])
                                     ->where("t1.task_type","neq",5)
                                     ->where($where)
                                     ->field("t1.id,t1.accept_at,t1.id,t1.user_id,t1.wangwang_id,t1.status,t1.task_type,t1.order_id,t2.goods_name")
                                     ->select();
        exit(ajaxReturn($list,1,'数据获取成功'));
    }

    //商家确定完成订单
    public function confFinish(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $res = Db::name("son_task") ->where("t1.task_type","neq",5) ->where(["id"=>$son_task_id,"user_id"=>$user_id,"status"=>5]) ->update(["status"=>6,"finish_at"=>time()]);
        if($res !== false){
            exit(ajaxReturn([],1,'确认成功'));
        }else{
            exit(ajaxReturn([],0,'确认失败'));
        }
    }

    //任务费用详情
    public function feeInfo(){
        $task_id = input("post.id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $data = Db::name("task") ->alias("t1")
                                 ->join("sd_fee_info t2","t1.id=t2.task_id")
                                 ->where(["t1.id"=>$task_id,"t1.shop_id"=>$user_id])
                                 ->field("t1.every_cash_pledge,t1.every_commission,t1.task_num,t2.thousand_fee,t2.platform_fee,t2.empty_parcel_fee,t2.favorites_fee")
                                 ->find();
        if(empty($data)){
            exit(ajaxReturn([],0,'数据获取失败'));
        }
        exit(ajaxReturn($data,1,'数据获取成功'));
    }

    //（费用）进行中订单
    public function feeUnderway(){
        $task_id = input("post.id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->where(["task_id"=>$task_id,"shop_id"=>$user_id]) ->where("t1.task_type","neq",5) ->field("accept_at,order_id,user_id,wangwang_id,cash_pledge,real_pay,status") ->select();
        exit(ajaxReturn($list,1,'数据获取成功'));
    }

    //（费用）已完成订单
    public function feeFinish(){
        $task_id = input("post.id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->where(["task_id"=>$task_id,"status"=>6,"shop_id"=>$user_id]) ->field("finish_at,order_id,user_id,wangwang_id,cash_pledge,real_pay") ->select();
        exit(ajaxReturn($list,1,'数据获取成功'));
    }

    //(费用)代接订单
    public function feeWait(){
        $task_id = input("post.id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->alias("t1")
                                     ->join("sd_task_comment_info t2","t1.comment_info_id=t2.id")
                                     ->where(["t1.task_id"=>$task_id,"t1.shop_id"=>$user_id,"t1.status"=>1])
                                     ->field("t1.id,t1.cash_pledge,t1.commission,t1.status,t2.search_word,t2.type")
                                     ->select();
        // foreach($list as &$v){
        //     if($v["type"] != 1){
        //         $v["commission"] += 1;
        //     }
        // }
        exit(ajaxReturn($list,1,'数据获取成功'));
    }

    //撤销任务
    public function doRecallTask(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $son_task = Db::name("son_task") ->where(["id"=>$son_task_id,"shop_id"=>$user_id,"status"=>1]) ->field("cash_pledge,commission,add_service_fee") ->find();
        if(empty($son_task)){
            exit(ajaxReturn([],0,'未找到订单'));
        }
        Db::startTrans();
        try{
            Db::name("son_task") ->where(["id"=>$son_task_id]) ->update(["status"=>-2,"recall_at"=>time()]);
            $sum_fee = $son_task["cash_pledge"] + $son_task["commission"] + $son_task["add_service_fee"];
            //把金额退给商家
            $after_num = MemberModel::afterRes($user_id,$sum_fee);
            //写记录
            Minutiae::insertMinu($user_id,7,"撤销任务退回,任务编号：".$son_task_id,$sum_fee,$after_num);
            Db::commit();
            exit(ajaxReturn([],1,'撤销成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //已撤销的订单
    public function recallTask(){
        $son_task_id = input("post.id");
        if(!is_numeric($son_task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $son_task = Db::name("son_task") ->where(["id"=>$son_task_id,"shop_id"=>$user_id,"status"=>-2]) ->field("recall_at,id,cash_pledge,商家撤销 as note") ->find();
         exit(ajaxReturn($son_task,1,'数据获取成功'));
    }

    //代接订单
    public function waitTask(){
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->ailas("t1")
                                     ->join("sd_task_comment_info t2","t1.comment_info_id=t2.id")
                                     ->where(["t1.shop_id"=>$user_id,"t1.status"=>1])
                                     ->field("t1.id,t1.cash_pledge,t1.commission,t1.status,t2.type,t2.search_word")
                                     ->select();
        exit(ajaxReturn($list,1,'数据获取成功'));
    }

    //浏览任务撤销
    public function doRecallBrowse(){
        $task_id = input("post.id");
        if(!is_numeric($task_id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $recallNum = Db::name("son_task") ->where(["shop_id"=>$user_id,"status"=>1,"task_id"=>$task_id]) ->update(["status"=>-2,"recall_at"=>time()]);
        if(!$recallNum){
            exit(ajaxReturn([],0,'无单可撤销'));
        }

        Db::startTrans();
        try{
            Db::name("task") ->where(["id"=>$task_id]) ->setDec("task_num",$recallNum);
            Db::name("task") ->where(["id"=>$task_id]) ->update(["is_recall"=>1]);
            $son_task = Db::name("task") ->where(["task_id"=>$task_id]) ->field("commission,add_service_fee") ->find();
            $sum_fee = ($son_task["commission"] + $son_task["add_service_fee"]) * $recallNum;
            //把金额退给商家
            $after_num = MemberModel::afterRes($user_id,$sum_fee);
            //写记录
            Minutiae::insertMinu($user_id,7,"撤销浏览任务退回,总任务编号：".$task_id,$sum_fee,$after_num);
            Db::commit();
            exit(ajaxReturn([],1,'撤销成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //浏览任务撤销列表
    public function recallBrowse(){
        $user_id = $this ->user["id"];
        $list = Db::name("task") ->ailas("t1")
                                 ->join("sd_bind_shop","t1.shop_wang_id=t2.id")
                                 ->join("sd_task_goods_info t3","t1.id=t3.task_id")
                                 ->where(["t1.user_id"=>$user_id,"t1.is_recall"=>1])
                                 ->field("t2.shop_name,t3.goods_name,t3.goods_img,商家撤销 as note")
                                 ->select();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }
}