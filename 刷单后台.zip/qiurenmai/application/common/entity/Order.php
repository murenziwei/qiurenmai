<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/8
 * Time: 14:47
 */

namespace app\common\entity;


class Order extends BaseEntity
{
    public $id;
    public $order_no;
    public $goods_id;
    public $uid;
    public $status;
    public $money;
    public $total_fee;
    public $price;
    public $freight;
    public $transaction_id;
    public $goods_name;
    public $num;
    public $spec;
    public $consignee;
    public $address;
    public $phone;
    public $message;
    public $pay_time;
    public $discount;
    public $coupon_id;
    public $is_deleted;
    public $created_at;
    public $logistics_name;
    public $logistics_code;
    public $shipping_time;
    public $confirm_time;
    public $apply_refund_time;
    public $confirm_refund_time;
    public $reason;
    public $type;
    public $shopping_status;

    /**
     * @param mixed $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $order_no
     */
    public function setOrderNo(string $order_no)
    {
        $this->order_no = $order_no;
    }

    /**
     * @param mixed $goods_id
     */
    public function setGoodsId(int $goods_id)
    {
        $this->goods_id = $goods_id;
    }

    /**
     * @param mixed $uid
     */
    public function setUid(int $uid)
    {
        $this->uid = $uid;
    }

    /**
     * @param mixed $status
     */
    public function setStatus(int $status)
    {
        $this->status = $status;
    }

    /**
     * @param mixed $money
     */
    public function setMoney(string $money)
    {
        $this->money = $money;
    }

    /**
     * @param mixed $total_fee
     */
    public function setTotalFee(string $total_fee)
    {
        $this->total_fee = $total_fee;
    }

    /**
     * @param mixed $price
     */
    public function setPrice(string $price)
    {
        $this->price = $price;
    }

    /**
     * @param mixed $freight
     */
    public function setFreight(string $freight)
    {
        $this->freight = $freight;
    }

    /**
     * @param mixed $transaction_id
     */
    public function setTransactionId(string $transaction_id)
    {
        $this->transaction_id = $transaction_id;
    }

    /**
     * @param mixed $goods_name
     */
    public function setGoodsName(string $goods_name)
    {
        $this->goods_name = $goods_name;
    }

    /**
     * @param mixed $num
     */
    public function setNum(int $num)
    {
        $this->num = $num;
    }

    /**
     * @param mixed $spec
     */
    public function setSpec(string $spec)
    {
        $this->spec = $spec;
    }

    /**
     * @param mixed $consignee
     */
    public function setConsignee(string $consignee)
    {
        $this->consignee = $consignee;
    }

    /**
     * @param mixed $address
     */
    public function setAddress(string $address)
    {
        $this->address = $address;
    }

    /**
     * @param mixed $phone
     */
    public function setPhone(string $phone)
    {
        $this->phone = $phone;
    }

    /**
     * @param mixed $message
     */
    public function setMessage(string $message)
    {
        $this->message = $message;
    }

    /**
     * @param mixed $pay_time
     */
    public function setPayTime(int $pay_time)
    {
        $this->pay_time = $pay_time;
    }

    /**
     * @param mixed $discount
     */
    public function setDiscount(string $discount)
    {
        $this->discount = $discount;
    }

    /**
     * @param mixed $coupon_id
     */
    public function setCouponId(int $coupon_id)
    {
        $this->coupon_id = $coupon_id;
    }

    /**
     * @param mixed $is_deleted
     */
    public function setIsDeleted(int $is_deleted)
    {
        $this->is_deleted = $is_deleted;
    }

    /**
     * @param mixed $created_at
     */
    public function setCreatedAt(int $created_at)
    {
        $this->created_at = $created_at;
    }

    /**
     * @param mixed $logistics_name
     */
    public function setLogisticsName(string $logistics_name)
    {
        $this->logistics_name = $logistics_name;
    }

    /**
     * @param mixed $logistics_code
     */
    public function setLogisticsCode(string $logistics_code)
    {
        $this->logistics_code = $logistics_code;
    }

    /**
     * @param mixed $shipping_time
     */
    public function setShippingTime(int $shipping_time)
    {
        $this->shipping_time = $shipping_time;
    }

    /**
     * @param mixed $confirm_time
     */
    public function setConfirmTime(int $confirm_time)
    {
        $this->confirm_time = $confirm_time;
    }

    /**
     * @param mixed $apply_refund_time
     */
    public function setApplyRefundTime(int $apply_refund_time)
    {
        $this->apply_refund_time = $apply_refund_time;
    }

    /**
     * @param mixed $confirm_refund_time
     */
    public function setConfirmRefundTime(int $confirm_refund_time)
    {
        $this->confirm_refund_time = $confirm_refund_time;
    }

    /**
     * @param mixed $reason
     */
    public function setReason(string $reason)
    {
        $this->reason = $reason;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @param mixed $type
     */
    public function setType(int $type)
    {
        $this->type = $type;
    }

    /**
     * @return mixed
     */
    public function getShoppingStatus()
    {
        return $this->shopping_status;
    }

    /**
     * @param mixed $shopping_status
     */
    public function setShoppingStatus(int $shopping_status)
    {
        $this->shopping_status = $shopping_status;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getOrderNo()
    {
        return $this->order_no;
    }

    /**
     * @return mixed
     */
    public function getGoodsId()
    {
        return $this->goods_id;
    }

    /**
     * @return mixed
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @return mixed
     */
    public function getMoney()
    {
        return $this->money;
    }

    /**
     * @return mixed
     */
    public function getTotalFee()
    {
        return $this->total_fee;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @return mixed
     */
    public function getFreight()
    {
        return $this->freight;
    }

    /**
     * @return mixed
     */
    public function getTransactionId()
    {
        return $this->transaction_id;
    }

    /**
     * @return mixed
     */
    public function getGoodsName()
    {
        return $this->goods_name;
    }

    /**
     * @return mixed
     */
    public function getNum()
    {
        return $this->num;
    }

    /**
     * @return mixed
     */
    public function getSpec()
    {
        return $this->spec;
    }

    /**
     * @return mixed
     */
    public function getConsignee()
    {
        return $this->consignee;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * @return mixed
     */
    public function getPayTime()
    {
        return $this->pay_time;
    }

    /**
     * @return mixed
     */
    public function getDiscount()
    {
        return $this->discount;
    }

    /**
     * @return mixed
     */
    public function getCouponId()
    {
        return $this->coupon_id;
    }

    /**
     * @return mixed
     */
    public function getIsDeleted()
    {
        return $this->is_deleted;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * @return mixed
     */
    public function getLogisticsName()
    {
        return $this->logistics_name;
    }

    /**
     * @return mixed
     */
    public function getLogisticsCode()
    {
        return $this->logistics_code;
    }

    /**
     * @return mixed
     */
    public function getShippingTime()
    {
        return $this->shipping_time;
    }

    /**
     * @return mixed
     */
    public function getConfirmTime()
    {
        return $this->confirm_time;
    }

    /**
     * @return mixed
     */
    public function getApplyRefundTime()
    {
        return $this->apply_refund_time;
    }

    /**
     * @return mixed
     */
    public function getConfirmRefundTime()
    {
        return $this->confirm_refund_time;
    }

    /**
     * @return mixed
     */
    public function getReason()
    {
        return $this->reason;
    }


}