<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-02 09:23:42
 */
namespace app\api\controller;

use think\Db;

class Other extends Base
{
    public function shareUrl(){
        $user_id = $this ->user["id"];
        $code = Db::name("member") ->where(["id"=>$user_id]) ->value("invite_code");
        if(empty($code)){
            exit(ajaxReturn([],0,"获取数据失败"));
        }
        $url = 'http://www.xxx.com?code='.$code;
        exit(ajaxReturn(["url"=>$url],1,"生成成功"));
    }

    public function notice(){
        $note = Db::name("introduce") ->where(["type"=>2]) ->value("note");
        if(empty($note)){
            exit(ajaxReturn([],0,"暂无数据"));
        }
        exit(ajaxReturn(["note"=>$note],1,"获取成功"));
    }

    public function upload(){
        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('file');
        if(empty($file)){
            exit(ajaxReturn([],0,"图片未上传"));
        }
        // 移动到框架应用根目录/public/uploads/ 目录下
        $info = $file->validate(['ext'=>'jpg,png,jpeg'])->move(ROOT_PATH.'uploads');
        if($info){
           //获取图片的存放相对路径
            $filePath =  '/uploads/'.$info->getSaveName();

            exit(ajaxReturn(["filePath"=>$filePath],1,"上传成功"));
        }else{
            exit(ajaxReturn([],0,$file->getError()));
        }
    }

    public function video(){
        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('file');
        if(empty($file)){
            exit(ajaxReturn([],0,"视频未上传"));
        }
        // 移动到框架应用根目录/public/uploads/ 目录下
        $info = $file->validate(['ext'=>'avi,mov,rmvb,rm,flv,mp4,3gp,mp3'])->move(ROOT_PATH.'uploads');
        if($info){
           //获取图片的存放相对路径
            $filePath =  '/uploads/'.$info->getSaveName();

            exit(ajaxReturn(["filePath"=>$filePath],1,"上传成功"));
        }else{
            exit(ajaxReturn([],0,$file->getError()));
        }
    }

}