<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;

class Introduce extends Base
{
    public function shop(){
        $data = Db::name("introduce") ->where(["type"=>1]) ->find();
        $this ->assign("data",$data);
        return $this ->fetch();
    }

    public function buy(){
        $data = Db::name("introduce") ->where(["type"=>2]) ->find();
        $this ->assign("data",$data);
        return $this ->fetch();
    }

    public function editIntroduce(){
        $id = input("post.id");
        $type = input("post.type");
        $note = input("post.note");
        if(!is_numeric($id)||!is_numeric($type)||empty($note)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $res = Db::name("introduce") ->where(["id"=>$id,"type"=>$type]) ->update(["note"=>$note,"update_at"=>time()]);
        if($res !== false){
            $this ->success("修改成功");
        }else{
            $this ->error("修改失败");
        }
    }
}