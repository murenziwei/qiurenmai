<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-04 16:05:36
 */
namespace app\api\controller;

use app\api\logic\Member as memberLogic;
use think\Controller;
use app\api\validate\Member as MemberVali;
use app\api\model\Member as memberModel;
use think\Db;
use app\api\model\Minutiae;

class Login extends Controller
{
    //登录
    public function userLogin(){
        $memberLogic = new memberLogic();
        echo $memberLogic->login();
    }

    //注册
    public function register(){
        $data = input();
        $validate = new MemberVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $is_exist = Db::name("member") ->where("ue_account",$data["ue_account"]) ->find();
        if($is_exist){
            exit(ajaxReturn([],0,"手机号已存在"));
        }
        if(cache($data["ue_account"]) != $data["phone_code"]){
            exit(ajaxReturn([],0,"验证码错误"));
        }
        $data["ue_password"] = MD5(md5($data["ue_password"]) . config('app.salf'));
        $data["invite_code"] = memberModel::getInvitationCode();

        $pmember = Db::name("member") ->where(["invite_code"=>$data["pcode"]]) ->field("id,type") ->find();
        if(empty($pmember)){
            exit(ajaxReturn([],0,"错误的邀请码"));
        }
        if($pmember["type"] != $data["type"]){
            if($pmember["type"] == 1){
                exit(ajaxReturn([],0,"买手不得填商家的邀请码"));
            }else{
                exit(ajaxReturn([],0,"商家不得填买手的邀请码"));
            }
        }
        $data["pid"] = $pmember["id"];
        //买手注册是送10金币和三个月会员
        $time = time();
        if($data["type"] == 2){
            $data["commission"] = 10;
            $data["vip"] = 60*60*24*30*3 + $time;
        }
        unset($data["phone_code"]);
        //unset($data["ue_password"]);
        unset($data["confirm_password"]);
        unset($data["pcode"]);
        $data["create_at"] = $time;

        Db::startTrans();
        try{
            $user_id = Db::name("member") ->insertGetId($data);
            if($data["type"] == 2){
                Minutiae::platformFlow(-10,$user_id,0,7,2,2);
            }
            Db::commit();
            exit(ajaxReturn([],1,"注册成功"));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //发送验证码
    public function getCode(){
        $phone = input("post.phone");
        if(empty($phone)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $code = rand(1111,9999);
        $mobile = new Mobile();
        $res = $mobile ->sendMsg($phone,$code);
        if($res["code"] == "9001"){
            cache($phone,$code, 60*15);
            exit(ajaxReturn([],1,"发送成功"));
        }else{
            exit(ajaxReturn([],0,"发送失败"));
        }
    }


}