<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/8
 * Time: 15:30
 */

namespace app\common\model;


class User extends BaseDao
{
    public static function checkUsernameBy($uesrname,$user_id=''){
        $map[] = ['username','=',$uesrname];
        if(!empty($user_id))
            $map[] = ['user_id','neq',$user_id];
        $data = self::where($map)->find();
        if(!$data)
            return false;
        return true;
    }
}