<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 0:18
 */

namespace app\common\logic;
use app\common\BaseModel;
use app\common\entity\User as userEntity;
use app\common\model\User as userModel;
use app\common\model\Role as roleModel;
use think\Db;

class User extends BaseModel
{
    protected $userEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->userEntity = new userEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){
//        if(isset($this->requestData['search'])) {
//            $this->authEntity->auth_name($this->requestData['search']);
//        }
//        $map = $this->authEntity->params();
//        if(isset($map['auth_name'])){
//            $map['auth_name'] = ['like','%'.$map['auth_name'].'%'];
//        }
        $list = userModel::pageList("1=1",'*',$limit);
        $list->each(function($item,$key){
            $cate_auth = roleModel::findOne(['role_id'=>$item['role_id']],'role_name');
            $item['role_name'] = empty($cate_auth['role_name'])?'管理员':$cate_auth['role_name'];
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function updateStatus(){
        $this->userEntity->setUserId($this->requestData['user_id']);
        $info = userModel::findOne($this->userEntity->params());
        if(!$info)
            return $this->failReturn('数据不存在');
        if($info['status']==1){
            $data['status'] = 0;
        }else{
            $data['status'] = 1;
        }
        $res = userModel::updateDatas($data,$this->userEntity->params());
        if(!$res)
            return $this->failReturn('修改失败');
        return $this->successReturn('修改成功');
    }

    public function del(){
        if(!array_key_exists('user_id',$this->requestData)&&!empty($this->requestData['user_id']))
            return $this->failReturn('请选择角色');
        if(!is_array($this->requestData['user_id'])){
            $res = userModel::deleteByKey(['user_id'=>$this->requestData['user_id']]);
        }else{
            $res = Db::table('__USER__')->delete($this->requestData['user_id']);
        }
        if ($res) {
            return $this->successReturn('删除成功');
        } else {
            return $this->failReturn('删除失败');
        }
    }

    public function saveData(){
        if(!array_key_exists('username',$this->requestData)||empty($this->requestData['username']))
            return $this->failReturn('请填写账号');
        if(!array_key_exists('nickname',$this->requestData)||empty($this->requestData['nickname']))
            return $this->failReturn('请填写昵称');
        if(!array_key_exists('role_id',$this->requestData)||empty($this->requestData['role_id']))
            return $this->failReturn('请选择角色');
        if(!array_key_exists('status',$this->requestData))
            $this->userEntity->setStatus(1);
        else
            $this->userEntity->setStatus($this->requestData['status']);

        $this->userEntity->setUsername($this->requestData['username']);
        $this->userEntity->setNickname($this->requestData['nickname']);
        $this->userEntity->setRoleId($this->requestData['role_id']);
        if(array_key_exists('user_id',$this->requestData)&&!empty($this->requestData['user_id'])){
            if(array_key_exists('password',$this->requestData)&&!empty($this->requestData['password'])){
                $password = md5(md5($this->requestData['password']).config('app.salf'));
                $this->userEntity->setPassword($password);
            }
            $res1 = userModel::checkUsernameBy($this->requestData['username'],$this->requestData['user_id']);
            if($res1)
                return $this->failReturn('账号已存在');
            $res = roleModel::updateDatas($this->userEntity->params(),['user_id'=>$this->requestData['user_id']]);
        }else{
            if(!array_key_exists('password',$this->requestData)||empty($this->requestData['password']))
                return $this->failReturn('请填写密码');
            $password = md5(md5($this->requestData['password']).config('app.salf'));
            $this->userEntity->setPassword($password);
            $this->userEntity->setCreatedAt(time());
            $res1 = userModel::checkUsernameBy($this->requestData['username']);
            if($res1)
                return $this->failReturn('账号已存在');
            $res = userModel::createData($this->userEntity->params());
        }
        if(!$res)
            return $this->failReturn('操作失败');
        return $this->successReturn('操作成功');
    }
}