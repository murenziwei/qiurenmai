<?php
namespace app\api\validate;

use think\Validate;

class SendPlan extends Validate
{
    protected $rule = [
        'start_at'  => 'require',
        'time_interval' => 'require|number',
        'task_num' => 'require|number|between:1,255'
    ];


    protected $field = [
        'start_at'  => '开始时间',
        'time_interval' => '时间间隔',
        'task_num' => '单数'
    ];
}