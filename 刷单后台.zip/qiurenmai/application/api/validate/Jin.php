<?php
namespace app\api\validate;

use think\Validate;

class Jin extends Validate
{
    protected $rule = [
        'bank'  => 'require',
        'card_name' => 'require',
        'card_no' => 'require',
        'money' => 'require|float'
    ];


    protected $field = [
        'bank'  => '银行名称',
        'card_name' => '银行姓名',
        'card_no' => '银行卡号',
        'money' => '金额'
    ];
}