<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use app\admin\logic\Login as loginLogic;
use think\Controller;
use think\facade\Config;
use think\facade\Env;
use think\facade\Request;

class Login extends Controller
{
    public function login(){
        if($this->request->isPost()){
            echo (new loginLogic())->checkLogin();
            exit;
//            return $this->returnDataFormat('登录成功');
        }
        $this->assign('title','刷单管理后台');
        $this->assign('website','刷单管理后台');
        echo $this->fetch();
    }

    public function logout(){
        session(null);
        $this->redirect('admin/login/login');
    }
}