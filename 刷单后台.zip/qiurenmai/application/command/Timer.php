<?php

namespace app\command;

use app\api\controller\Hosting;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\Exception;

class Timer extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('timedTask');
        // 设置参数

    }

    protected function execute(Input $input, Output $output)
    {
        // 指令输出
        $output->writeln('执行开始！');
        $Hosting = new \app\api\logic\Hosting();
        $Hosting->autoStatisticsPrice();
        $Hosting->autoUpgradeNode();
        $Hosting->freedLocked();
        $Hosting->timedTask();
        $output->writeln('执行完成！');
    }
}
