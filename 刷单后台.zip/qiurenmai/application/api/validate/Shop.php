<?php
namespace app\api\validate;


class Shop extends BaseVali
{
    protected $rule = [
        'platform_type' => 'require|number|between:1,3',
        'shop_name'  =>  'require',
        'shop_url'  => 'require',
        'wangwang_id' => 'require',
        'address'  =>'require',
        'detailed_address' => 'require',
        'phone'  =>  'require|isMobile'
    ];


    protected $field = [
        'platform_type' => '平台',
        'shop_name'  =>  '店铺名',
        'shop_url'  => '店铺链接',
        'wangwang_id' => '店主旺旺ID',
        'address'  =>'地址',
        'detailed_address' => '街道',
        'phone'  =>  '手机号'
    ];
}