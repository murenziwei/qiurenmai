<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:25
 */
use think\facade\Route;

Route::group('api',function (){

});