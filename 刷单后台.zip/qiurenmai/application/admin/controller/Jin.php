<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;
use app\admin\validate\Section as SectionVali;

class Jin extends Base
{
    public function topUpList(){
        $list = Db::name("top_up") ->order("create_at desc") ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    public function withdrawList(){
        $list = Db::name("withdraw") ->alias("t1")
                                     ->join("sd_bind_bank_card t2","t1.bind_bank_id=t2.id")
                                     ->field("t1.id,t1.create_at,t1.user_id,t1.money,t1.status,t2.name as card_name,t2.bank,t1.check_at")
                                     ->order("t1.create_at desc")
                                     ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }


    public function doCkWithdraw(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $res = Db::name("withdraw") ->where(["id"=>$id]) ->update(["status"=>1,"check_at"=>time()]);
        if($res !== false){
            $this ->success("处理成功");
        }else{
            $this ->error("处理失败");
        }
    }
    //平台流水
    public function platformFlow(){
        $list = Db::name("platform_flow") ->order("id desc") ->paginate(15);
        $jin_sum = Db::name("platform_flow") ->where(["jin_type"=>1]) ->sum("jin");
        $comiss_sum = Db::name("platform_flow") ->where(["jin_type"=>2]) ->sum("jin");
        $this ->assign("list",$list);
        $this ->assign("jin_sum",$jin_sum);
        $this ->assign("comiss_sum",$comiss_sum);
        return $this ->fetch();
    }

    //垫付区间列表
    public function sectionList(){
        $type = input("type");
        if(!is_numeric($type)){
            $this ->error("参数有误");
        }
        $list = Db::name("task_commission_fee") ->where(["task_type"=>$type,"is_del"=>0]) ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    public function setSection(){
        return $this ->fetch();
    }


    public function doSetSection(){
        $data = input('post.');

        $validate = new SectionVali();
        if (!$validate->check($data)) {
            $this ->error($validate->getError());
        }
        $res = Db::name('task_commission_fee') ->insert($data);
        if($res){
            $this ->success("添加成功");
        }else{
            $this ->error("添加失败");
        }

    }


    public function doDelSection(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $is_del = Db::name('task_commission_fee') ->where('id',$id) ->update(['is_del'=>1]);
        if($is_del){
           $this ->success("删除成功");
        }else{
            $this ->error("删除失败");
        }
    }


    public function editSection(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数错误");
        }
        $data = Db::name('task_commission_fee') ->where(['id'=>$id,'is_del'=>0]) ->find();
        if(empty($data)){
             $this ->error("数据获取失败");
        }
        $this ->assign("data",$data);
        return $this ->fetch();
    }


    public function doEditSection(){
        $data = input("post.");
        if(!isset($data['id']) || !is_numeric($data['id'])){
            $this ->error("参数错误");
        }
        $validate = new SectionVali();
        if (!$validate->check($data)) {
            $this ->error($validate->getError());
        }
        $res = Db::name('task_commission_fee') ->where(['id'=>$data['id']]) ->update($data);
        if($res !== false){
            $this ->success("修改成功");
        }else{
            $this ->error("修改失败");
        }
    }
}