<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use app\common\model\Role as roleModel;
use app\common\logic\Role as roleLogic;
use app\common\model\Auth as authModel;
use think\App;
use think\Controller;
use think\facade\Config;
use think\facade\Env;
use think\facade\Request;

class Role extends Base
{
    public $roleLogic;
    public function __construct(App $app = null)
    {
        parent::__construct($app);
        $this->roleLogic = new roleLogic();
    }

    public function index(){
        //sql语句的意思：查找role（角色）表的所有字段，auth（权限）表的权限名称，分组后auth表的auth_name字段连接在一起产生新的字段all_auth ，来自role表左连接auth表条件是auth表的权限id在role表的auth_id_list的集合中，最后以role表的角色id进行分组
        $data = roleModel::getList();
        $this->assign($data);
        echo $this->fetch();
    }

    public function add(){
        if($this->request->isPost()){
            exit($this->roleLogic->saveData());
        }
        $data = authModel::getList();
        $this->assign($data);
        echo $this->fetch('edit');
    }

    public function upd($role_id){
        if($this->request->isPost()){
            exit($this->roleLogic->saveData());
        }
        $roleData = roleModel::findOne(['role_id'=>$role_id]);//根据ID找到记录
        $roleData['auth_id_list'] = explode(',', $roleData['auth_id_list']);
        $data = authModel::getList();
        $this->assign($data);
        $this->assign([
            'role_id'=>$role_id,
            'roleData'=>$roleData,
        ]);
        echo $this->fetch('upd');
    }

    public function del(){
        exit($this->roleLogic->del());
    }

    public function updateStatus(){
        exit($this->roleLogic->updateStatus());
    }
}