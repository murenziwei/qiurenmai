<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\12 0012
 * Time: 14:34
 */

namespace app\common\entity;


class Withdraw extends BaseEntity
{
    public $id;
    public $user_id;
    public $address;
    public $num;
    public $handling_fee;
    public $actual_num;
    public $created_at;
    public $status;

    /**
     * @param mixed $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId(int $user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * @param mixed $address
     */
    public function setAddress(string $address)
    {
        $this->address = $address;
    }

    /**
     * @param mixed $num
     */
    public function setNum(float $num)
    {
        $this->num = $num;
    }

    /**
     * @param mixed $handling_fee
     */
    public function setHandlingFee(float $handling_fee)
    {
        $this->handling_fee = $handling_fee;
    }

    /**
     * @param mixed $actual_num
     */
    public function setActualNum(float $actual_num)
    {
        $this->actual_num = $actual_num;
    }

    /**
     * @param mixed $created_at
     */
    public function setCreatedAt(int $created_at)
    {
        $this->created_at = $created_at;
    }

    /**
     * @param mixed $status
     */
    public function setStatus(int $status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @return mixed
     */
    public function getNum()
    {
        return $this->num;
    }

    /**
     * @return mixed
     */
    public function getHandlingFee()
    {
        return $this->handling_fee;
    }

    /**
     * @return mixed
     */
    public function getActualNum()
    {
        return $this->actual_num;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }


}