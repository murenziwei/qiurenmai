<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\13 0013
 * Time: 16:15
 */

namespace app\admin\logic;

use app\common\BaseModel;
use app\common\model\SmsTemp as smsTempModel;
use think\Db;

class SmsTemp extends BaseModel
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

    /**
     * 获取分页列表
     * @param int $limit
     * @return array
     */
    public function getList(int $limit=10){
        $map = "1=1";
        $list = smsTempModel::pageList($map,'*',$limit,'created_at desc');
        $list->each(function($item,$key){
            $cat_list = ['验证码短信','通知类短信'];
            $item['cat_name'] = $cat_list[$item['cat_id']-1];
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function del(){
        if(!array_key_exists('id',$this->requestData)&&!empty($this->requestData['id']))
            return $this->failReturn('请选择对应文章');
        if(!is_array($this->requestData['id'])){
            $res = smsTempModel::deleteByKey(['id'=>$this->requestData['id']]);
        }else{
            $res = Db::table('__SMS_TEMP__')->delete($this->requestData['id']);
        }
        if ($res) {
            return $this->successReturn('删除成功');
        } else {
            return $this->failReturn('删除失败');
        }
    }

    public function saveData(){
        if(!array_key_exists('cat_id',$this->requestData)||empty($this->requestData['cat_id']))
            return $this->failReturn('请选择类型');
        if(!array_key_exists('template_code',$this->requestData)||empty($this->requestData['template_code']))
            return $this->failReturn('模板ID不能为空');
        $params = [
            'cat_id'=>$this->requestData['cat_id'],
            'template_code'=>$this->requestData['template_code'],
            'sign_name'=>$this->requestData['sign_name'],
            'status'=>1,
        ];
        if(array_key_exists('id',$this->requestData)&&!empty($this->requestData['id'])) {
            $res = smsTempModel::updateDatas($params, ['id' => $this->requestData['id']]);
        }else {
            $params['created_at'] = time();
            $res = smsTempModel::createData($params);
        }
        if(!$res)
            return $this->failReturn('操作失败');
        return $this->successReturn('操作成功');
    }
}