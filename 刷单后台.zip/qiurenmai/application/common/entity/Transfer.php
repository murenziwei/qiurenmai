<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\11 0011
 * Time: 10:16
 */

namespace app\common\entity;


class Transfer extends BaseEntity
{
    public $id;
    public $user_id;
    public $r_id;
    public $r_address;
    public $from;
    public $num;
    public $created_at;

    /**
     * @param mixed $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId(int $user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * @param mixed $r_id
     */
    public function setRId(int $r_id)
    {
        $this->r_id = $r_id;
    }

    /**
     * @param mixed $r_address
     */
    public function setRAddress(string $r_address)
    {
        $this->r_address = $r_address;
    }

    /**
     * @param mixed $from
     */
    public function setFrom(int $from)
    {
        $this->from = $from;
    }

    /**
     * @param mixed $num
     */
    public function setNum(float $num)
    {
        $this->num = $num;
    }

    /**
     * @param mixed $created_at
     */
    public function setCreatedAt(int $created_at)
    {
        $this->created_at = $created_at;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @return mixed
     */
    public function getRId()
    {
        return $this->r_id;
    }

    /**
     * @return mixed
     */
    public function getRAddress()
    {
        return $this->r_address;
    }

    /**
     * @return mixed
     */
    public function getFrom()
    {
        return $this->from;
    }

    /**
     * @return mixed
     */
    public function getNum()
    {
        return $this->num;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

}