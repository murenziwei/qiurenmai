<?php
/**
 * Created by PhpStorm.
 * User: xiao
 * Date: 2019/1/16
 * Time: 17:22
 */

namespace app\engine\controller;


use app\engine\service\AihCore;

class Test
{
    public function getAccountList()
    {
        $AihCoin = new AihCore();
        $list = $AihCoin->getAccountList();
        dump($list);
    }

    public function newAccount()
    {
//        return date("Y-m-d H:i:s", time());
        $AihCoin = new AihCore();
        return $AihCoin->newAccount("00008888");
    }

    public function unlockAccount()
    {
        $AihCoin = new AihCore();
        return $AihCoin->unlockAccount('test', '00008888');
    }

    public function getBalance()
    {
        $AihCoin = new AihCore();
        dump($AihCoin->getBalance('test'));
    }
}