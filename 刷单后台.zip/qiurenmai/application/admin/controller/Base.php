<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/7
 * Time: 14:52
 */

namespace app\admin\controller;
use think\App;
use think\Controller;
use think\facade\Request;
use think\facade\Session;

class Base extends Controller
{
    public $request;
    public $requestData;//请求数据包
    public function __construct(App $app = null)
    {
        parent::__construct($app);
        if (!Session::get('nickname')) {
            $this->redirect('Admin/Login/login');
        }

        $all_auth = Session::get('auth');
        $user_id = Session::get('user_id');
        $controller = Request::instance()->controller();
        $action = Request::instance()->action();
        $this->request = $app['request'];
        $this->requestData = $this->request->param('');
        $this->assign('title','刷单管理后台');
        $this->assign('website','刷单管理后台');
        if ($all_auth == '*' || strtolower($controller) == 'index') {
            return true;
        }
        $now_auth = strtolower($controller.'/'.$action);
        $not_auth = ['goods/getattrgroup'];
        if (!in_array($now_auth, $all_auth)&&!in_array($now_auth,$not_auth)) {
            $this->error("无权访问",url("admin/index/index"));
        }
    }

    public function returnDataFormat($msg = '',$flag = 1)
    {
        return ['status'=>$flag,  'message'=> $msg];
    }

    /**
     * @param array $data
     * @param int $code
     * @param string $message
     * @return \think\response\Json
     */
    public function ajaxReturn($data = [],$code = 1,$message = 'success')
    {
        header('Content-Type:application/json; charset=utf-8');
        if (!is_array($data) || empty($data)){
            return json_encode(['data'=>array(),'code'=>$code,'message'=>$message]);
        }
        if(array_key_exists('message',$data)){
            if(array_key_exists('status',$data)){
                return json_encode(['data'=>array(),'code'=>$data['status'],'message'=>$data['message']]);
            }else{
                return json_encode(['data'=>array(),'code'=>0,'message'=>$data['message']]);
            }
        }
        return json_encode(['data'=> !array_key_exists(0,$data) ? array($data) : $data,'code'=>$code,'message'=>$message]);
    }
}