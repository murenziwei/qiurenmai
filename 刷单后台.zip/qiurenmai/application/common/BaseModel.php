<?php
namespace app\common;

use think\Db;
use think\Model;
use \think\facade\Request;


class BaseModel extends Model
{
    public $request;
    public $requestData;
    protected $user;
    protected $map = [];
    public function __construct($data = [])
    {
        parent::__construct($data);
        $this->request = Request::instance();
        $this->requestData = empty($data) ? $this->request->param('') : $data;

        if ($this->request->__get('user')) {
            $this->user = $this->request->__get('user');
        }
    }

    protected function prefixImgUrl($val,$url = '')
    {
        if (is_array($val)){
            if(!empty($val)){
                foreach ($val as &$v){
                    $v = config('sms_temp.img_prefix').$url.str_replace('\\',"/", $v);
                }
            }
        }else{
            $val = config('sms_temp.img_prefix').$url.str_replace('\\',"/", $val);
        }
        return $val;
    }

    /**
     * @param string $message
     * @param array $data
     * @return \think\response\Json
     */
    public function successReturn($message = 'success',$data = [])
    {
        header('Content-Type:application/json; charset=utf-8');
        return json_encode(['data'=>$data,'code'=>1,'message'=>$message],JSON_UNESCAPED_UNICODE);
    }

    public function failReturn($message = 'fial')
    {
        header('Content-Type:application/json; charset=utf-8');
        return json_encode(['data'=>[],'code'=>0,'message'=>$message],JSON_UNESCAPED_UNICODE);
    }
}