<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/8
 * Time: 15:53
 */
namespace app\common\logic;
use app\common\BaseModel;
use app\common\model\Auth as authModel;
use app\common\entity\Auth as authEntity;

class Auth extends BaseModel
{
    protected $authEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->authEntity = new authEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $type=1,int $limit=10,int $is_delete=0){
        $this->authEntity->setType($type);
        $this->authEntity->setIsDelete($is_delete);
        if(isset($this->requestData['search'])) {
            $this->authEntity->auth_name($this->requestData['search']);
        }
        $map = $this->authEntity->params();
        if(isset($map['auth_name'])){
            $map['auth_name'] = ['like','%'.$map['auth_name'].'%'];
        }
        $list = authModel::pageList($map,'*',$limit);
        $list->each(function($item,$key){
            $cate_auth = authModel::findOne(['auth_id'=>$item['pid'],'is_delete'=>0],'auth_name');
            $item['cate_auth'] = empty($cate_auth['auth_name'])?'顶级权限':$cate_auth['auth_name'];
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function saveData(){

    }
}