<?php
namespace app\api\validate;

use think\Validate;

class Comment extends Validate
{
    protected $rule = [
        'video' => 'require',
        'imgs' => 'require',
        'specification' => 'require',
        'search_word' => 'max:25',
        'than_word' => 'max:25',
    ];

    //验证场景
    protected $scene = [
        'common' => ['search_word','than_word'=>'require'],
        'word'   => ['search_word','than_word'=>'require'],
        'img'    => ['search_word','imgs','specification','than_word'=>'require'],
        'video'  => ['search_word','imgs','specification','video','than_word'=>'require']
    ];

    protected $field = [
        'video' => '视频',
        'imgs' => '图片',
        'specification' => '规格',
        'search_word' => '搜索关键词',
        'than_word' => '货比词',
    ];
}