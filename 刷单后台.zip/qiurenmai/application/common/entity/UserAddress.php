<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/5
 * Time: 15:25
 */

namespace app\common\entity;


class UserAddress extends BaseEntity
{
    public $address_id;
    public $user_id;
    public $consignee;
    public $address;
    public $mobile;
    public $is_default;
    public $province;
    public $city;
    public $area;

    /**
     * @param mixed $address_id
     */
    public function setAddressId(int $address_id)
    {
        $this->address_id = $address_id;
    }

    /**
     * @param mixed $user_id
     */
    public function setUserId(int $user_id)
    {
        $this->user_id = $user_id;
    }

    /**
     * @param mixed $consignee
     */
    public function setConsignee(string $consignee)
    {
        $this->consignee = $consignee;
    }

    /**
     * @param mixed $address
     */
    public function setAddress(string $address)
    {
        $this->address = $address;
    }

    /**
     * @param mixed $mobile
     */
    public function setMobile(string $mobile)
    {
        $this->mobile = $mobile;
    }

    /**
     * @param mixed $is_default
     */
    public function setIsDefault(string $is_default)
    {
        $this->is_default = $is_default;
    }

    /**
     * @param mixed $province
     */
    public function setProvince(string $province)
    {
        $this->province = $province;
    }

    /**
     * @param mixed $city
     */
    public function setCity(string $city)
    {
        $this->city = $city;
    }

    /**
     * @param mixed $area
     */
    public function setArea(string $area)
    {
        $this->area = $area;
    }


    /**
     * @return mixed
     */
    public function getAddressId()
    {
        return $this->address_id;
    }

    /**
     * @return mixed
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * @return mixed
     */
    public function getConsignee()
    {
        return $this->consignee;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @return mixed
     */
    public function getMobile()
    {
        return $this->mobile;
    }

    /**
     * @return mixed
     */
    public function getIsDefault()
    {
        return $this->is_default;
    }

    /**
     * @return mixed
     */
    public function getProvince()
    {
        return $this->province;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @return mixed
     */
    public function getArea()
    {
        return $this->area;
    }


}