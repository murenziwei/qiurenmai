<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\9 0009
 * Time: 11:49
 */

namespace app\common\entity;

class Member extends BaseEntity
{
    public $id;
    public $avatar;
    public $ue_account;
    public $ue_name;
    public $ue_phone;
    public $ue_password;
    public $ue_pay_psw;
    public $ue_reg_time;
    public $ue_log_num;
    public $ue_status;
    public $ue_note;
    public $UE_qbc;
    public $ue_pdc;
    public $ue_income;
    public $UE_sum;
    public $ue_reward;
    public $ue_reward_team;
    public $UE_activeTime;
    public $ue_address;
    public $ue_pd_address;
    public $pid;
    public $track_pid_list;
    public $code;
    public $p_num;
    public $is_internal;

    /**
     * @param mixed $id
     */
    public function setId(int $id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $avatar
     */
    public function setAvatar(string $avatar)
    {
        $this->avatar = $avatar;
    }

    /**
     * @param mixed $ue_account
     */
    public function setUeAccount(string $ue_account)
    {
        $this->ue_account = $ue_account;
    }

    /**
     * @param mixed $ue_name
     */
    public function setUeName(string $ue_name)
    {
        $this->ue_name = $ue_name;
    }

    /**
     * @param mixed $ue_phone
     */
    public function setUePhone(string $ue_phone)
    {
        $this->ue_phone = $ue_phone;
    }

    /**
     * @param mixed $ue_password
     */
    public function setUePassword(string $ue_password)
    {
        $this->ue_password = $ue_password;
    }

    /**
     * @param mixed $ue_pay_psw
     */
    public function setUePayPsw(string $ue_pay_psw)
    {
        $this->ue_pay_psw = $ue_pay_psw;
    }

    /**
     * @param mixed $ue_reg_time
     */
    public function setUeRegTime(int $ue_reg_time)
    {
        $this->ue_reg_time = $ue_reg_time;
    }

    /**
     * @param mixed $ue_log_num
     */
    public function setUeLogNum(int $ue_log_num)
    {
        $this->ue_log_num = $ue_log_num;
    }

    /**
     * @param mixed $ue_status
     */
    public function setUeStatus(int $ue_status)
    {
        $this->ue_status = $ue_status;
    }

    /**
     * @param mixed $ue_note
     */
    public function setUeNote(string $ue_note)
    {
        $this->ue_note = $ue_note;
    }

    /**
     * @param mixed $UE_qbc
     */
    public function setUEQbc(float $UE_qbc)
    {
        $this->UE_qbc = $UE_qbc;
    }

    /**
     * @param mixed $ue_pdc
     */
    public function setUePdc(float $ue_pdc)
    {
        $this->ue_pdc = $ue_pdc;
    }

    /**
     * @param mixed $ue_income
     */
    public function setUeIncome(float $ue_income)
    {
        $this->ue_income = $ue_income;
    }

    /**
     * @param mixed $UE_sum
     */
    public function setUESum(float $UE_sum)
    {
        $this->UE_sum = $UE_sum;
    }

    /**
     * @param mixed $ue_reward
     */
    public function setUeReward(float $ue_reward)
    {
        $this->ue_reward = $ue_reward;
    }

    /**
     * @param mixed $ue_reward_team
     */
    public function setUeRewardTeam(float $ue_reward_team)
    {
        $this->ue_reward_team = $ue_reward_team;
    }

    /**
     * @param mixed $UE_activeTime
     */
    public function setUEActiveTime(int $UE_activeTime)
    {
        $this->UE_activeTime = $UE_activeTime;
    }

    /**
     * @param mixed $ue_address
     */
    public function setUeAddress(string $ue_address)
    {
        $this->ue_address = $ue_address;
    }

    /**
     * @param mixed $ue_pd_address
     */
    public function setUePdAddress(string $ue_pd_address)
    {
        $this->ue_pd_address = $ue_pd_address;
    }

    /**
     * @param mixed $pid
     */
    public function setPid(int $pid)
    {
        $this->pid = $pid;
    }

    /**
     * @param mixed $track_pid_list
     */
    public function setTrackPidList(string $track_pid_list)
    {
        $this->track_pid_list = $track_pid_list;
    }

    /**
     * @param mixed $code
     */
    public function setCode(string $code)
    {
        $this->code = $code;
    }

    /**
     * @param mixed $p_num
     */
    public function setPNum(float $p_num)
    {
        $this->p_num = $p_num;
    }

    /**
     * @param mixed $is_internal
     */
    public function setIsInternal(int $is_internal)
    {
        $this->is_internal = $is_internal;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getAvatar()
    {
        return $this->avatar;
    }

    /**
     * @return mixed
     */
    public function getUeAccount()
    {
        return $this->ue_account;
    }

    /**
     * @return mixed
     */
    public function getUeName()
    {
        return $this->ue_name;
    }

    /**
     * @return mixed
     */
    public function getUePhone()
    {
        return $this->ue_phone;
    }

    /**
     * @return mixed
     */
    public function getUePassword()
    {
        return $this->ue_password;
    }

    /**
     * @return mixed
     */
    public function getUePayPsw()
    {
        return $this->ue_pay_psw;
    }

    /**
     * @return mixed
     */
    public function getUeRegTime()
    {
        return $this->ue_reg_time;
    }

    /**
     * @return mixed
     */
    public function getUeLogNum()
    {
        return $this->ue_log_num;
    }

    /**
     * @return mixed
     */
    public function getUeStatus()
    {
        return $this->ue_status;
    }

    /**
     * @return mixed
     */
    public function getUeNote()
    {
        return $this->ue_note;
    }

    /**
     * @return mixed
     */
    public function getUEQbc()
    {
        return $this->UE_qbc;
    }

    /**
     * @return mixed
     */
    public function getUePdc()
    {
        return $this->ue_pdc;
    }

    /**
     * @return mixed
     */
    public function getUeIncome()
    {
        return $this->ue_income;
    }

    /**
     * @return mixed
     */
    public function getUESum()
    {
        return $this->UE_sum;
    }

    /**
     * @return mixed
     */
    public function getUeReward()
    {
        return $this->ue_reward;
    }

    /**
     * @return mixed
     */
    public function getUeRewardTeam()
    {
        return $this->ue_reward_team;
    }

    /**
     * @return mixed
     */
    public function getUEActiveTime()
    {
        return $this->UE_activeTime;
    }

    /**
     * @return mixed
     */
    public function getUeAddress()
    {
        return $this->ue_address;
    }

    /**
     * @return mixed
     */
    public function getUePdAddress()
    {
        return $this->ue_pd_address;
    }

    /**
     * @return mixed
     */
    public function getPid()
    {
        return $this->pid;
    }

    /**
     * @return mixed
     */
    public function getTrackPidList()
    {
        return $this->track_pid_list;
    }

    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @return mixed
     */
    public function getPNum()
    {
        return $this->p_num;
    }

    /**
     * @return mixed
     */
    public function getIsInternal()
    {
        return $this->is_internal;
    }



}