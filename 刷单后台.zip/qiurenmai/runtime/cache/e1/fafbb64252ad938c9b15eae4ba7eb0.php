<?php
//000000604800
 exit();?>
{"user":{"id":1,"uid":"","ue_account":"tst","cash_pledge":"0.00","ue_phone":"tst","qq_no":"","email":"","type":null,"create_at":"","last_login_at":"","bank_card":"","status":0,"access_token":""},"access_token":"3fdb3a904022b85647d1a9691890a160","expire_in":604800,"refresh_token":"7371d54795b99fad5433f85103c9e8c2","timestamp":1559701371,"scope":""}