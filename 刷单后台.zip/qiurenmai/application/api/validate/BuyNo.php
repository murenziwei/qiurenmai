<?php
namespace app\api\validate;


class BuyNo extends BaseVali
{
    protected $rule = [
        'platform_type' => 'require|number|between:1,3',
        'name' => 'require',
        'often_area' => 'require',
        'ip_img' => 'require',
        'wang_img' => 'require',
        'location' => 'require',
        'street' => 'require',
        'phone' => 'require|isMobile',
        //'location' => 'require',
        'zhifu_img' => 'require',
        'wang_id' => 'require',
        'zhifu_name'  =>  'require',
        'sex'  => 'require|number|between:1,2',
    ];

    protected $field = [
        'platform_type' => '平台',
        'name' => '收货人姓名',
        'often_area' => '旺旺常用登录地',
        'ip_img' => ' IP所在地截图',
        'wang_img' => '旺旺个人档案截图',
        'location' => '所在地区',
        'street' => '街道地址',
        'phone' => '收货人手机',
        //'location' => 'require',
        'zhifu_img' => ' 支付宝实名认证截图',
        'wang_id' => '旺旺ID',
        'zhifu_name'  =>  '支付宝认证姓名',
        'sex'  => '性别',
    ];

}