<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 13:25
 */

namespace app\admin\entity;


use app\common\entity\BaseEntity;

class System extends BaseEntity
{

}