<?php
namespace app\api\validate;


class Member extends BaseVali
{
    protected $rule = [
        'ue_account'  => 'require|isMobile',
        'phone_code' => 'require',
        'ue_password' => 'require|max:50',
        'confirm_password' => 'require|confirm:ue_password',
        'qq_no' => 'require|isQQ',
        'pcode' => 'require',
        'type'  =>  'require|between:1,2'
    ];


    protected $field = [
        'ue_account'  => '手机号',
        'phone_code' => '验证码',
        'ue_password' => '密码',
        'confirm_password' => '确认密码',
        'qq_no' => 'QQ',
        'pcode' => '邀请码',
        'type'  =>  '身份类型'
    ];
}