<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/6
 * Time: 17:33
 */

namespace app\common\logic;

use app\common\BaseModel;
use app\common\entity\Article as articleEntity;
use app\common\model\Article as articleModel;
use think\Db;
use think\Exception;

class Article extends BaseModel
{
    public $articleEntity;

    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->articleEntity = new articleEntity();
    }

    /**
     * 获取分页列表
     * @param int $limit
     * @return array
     */
    public function getList(int $limit=10){
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->articleEntity->setTitle($this->requestData['search']);
            $map[] = ['title','like',$this->articleEntity->getTitle()];
        }
        if(isset($this->requestData['type'])&&!empty($this->requestData['type'])){
            $this->articleEntity->setType($this->requestData['type']);
            $map[] = ['type','=',$this->requestData['type']];
        }
        if(empty($map))
            $map = "1=1";
        $list = articleModel::pageList($map,'*',$limit,'created_at desc');
        $list->each(function($item,$key){
            $item['type_name'] = $item['type']==1?'帮助中心':'app公告';
        });
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function del(){
        try {
            if (!array_key_exists('id', $this->requestData) && !empty($this->requestData['id']))
                return $this->failReturn('请选择对应文章');
            if (!is_array($this->requestData['id'])) {
                $res = articleModel::deleteByKey(['id' => $this->requestData['id']]);
            } else {
                $res = Db::table('__ARTICLE__')->delete($this->requestData['id']);
            }
            if ($res) {
                return $this->successReturn('删除成功');
            } else {
                return $this->failReturn('删除失败');
            }
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function saveData(){
        try {
            if ($this->requestData['type'] == 3) {
                $info = articleModel::findOne(array('type' => 3));
                if (empty($info)) {
                    $res = articleModel::createData(array('content' => htmlspecialchars_decode($this->requestData['content']), 'type' => 3));
                } else {
                    $res = articleModel::updateDatas(array('content' => htmlspecialchars_decode($this->requestData['content']), 'type' => 3), ['id' => $info['id']]);
                }

                if (!$res)
                    return $this->failReturn('操作失败');
                return $this->successReturn('操作成功');
            }

            if (!array_key_exists('title', $this->requestData) || empty($this->requestData['title']))
                return $this->failReturn('标题不能为空');
            if (!array_key_exists('content', $this->requestData) || empty($this->requestData['content']))
                return $this->failReturn('内容不能为空');
//        if(!array_key_exists('type',$this->requestData)||empty($this->requestData['type']))
//            return $this->failReturn('请选择类型');
            if (!array_key_exists('desc', $this->requestData) || empty($this->requestData['desc']))
                $desc = get_plain_text($this->requestData['content']);
            else
                $desc = $this->requestData['desc'];
            $this->articleEntity->setTitle($this->requestData['title']);
            $this->articleEntity->setDesc($desc);


            $this->articleEntity->setType($this->requestData['type']);
            $content = htmlspecialchars($this->requestData['content']);
            $this->articleEntity->setContent($content);
//        $this->articleEntity->setStatus($this->requestData['status']);
            $params = $this->articleEntity->params();
            $params['status'] = $this->requestData['status'];
            if (array_key_exists('id', $this->requestData) && !empty($this->requestData['id'])) {
                $res = articleModel::updateDatas($params, ['id' => $this->requestData['id']]);
            } else {
                $params['created_at'] = time();
                $res = articleModel::createData($params);
            }
            if (!$res)
                return $this->failReturn('操作失败');
            return $this->successReturn('操作成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }


}