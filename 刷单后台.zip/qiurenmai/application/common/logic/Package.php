<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\13 0013
 * Time: 17:27
 */

namespace app\common\logic;

use app\common\model\Package as packageModel;
use app\common\BaseModel;
use think\Db;
use think\Exception;

class Package extends BaseModel
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

    /**
     * 获取分页列表
     * @param int $limit
     * @return array
     */
    public function getList(int $limit=10){
        $map = ['is_del'=>0];
        $list = packageModel::pageList($map,'*',$limit,'created_at desc');
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function del(){
        try {
            if (!array_key_exists('id', $this->requestData) && !empty($this->requestData['id']))
                return $this->failReturn('请选择对应文章');
            if (!is_array($this->requestData['id'])) {
                $res = packageModel::updateDatas(['is_del' => 1], ['id' => $this->requestData['id']]);
            } else {
                $ids = implode(',', $this->requestData['id']);
                $res = packageModel::updateDatas(['is_del' => 1], "id in ({$ids})");
            }
            if ($res) {
                return $this->successReturn('删除成功');
            } else {
                return $this->failReturn('删除失败');
            }
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function saveData(){
        try {
            if (!array_key_exists('name', $this->requestData) || empty($this->requestData['name']))
                return $this->failReturn('套餐名不能为空');
            if (!array_key_exists('num', $this->requestData) || empty($this->requestData['num']))
                return $this->failReturn('数量不能为空');
            $params = [
                'name' => $this->requestData['name'],
                'num' => $this->requestData['num'],
                'sort' => $this->requestData['sort'],
                'is_del' => 0,
            ];
            if (array_key_exists('id', $this->requestData) && !empty($this->requestData['id'])) {
                $res = packageModel::updateDatas($params, ['id' => $this->requestData['id']]);
            } else {
                $params['created_at'] = time();
                $res = packageModel::createData($params);
            }
            if (!$res)
                return $this->failReturn('操作失败');
            return $this->successReturn('操作成功');
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }
}