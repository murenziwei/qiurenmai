<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 9:50
 */

namespace app\common\logic;

use app\common\BaseModel;
use app\common\entity\Member as memberEntity;
use app\api\model\Member as apiMemberModel;
use app\common\model\Member as memberModel;
use app\common\model\MemberThaw as memberThawModel;
use app\common\model\Recharge as rechargeModel;
use app\common\model\Deduction as deductionModel;
use app\common\model\UserMinutiae as userMinutiaeModel;
use app\common\service\Excel;
use think\Db;
use think\Exception;

class Member extends BaseModel
{
    public $memberEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->memberEntity = new memberEntity();
    }

    /**
     * 获取分页列表
     * @param int $type
     * @param int $limit
     * @return array
     */
    public function getPageList(int $limit=10){
        $map = "1=1";
        $search = [
            'search'=>'',
            'p_account'=>'',
            'start_date'=>'',
            'end_date'=>'',
            'sort'=>'0',
            'field'=>'',
            'p'=>1,
        ];
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $this->memberEntity->setUePhone($this->requestData['search']);
            $this->memberEntity->setUeAccount($this->requestData['search']);
            $map = "(ue_phone like '%{$this->requestData['search']}%' OR ue_account like '%{$this->requestData['search']}%')";
            $search['search'] = $this->requestData['search'];
        }
        if(isset($this->requestData['start_date'])&&!empty($this->requestData['start_date'])){
            $start_date = strtotime($this->requestData['start_date']);
            if($map=="1=1"){
                $map = "(ue_reg_time >= {$start_date} OR ue_activeTime >= {$start_date})";
            }else{
                $map .= "AND (ue_reg_time >= {$start_date} OR ue_activeTime >= {$start_date})";
            }
            $search['start_date'] = $this->requestData['start_date'];
        }
        if(isset($this->requestData['end_date'])&&!empty($this->requestData['end_date'])){
            $end_date = strtotime($this->requestData['end_date']);
            if($map=="1=1"){
                $map = "(ue_reg_time <= {$end_date} OR ue_activeTime <= {$end_date})";
            }else{
                $map .= " AND (ue_reg_time <= {$end_date} OR ue_activeTime <= {$end_date})";
            }
            $search['end_date'] = $this->requestData['end_date'];
        }
        $sort = 'DESC';
        if(isset($this->requestData['sort'])&&$this->requestData['sort']==1){
            $sort = 'ASC';
            $search['sort'] = 1;
        }
        $order_field = 'ue_reg_time';
        if(isset($this->requestData['field'])&&!empty($this->requestData['field'])){
            $order_field = $this->requestData['field'];
        }
        $search['field'] = $order_field;
        $list = memberModel::pageList($map,'*',$limit,"{$order_field} {$sort}");
        $list->each(function($item,$key){
            $item['is_vip'] = $item['p_num']?1:0;
            $item['vip_count'] = memberModel::countData('pid='.$item['id'].' and p_num>=1');
            $item['ordinary_count'] = memberModel::countData(['pid'=>$item['id'],'p_num'=>0]);
            $item['team_count'] = apiMemberModel::getTeamCount($item['id']);
            $p_user = memberModel::findOne(['id'=>$item['pid']]);
            $item['p_account'] = $p_user['ue_account'];
            $item['p_name'] = $p_user['ue_name'];
            $item['p_avatar'] = $p_user['avatar'];
        });
        return array_merge(['list'=>$list,'count'=>$list->total(),'page'=>$list->render()],$search);
    }

    public function updateStatus(){
        try {
            $this->memberEntity->setId($this->requestData['id']);
            $info = memberModel::findOne($this->memberEntity->params());
            if (!$info)
                return $this->failReturn('数据不存在');
            if ($this->requestData['status'] == 0) {
                $data['ue_status'] = 0;
            } elseif ($this->requestData['status'] == 1) {
                $data['ue_status'] = 1;
            } else {
                $data['ue_status'] = 2;
            }
            $res = memberModel::updateDatas($data, $this->memberEntity->params());
            if (!$res)
                return $this->failReturn('修改失败');
            return $this->successReturn('修改成功', $data);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function updateIdentity(){
        try {
            $this->memberEntity->setId($this->requestData['id']);
            $info = memberModel::findOne($this->memberEntity->params());
            if (!$info)
                return $this->failReturn('数据不存在');
            if ($this->requestData['status'] == 0) {
                $data['is_internal'] = 0;
            } elseif ($this->requestData['status'] == 1) {
                $data['is_internal'] = 1;
            }
            $res = memberModel::updateDatas($data, $this->memberEntity->params());
            if (!$res)
                return $this->failReturn('修改失败');
            return $this->successReturn('修改成功', $data);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function del(){
        try {
            if (!array_key_exists('id', $this->requestData) && !empty($this->requestData['id']))
                return $this->failReturn('请选择角色');
            if (!is_array($this->requestData['id'])) {
                $res = memberModel::deleteByKey(['id' => $this->requestData['id']]);
            } else {
                $res = Db::table('__MEMBER__')->delete($this->requestData['id']);
            }
            if ($res) {
                return $this->successReturn('删除成功');
            } else {
                return $this->failReturn('删除失败');
            }
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function recharge(){
        try {

            if (!array_key_exists('type', $this->requestData) || !in_array($this->requestData['type'],[1,2]))
                return $this->failReturn('操作无效');
            if($this->requestData['type']==1)
                $text = '充值';
            else
                $text = '扣币';
            if (!array_key_exists('num', $this->requestData) || empty($this->requestData['num']))
                return $this->failReturn("请填写{$text}数量");
            if (!array_key_exists('from', $this->requestData) || empty($this->requestData['from']))
                return $this->failReturn("请选择{$text}去向");
            if (!array_key_exists('id', $this->requestData) || empty($this->requestData['id']))
                return $this->failReturn("请选择{$text}对象");
            if (!in_array($this->requestData['from'], [1, 2]))
                return $this->failReturn("{$text}去向无效");
            Db::startTrans();
            $params = [
                'user_id' => $this->requestData['id'],
                'num' => $this->requestData['num'],
                'actual_num' => $this->requestData['num'],
                'status' => 1,
                'from' => $this->requestData['from'],
                'is_admin' => 1,
                'created_at' => time(),
            ];
            if($this->requestData['type']==1) {
                if ($this->requestData['from'] == 1) {//QDC
                    $res1 = memberModel::where(['id' => $this->requestData['id']])->setInc('ue_qdc', $this->requestData['num']);
                } else {//PDC
                    $res1 = memberModel::where(['id' => $this->requestData['id']])->setInc('ue_pdc', $this->requestData['num']);
                }
                $res2 = rechargeModel::createData($params);
                $res3 = userMinutiaeModel::addMinutiaeLog($this->requestData['id'], $res2['id'], $this->requestData['from'], 3, $this->requestData['num']);
                $res = $res1 && $res2 && $res3;
            }else{
                $user = memberModel::findOne(['id'=>$this->requestData['id']]);
                if ($this->requestData['from'] == 1) {//QDC
                    if($user['ue_qdc']<$this->requestData['num'])
                        return $this->failReturn("余额不足");
                    $res1 = memberModel::where(['id' => $this->requestData['id']])->setDec('ue_qdc', $this->requestData['num']);
                } else {//PDC
                    if($user['ue_pdc']<$this->requestData['num'])
                        return $this->failReturn("余额不足");
                    $res1 = memberModel::where(['id' => $this->requestData['id']])->setDec('ue_pdc', $this->requestData['num']);
                }
                $res2 = deductionModel::createData($params);
//                $res3 = userMinutiaeModel::addMinutiaeLog($this->requestData['id'], $res2['id'], $this->requestData['from'], 3, $this->requestData['num'],2);
//                $res = $res1 && $res2 && $res3;
                $res = $res1 && $res2;
            }
            if (!$res) {
                Db::rollback();
                return $this->failReturn("{$text}失败");
            }
            Db::commit();
            return $this->successReturn("{$text}成功");
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }

    public function getRechargeList(int $user_id,int $type,int $limit=10){
        $map = ['user_id'=>$user_id,'is_admin'=>1];
        if($type==1) {
            $list = rechargeModel::pageList($map, '*', $limit, 'created_at desc');
        }else{
            $list = deductionModel::pageList($map, '*', $limit, 'created_at desc');
        }
        return ['list'=>$list,'count'=>$list->total(),'page'=>$list->render()];
    }

    public function getThawList(int $limit=10){
        $search = [
            'start_date'=>'',
            'end_date'=>'',
            'search'=>'',
        ];
        $map = '';
        if(isset($this->requestData['start_date'])&&!empty($this->requestData['start_date'])){
            $start_date = strtotime($this->requestData['start_date']);
            $map .= "update_at >= {$start_date} AND ";
            $search['start_date'] = $this->requestData['start_date'];
        }
        if(isset($this->requestData['end_date'])&&!empty($this->requestData['end_date'])){
            $end_date = strtotime($this->requestData['end_date'].' 23:59:59');
            $map .= " update_at <= {$end_date} AND ";
            $search['end_date'] = $this->requestData['end_date'];
        }
        if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
            $user_ids = memberModel::whereLike('phone',"%{$this->requestData['search']}%")->column('id');
            $user_ids = implode(',',$user_ids);
            $map = "(user_id in ({$user_ids}))";
            $search['search'] = $this->requestData['search'];
        }
        $list = memberThawModel::pageList($map,'*',$limit,"update_at DESC");
        $list->each(function($item,$key){
            $user = memberModel::findOne(['id'=>$item['user_id']]);
            $item['ue_phone'] = $user['ue_phone'];
        });
        return array_merge(['list'=>$list,'count'=>$list->total(),'page'=>$list->render()],$search);
    }

    public function export(){
        try{
            $map = "1=1";
            if(isset($this->requestData['search'])&&!empty($this->requestData['search'])) {
                $this->memberEntity->setUePhone($this->requestData['search']);
                $this->memberEntity->setUeAccount($this->requestData['search']);
                $map = "(ue_phone like '%{$this->requestData['search']}%' OR ue_account like '%{$this->requestData['search']}%')";
            }
            if(isset($this->requestData['start_date'])&&!empty($this->requestData['start_date'])){
                $start_date = strtotime($this->requestData['start_date']);
                if($map=="1=1"){
                    $map = "(ue_reg_time >= {$start_date} OR ue_activeTime >= {$start_date})";
                }else{
                    $map .= "AND (ue_reg_time >= {$start_date} OR ue_activeTime >= {$start_date})";
                }
            }
            if(isset($this->requestData['end_date'])&&!empty($this->requestData['end_date'])){
                $end_date = strtotime($this->requestData['end_date']);
                if($map=="1=1"){
                    $map = "(ue_reg_time <= {$end_date} OR ue_activeTime <= {$end_date})";
                }else{
                    $map .= " AND (ue_reg_time <= {$end_date} OR ue_activeTime <= {$end_date})";
                }
            }
            $sort = 'DESC';
            if(isset($this->requestData['sort'])&&$this->requestData['sort']==1){
                $sort = 'ASC';
            }
            $order_field = 'ue_reg_time';
            if(isset($this->requestData['field'])&&!empty($this->requestData['field'])){
                $order_field = $this->requestData['field'];
            }
            $select_field = "id,ue_phone,ue_name,code,ue_qdc,ue_pdc,ue_address,ue_pd_address,DATE_FORMAT(FROM_UNIXTIME(ue_reg_time),'%Y-%m-%d %H:%i:%s') as created_at,
            pid,p_num,ue_income,ue_sum,ue_reward,ue_reward_team,ue_status";
            if(isset($this->requestData['type'])&&$this->requestData['type']==1){
                $limit = ($this->requestData['p']-1)*10;
                $list = memberModel::paginates($map,$select_field,$limit,"{$order_field} {$sort}")->toArray()?:[];
            }else{
                $list = memberModel::where($map)->order("{$order_field} {$sort}")->field('*')->select()->toArray()?:[];
            }
            $header = ['手机号码','昵称','推荐码','是否VIP','QDC余额','QDC钱包地址','PDC余额','PDC钱包地址','直推好友数量',
                'VIP好友数量','团队人数','注册时间','推荐人','排单数量','累计静态收益','累计直推收益','累计团队收益','用户状态'];
            $body = [];
            foreach($list as $k => $val){
                $p_user = memberModel::findOne(['id'=>$val['pid']]);
                $body[$k][] = $val['ue_phone'];
                $body[$k][] = $val['ue_name'];
                $body[$k][] = $val['code'];
                $body[$k][] = $val['p_num']>0?'是':'否';
                $body[$k][] = (float)$val['ue_qdc'];
                $body[$k][] = $val['ue_address'];
                $body[$k][] = (float)$val['ue_pdc'];
                $body[$k][] = $val['ue_pd_address'];
                $body[$k][] = memberModel::countData(['pid'=>$val['id'],'p_num'=>0]);
                $body[$k][] = memberModel::countData('pid='.$val['id'].' and p_num>=1');
                $body[$k][] = apiMemberModel::getTeamCount($val['id']);
                $body[$k][] = $val['created_at'];
                $body[$k][] = $p_user['ue_name'];
                $body[$k][] = $val['p_num'];
                $body[$k][] = (float)$val['ue_sum'];
                $body[$k][] = (float)$val['ue_reward'];
                $body[$k][] = (float)$val['ue_reward_team'];
                $body[$k][] = $val['ue_status']==0?'正常':($val['status']==1?'已拉黑':'已冻结');
            }//var_dump($body);exit;
            Excel::export($header, $body);
        }catch (Exception $e){
            return $this->failReturn($e->getMessage());
        }
    }
}