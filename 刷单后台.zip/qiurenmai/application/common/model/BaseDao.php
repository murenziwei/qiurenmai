<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/27
 * Time: 8:56
 */

namespace app\common\model;

use think\facade\Request;
use app\common\BaseModel;

class BaseDao extends BaseModel
{
    public static function findOne($map,$field="*")
    {
        return self::field($field)->where($map)->find();
    }

    public static function findAll($map = [],$field = "*",$order = "",$page = 1,$limit = null)
    {
        return self::field($field)->where($map)->order($order)->page($page,$limit)->select();
    }

    public static function createData($data)
    {
        return self::create($data);
    }

    public static function updateDatas($data = [], $where = [])
    {
        return self::update($data, $where);
    }

    public static function deleteByKey($map = [])
    {
        if(empty($map)) return 0;
        return self::where($map)->delete();
    }

    public static function countData($where = [],$field='*'){
        return self::where($where)->count($field);
    }

    /**
     * 分页
     * @param array $where
     * @param string $field
     * @param string $order
     * @param $page 页码
     * @param $limit 每页条数
     * @return array
     */
    public static function pagination($where = [],$field = '*',$order = "",$page = 1,$limit = null){
        $count = self::where($where)->count();
        $list = array();
        if($count > 0){
            $list = self::where($where)->field($field)->order($order)->page($page,$limit)->select();
        }
        return array(
            'list' => $list,
            'page' => $page,
            'limit' => $limit,
            'count' => $count,
        );
    }

    public static function pageList($where = [],$field = '*',$limit = 10,$order = ""){
        return self::where($where)->field($field)->order($order)->paginate($limit,false,['query'=>Request::get()]);
    }


    public static function paginates($where = [],$field = '*',$limit = 5,$order = ""){
        return self::where($where)->field($field)->order($order)->limit($limit,10)->select();
    }
}


