<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\5\13 0013
 * Time: 18:45
 */

namespace app\lib\exception;


class ExcelException extends BaseException
{
    public $code = 0;
    public $message = '内存溢出';
    public $errorCode = 20001;
}