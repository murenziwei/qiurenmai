<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Date: 2018/12/6
 * Time: 15:58
 */

namespace app\admin\controller;

use think\Db;
use app\admin\validate\Package as PackageValidate;
use app\api\model\Minutiae;
use app\api\model\Member as MemberModel;

class Member extends Base
{
    public function packageList(){
        $list = Db::name("package") ->where(["is_del"=>0]) ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }


    public function addPackage(){
        return $this ->fetch();
    }


    public function doAddPackage(){
        $data = input('post.');

        $validate = new PackageValidate();
        if (!$validate->check($data)) {
            $this ->error($validate->getError());
        }
        $data['created_at'] = time();
        $res = Db::name('package') ->insert($data);
        if($res){
            $this ->success("添加成功");
        }else{
            $this ->error("添加失败");
        }

    }


    public function doDelPackage(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $is_del = Db::name('package') ->where('id',$id) ->update(['is_del'=>1]);
        if($is_del){
           $this ->success("删除成功");
        }else{
            $this ->error("删除失败");
        }
    }


    public function updPackage(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数错误");
        }
        $data = Db::name('package') ->where(['id'=>$id,'is_del'=>0]) ->find();
        if(empty($data)){
             $this ->error("数据获取失败");
        }
        $this ->assign("data",$data);
        return $this ->fetch();
    }


    public function doUpdPackage(){
        $data = input("post.");
        if(!is_numeric($data['id'])){
            $this ->error("参数错误");
        }
        $validate = new PackageValidate();
        if (!$validate->check($data)) {
            $this ->error($validate->getError());
        }
        $res = Db::name('package') ->where(['id'=>$data['id']]) ->update($data);
        if($res !== false){
            $this ->success("修改成功");
        }else{
            $this ->error("修改失败");
        }
    }

    public function shopList(){
        $data = input();
        $where = search($data);
        $list = Db::name("member") ->where(["type"=>1]) ->where($where) ->field("id,ue_account,qq_no,ue_jin") ->paginate(15,false,$data);
        $this ->assign("list",$list);
        $search_id = !empty($data['id'])?$data['id']:'';
        $this->assign('search_id',$search_id);
        return $this ->fetch();
    }

    public function bindShopList(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $list = Db::name("bind_shop") ->where(["user_id"=>$id,"is_del"=>0]) ->select();;
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    //type1商家2买号
    public function doCkShop(){
        $id = input("post.id");
        $status = input("post.status");
        if(!is_numeric($id) || !is_numeric($status)){
            $this ->error("参数有误");
        }

        $table = $this ->getTable();
        $res = Db::name($table) ->where(["id"=>$id]) ->update(["status"=>$status]);
        if($res !== false){
            $this ->success("审核成功");
        }else{
            $this ->error("审核失败");
        }
    }


    private function getTable(){
        $type = input("post.type");
        if(!is_numeric($type)){
            $this ->error("参数有误");
        }
        if($type == 1){
            $table = "bind_shop";
        }else{
            $table = "bind_buy_no";
        }
        return $table;
    }

    public function sendTaskList(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $list = Db::name("son_task") ->alias("t1")
                                     ->join("sd_bind_shop t2","t1.shop_wang_id = t2.wangwang_id")
                                     ->where(["t1.shop_id"=>$id])
                                     ->where("t1.status","neq",-1)
                                     ->field("t1.id,t2.shop_name,t1.status,t1.start_at")
                                     ->select();
        $this ->assign("list",$list);
        return $this ->fetch();
    }
    //任务取消
    public function cancelTask(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $this ->afterCancel($id);
        if($res !== false){
            $this ->success("任务取消成功");
        }else{
            $this ->error("任务取消失败");
        }
    }

    //取消之后操作私类
    private function afterCancel($id){
        $son_task = Db::name("son_task") ->where(["id"=>$id]) ->field("id,shop_id,status,commission,add_service_fee,cash_pledge,comment_info_id") ->find();
        if($son_task["status"] < 3){
            $this ->error("刷手还没操作任务");
        }
        if($son_task["status"] == 6){
            $this ->error("订单已完成");
        }
        Db::startTrans();
        try{
            $conf = ConfigModel::getConf("jin");
            $comment_fee = Minutiae::getComiss($son_task["comment_info_id"],$conf);
            //空包不退
            $empty_fee = Db::name("fee_info") ->where(["task_id"=>$id]) ->value("empty_parcel_fee");
            if(empty($empty_fee)){
                $this ->error("费用信息未找到");
            }
            $sum_fee = $son_task["commission"] + $son_task["add_service_fee"] + $son_task["cash_pledge"] + $comment_fee - $empty_fee;
            $after_num = MemberModel::afterRes($son_task["shop_id"],$sum_fee);
            Db::name("son_task") ->where(["id"=>$id]) ->update(["status"=>-1]);
            //写记录
            Minutiae::insertMinu($son_task["shop_id"],4,"任务取消退还,任务编号：".$son_task["id"],$sum_fee,$after_num);
            Db::commit();
            $this ->success("取消成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            $this ->error($e->getMessage());
        }
    }

    //刷手管理
    public function consumerList(){
        $data = input();
        $where = search($data);
        $list = Db::name("member") ->where(["type"=>2]) ->where($where) ->field("id,ue_account,qq_no,ue_jin") ->paginate(15,false,$data);
        $this ->assign("list",$list);
        $search_id = !empty($data['id'])?$data['id']:'';
        $this->assign('search_id',$search_id);
        return $this ->fetch();
    }

    //商家账户明细
    public function minuList(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $list = Db::name("user_minutiae") ->where(["user_id"=>$id]) ->field("id,created_at,num,note,after_num") ->select();
        // ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    //绑定的账户
    public function bindAccountList(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $list = Db::name("bind_buy_no") ->where(["user_id"=>$id,"is_del"=>0]) ->select();
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    //设置钻石级别
    public function doSetLevel(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $res = Db::name("bind_buy_no") ->where(["id"=>$id]) ->update(["is_level"=>1]);
        if($res !== false){
            $this ->success("修改成功");
        }else{
            $this ->error("修改失败");
        }
    }

    //接手的任务
    public function acceptTaskList(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $list = Db::name("son_task") ->where(["user_id"=>$id]) ->field("id,wangwang_id,status,accept_at") ->select();
        $this ->assign("list",$list);
        return $this ->fetch();
    }
    //账号
    public function Account(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $this ->assign("id",$id);
        return $this ->fetch();
    }
    //冻结账号
    public function doAccount(){
        $data = input("post.");
        if(!is_numeric($data["user_id"]) || empty($data["note"])){
            $this ->error("参数有误");
        }
        switch ($data["day"]) {
            case 3:
                $data["freeze_day"] = "3天";
                break;
            case 5:
                $data["freeze_day"] = "5天";
                break;
            case 10:
                $data["freeze_day"] = "10天";
                break;
            case 0:
                $data["freeze_day"] = "永久";
                break;
            default:
                $this ->error("类型错误");
                break;
        }
        $data["freeze_date"] = $data["day"] * (60*60*24) + time();
        $data["create_at"] = time();
        unset($data["day"]);
        $res = Db::name("freeze") ->insert($data);
        if($res){
            $this ->success("操作成功");
        }else{
            $this ->error("操作失败");
        }
    }

    public function backTopUp(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $this ->assign("id",$id);
        return $this ->fetch();
    }

    //执行人工充值
    //id:用户id
    public function doBackTopUp(){
        $id = input("post.id");
        $jin = input("post.jin");
        if(!is_numeric($id) || !is_numeric($jin)){
            $this ->error("参数有误");
        }
        $member = Db::name("member") ->where(["id"=>$id]) ->field("ue_jin,commission,type") ->find();
        if(empty($member)){
            exit(ajaxReturn([],0,"用户未找到"));
        }
        if($member["type"] == 1){
            $after_num = $jin + $member["ue_jin"];
            $update = ["ue_jin"=>$after_num];
            $from = 1;
        }else{
            $after_num = $jin + $member["commission"];
            $update = ["commission"=>$after_num];
            $from = 2;
        }


        Db::startTrans();
        try{
            Db::name("member") ->where(["id"=>$id]) ->update($update);
            //写记录
            Minutiae::insertMinu($id,5,"后台充值",$jin,$after_num,$from);
            Db::commit();
            exit(ajaxReturn([],1,"充值成功"));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            $this ->error($e->getMessage());
        }
    }

    public function check(){
        $list = Db::name("bind_buy_no") ->alias("t1")
                                        ->join("sd_member t2","t1.user_id=t2.id")
                                        ->where(["t1.status"=>0])
                                        ->field("t1.id,t1.status,t1.wang_id,t2.ue_account,t1.create_at")
                                        ->paginate(15);
        $this ->assign("list",$list);
        return $this ->fetch();
    }

    public function buyNoInfo(){
        $id = input("get.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $data = Db::name("bind_buy_no") ->where(["id"=>$id,"status"=>0]) ->find();
        $this ->assign("data",$data);
        return $this ->fetch();
    }

    public function doDelBind(){
        $id = input("post.id");
        if(!is_numeric($id)){
            $this ->error("参数有误");
        }
        $type = input("post.type");
        if($type == 1){
            $table = "bind_shop";
        }elseif($type == 2){
            $table = "bind_buy_no";
        }else{
            $this ->error("参数有误");
        }
        $is_del = Db::name($table) ->where('id',$id) ->update(['is_del'=>1]);
        if($is_del){
           $this ->success("删除成功");
        }else{
            $this ->error("删除失败");
        }
    }

    public function setRoot(){
        $id = input("post.id");
        $status = input("post.status");
        if(!is_numeric($id) || !is_numeric($status)){
            $this ->error("参数有误");
        }

        $res = Db::name('bind_buy_no') ->where('id',$id) ->update(['is_down_root'=>$status]);
        if($res){
           $this ->success("操作成功");
        }else{
            $this ->error("操作失败");
        }
    }
}