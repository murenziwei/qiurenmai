<?php
//000000604800
 exit();?>
{"user":{"id":1,"uid":"","ue_account":"tst","cash_pledge":"0.00","ue_phone":"tst","qq_no":"","email":"","type":null,"create_at":"","last_login_at":"","bank_card":"","status":0,"access_token":""},"access_token":"98242f2c10bce406ea9b1c63c53a41cc","expire_in":604800,"refresh_token":"7f5120f4826c9ee9c0924330f3372cb0","timestamp":1559701152,"scope":""}