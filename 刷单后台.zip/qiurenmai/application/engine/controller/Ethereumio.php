<?php
/**
 * Created by PhpStorm.
 * User: xiao
 * Date: 2019/1/10
 * Time: 17:38
 */

namespace app\engine\controller;


use app\api\model\Member;
use app\common\BaseModel;
use app\common\model\Config;
use app\common\model\TurnoverLog;
use app\engine\service\Transaction;
use app\engine\service\Trusteeship;
use think\Db;
use think\Request;
use think\Validate;

class Ethereumio
{
    private $ratio = 10; // 挂卖挂买手续费 百分比

    /**
     */
    public function createAccount(Request $request){

    }

    /**
     * @return string|\think\response\Json
     * 挂卖挂卖
     */
    public function Hang_Business(){
        $user_num = '100';
        $receivables = '收款账号';
        $data = [
            'u_id'=>'12',
            'currency'=>'1',//币种
            'number'=>'10',//最终得到的币
            'price'=>'1',
            'pay_mode'=>'1',//0挂买卖者选择 1微信 2支付宝 3银行卡
            'attribute'=>'1',//0挂买 1挂卖
            'receivables'=>$receivables
        ];
        $idratio = '50';//如果身份为顶级或合伙人 需要减去的手续费
        return Trusteeship::Hang_Business($data,$this->ratio,$user_num,$idratio);
    }

    /**
     * @return \think\response\Json
     * 我的交易
     */
    public function Business_list(){
        $user_id = '1';
        $type = '1';//0挂买挂卖记录 1我买我卖记录
        return Trusteeship::Business_list($user_id,$type);
    }

    /**
     * @return \think\response\Json
     * 挂买挂卖列表数据
     */
    public function Pay_list(){
        $type = '0';//0挂买数据 1挂卖数据
        return Trusteeship::Pay_list($type);
    }
    /**
     *数据详情
     */
    public function Pay_details(){
        $oid = '1';
        return Trusteeship::Pay_details($oid);
    }

    //提交我要买我要卖
    public function My_Transaction(){
        $type = '1';//0我要买 1我要卖
        $oid = '1';
        $user_id = '2';
        return Trusteeship::My_Transaction($oid,$type,$user_id,$receivables='');
    }


    public function user_inspect(){
        $user_id = '1';
        $data = [
            'p_uid'=>'2',
            'identity'=>'3',
        ];
        return Transaction::user_inspect($user_id,$data);
    }

    public function user_recharge(){
        $user_id = '1';
        $currency = 'aih';
        $number = '100';
        $sql = 'setInc';//setDec
        $within = '5';
        $abroad = '1';
        $day = '90';
        return Transaction::user_recharge($user_id,$currency,$number,$sql,$within,$abroad,$day);
    }
    public function user_interest(){
        $config = Config::tpCache('base');
        $percent = $config['daily_income_ratio'];//当天百分比
        $Generation = $config['generation_ratio'];//一代返利百分比
        $two_generation = $config['second_ratio'];//二代返利百分比
        $three_generation = $config['three_ratio'];//三代返利百分比
        $Infinite = $config['infinite_ratio'];//无限层返利百分比
        $identitys = [$config['primary_ratio'], $config['intermediate_ratio'], $config['advanced_ratio'], $config['global_ratio']];//初级返利比例百分比 中级返利比例百分比 高级返利比例百分比 全球节点人返利比例百分比
        $identitys_name = ['初级返利', '中级返利', '高级返利', '全球节点人返利'];//提示语用于写入提示
        $list = Db::table('tp_Utrusteeship')->select();
        foreach ($list as $k => $v){
//            return json_encode($v);
            Transaction::user_interest($v['uid'],'aih',$percent,$Generation,$two_generation,$three_generation,$Infinite,$identitys,$identitys_name);
            Transaction::user_interest($v['uid'],'usdt',$percent,$Generation,$two_generation,$three_generation,$Infinite,$identitys,$identitys_name);
            Transaction::user_interest($v['uid'],'bth',$percent,$Generation,$two_generation,$three_generation,$Infinite,$identitys,$identitys_name);
            Transaction::user_interest($v['uid'],'eos',$percent,$Generation,$two_generation,$three_generation,$Infinite,$identitys,$identitys_name);
        }
        return;
    }

    public function Rebate(){
        $list = Db::table('tp_interest')->where(['operation'=>'0'])->select();
        $base = new BaseModel();
        foreach ($list as $k=>$v){
            if ($v['uid']){
                Member::where(['id' => $v['uid']])->setInc('aih', $v['number']);
                TurnoverLog::addTurnoverLog($v['uid'],29,1,$v['number'],1,0,'托管利息');
                if (Db::table('tp_interest')->where(['oid'=>$v['oid']])->update(['operation'=>'2','end_time'=>date("Y-m-d h:i:s")])){
                    continue;
                }
            }else{
                return $base->failReturn('请联系程序员。');
                break;
            };
        }
    }

//    public function Rebate(){
//        $list = Db::table('tp_interest')->where(['operation'=>'0'])->select();
//        $base = new BaseModel();
//        foreach ($list as $k=>$v){
//            if (json_decode(Transaction::user_recharge($v['uid'],$v['currency'],$v['number']),true)['code'] == '1'){
//                if (Db::table('tp_interest')->where(['oid'=>$v['oid']])->update(['operation'=>'2','end_time'=>date("Y-m-d h:i:s")])){
//                    continue;
//                }
//            }else{
//                return $base->failReturn('请联系程序员。');
//                break;
//            };
//        }
//    }
}