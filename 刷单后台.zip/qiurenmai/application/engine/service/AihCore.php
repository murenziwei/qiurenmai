<?php
/**
 * Created by PhpStorm.
 * User: xiao
 * Date: 2019/1/10
 * Time: 18:30
 */

namespace app\engine\service;


use think\Exception;
use Web3\Contract;
use Web3\Web3;

class AihCore
{
    public $WEB3, $contract;
    private $ABI = '[{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"INITIAL_SUPPLY","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_subtractedValue","type":"uint256"}],"name":"decreaseApproval","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_addedValue","type":"uint256"}],"name":"increaseApproval","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"name":"owner","type":"address"},{"indexed":true,"name":"spender","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"from","type":"address"},{"indexed":true,"name":"to","type":"address"},{"indexed":false,"name":"value","type":"uint256"}],"name":"Transfer","type":"event"}]';
    private $ContactAddr = '0x86dc652b6f904da80ea0e80c1127b2006bf8dd86'; // 合约地址
    public function __construct($host = 'http://65.49.223.204:8545')   //  节点服务器 当前为测试服务器
    {
        $this->WEB3 = new Web3($host);  // 节点实例化
        $this->contract = new Contract($host, $this->ABI); // 智能合约
    }

    /**
     * 获取所有AIH地址列表
     * @return array
     */
    public function getAccountList()
    {
        $list = [];
        $this->WEB3->personal->listAccounts(function ($E, $accounts) use (&$list) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $list = $accounts;
        });
        return $list;
    }

    /**
     * 创建新账号
     * @param string $password = "00008888"
     * @return string
     */
    public function newAccount($password)
    {
        return '0x'.$this->GetRandStr(60);
        $newAccount = null;
        $this->WEB3->personal->newAccount($password, function ($E, $account) use (&$newAccount) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $newAccount = $account;
        });
        return $newAccount;
    }

    public function GetRandStr($length){
        $str='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $len=strlen($str)-1;
        $randstr='';
        for($i=0;$i<$length;$i++){
            $num=mt_rand(0,$len);
            $randstr .= $str[$num];
        }
        return $randstr;
    }
    /**
     * 解锁账号
     * @param $acount
     * @param $pass
     * @param int $time
     * @return bool
     */
    public function unlockAccount($acount, $pass, $time = 3600)
    {
        $res = false;
        $this->WEB3->personal->unlockAccount($acount, $pass, $time, function ($E, $data) use (&$res) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $res = $data ? true : false;
        });
        return $res;
    }

    /**
     * 导入钱包 以太坊私钥
     * @param $keydata
     * @param $passphrase
     * @return string
     */
    public function importRawKey($keydata, $passphrase)
    {
        $acount = null;
        $this->WEB3->personal->importRawKey($keydata, $passphrase, function ($E, $data) use (&$acount) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $acount = $data;
        });
        return $acount;
    }

    /**
     * 发起交易
     * @param $password
     * @param $form
     * @param $to
     * @param $number
     * @return array
     */
    public function sendTransaction($password, $form, $to, $number)
    {
        $Tx = [
            "form" => $form,
            "to" => $this->ContactAddr,
            "value" => 0,
            "data" => '0xa9059cbb' . $to . $this->addPreZero(dechex($number)),
        ];
        $res = null;
        $this->WEB3->eth->getTransactionCount($form, "latest", function ($E, $data) use (&$res, &$Tx, &$password) {
            $Tx['nonce'] = hexdec($data->value) + 1;
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $this->WEB3->personal->sendTransaction($Tx, $password, function ($E, $data) use (&$res) {
                if ($E !== null) {
                    throw new Exception('错误:' . $E->getMessage(), 500);
                }
                $res = $data;
            });
        });
        return $this->getTransaction($res);  // 返回交易订单详情
    }

    /**
     * 获取订单记录
     * @param $transactionHash
     * @return null
     */
    public function getTransaction($transactionHash)
    {
        $res = null;
        $this->WEB3->eth->getTransaction($transactionHash, function ($E, $data) use (&$res) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $res = $data;
        });
        return $res;
    }

    /**
     * 查询余额 AIH
     * @param $acount
     * @return float
     */
    public function getBalance($acount)
    {
        $balance = 0;
        $this->contract->at($this->ContactAddr)->call('balanceOf', $acount, function ($E, $data) use (&$balance) {
            if ($E !== null) {
                throw new Exception('错误:' . $E->getMessage(), 500);
            }
            $balance = $data;
            foreach ($balance as $x) {
                $x->value = hexdec($x->value);
            }
        });
        return $balance;
    }

    // 补齐64位，不够前面用0补齐
    private function addPreZero($num)
    {
        $t = strlen($num);
        if ($t <= 2) {
            return $num;
        }
        $s = '';
        for ($i = 0; $i < 64 - $t; $i++) {
            $s = $s . '0';
        }
        return $s . substr($num, 2);
    }

}