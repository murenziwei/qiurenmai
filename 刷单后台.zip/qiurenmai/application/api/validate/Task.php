<?php
namespace app\api\validate;

use think\Validate;

class Task extends Validate
{
    protected $rule = [
        'task_type' => 'require|number|between:1,5',
        'shop_wang_id' => 'require',
        'is_top'  =>  'number|between:0,1',
        'restrict_sex'  => 'number|between:0,2',
        'restrict_level' => 'number|between:0,1',
        'is_favorites'  =>'number|between:0,1',
        'is_shopping_trolley' => 'number|between:0,1',
    ];


    protected $field = [
        'task_type' => '任务类型',
        'shop_wang_id' => '店主旺旺ID',
        'is_top'  =>  '置顶',
        'restrict_sex'  => '性别限制',
        'restrict_level' => '级别限制',
        'is_favorites'  =>'收藏',
        'is_shopping_trolley' => '加购',
    ];
}