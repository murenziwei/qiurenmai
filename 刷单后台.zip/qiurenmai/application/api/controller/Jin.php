<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-01 17:19:38
 */
namespace app\api\controller;

use think\Db;
use app\api\validate\Jin as JinVali;
use app\api\validate\BankCard as BankCardVali;
use app\api\model\Config as ConfigModel;
use app\api\model\Minutiae;

class Jin extends Base
{
    public function jinList(){
        $user_id = $this ->user["id"];
        $list = Db::name("user_minutiae") ->where(["user_id"=>$user_id]) ->field("from,note,num,created_at,after_num") ->order("created_at desc") ->paginate(config("app.page_num")) ->toArray();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }

    //充值提交
    public function topUpPost(){
        $data = input();
        $validate = new JinVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $data["user_id"] = $this ->user["id"];
        $data["create_at"] = time();
        unset($data["access_token"]);
        $res = Db::name("top_up") ->insert($data);
        if($res){
            exit(ajaxReturn([],1,"提交成功"));
        }else{
            exit(ajaxReturn([],0,"提交失败"));
        }
    }

    //充值提交表
    public function topUpList(){
        $user_id = $this ->user["id"];
        $list = Db::name("top_up") ->where(["user_id"=>$user_id]) ->field("money,create_at,bank,card_name") ->paginate(config("app.page_num")) ->toArray();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }



    //绑定银行卡
    public function doBindBankCard(){
        $data = input();
        $validate = new BankCardVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        $user_id = $this ->user["id"];
        $is_exist = Db::name("bind_bank_card") ->where(["user_id"=>$user_id]) ->find();

        unset($data["access_token"]);
        if($is_exist){
            $res = Db::name("bind_bank_card") ->where(["user_id"=>$user_id]) ->update($data);
        }else{
            $data["user_id"] = $user_id;
            $data["create_at"] = time();
            $res = Db::name("bind_bank_card") ->insert($data);
        }


        if($res !== false){
            exit(ajaxReturn([],1,'绑定成功'));
        }else{
            exit(ajaxReturn([],0,'绑定失败'));
        }
    }

    //已绑定银行卡数据
    public function bindBankCard(){
        $user_id = $this ->user["id"];
        $data = Db::name("bind_bank_card") ->where("user_id",$user_id) ->field("id,name,bank,open_city,open_branch_name,phone,card_no") ->find();
        if(empty($data)){
            exit(ajaxReturn([],0,'暂无数据'));
        }
        exit(ajaxReturn($data,1,'数据获取成功'));
    }

    //虚拟币提现界面
    public function withdrawList(){

        $user_id = $this ->user["id"];
        $data = Db::name("member") ->where(["id"=>$user_id]) ->field("ue_jin,commission") ->find();
        $data["bind_bank_id"] = Db::name("bind_bank_card") ->where(["user_id"=>$user_id]) ->value("id");
        // if(empty($data["bind_bank_id"])){
        //         exit(ajaxReturn([],0,'未找到银行卡'));
        // }
        exit(ajaxReturn($data,1,'数据获取成功'));
    }
    //提现列表
    public function withdrawTable(){
        $user_id = $this ->user["id"];
        $data = Db::name("withdraw") ->alias("t1")
                                         ->join("sd_bind_bank_card t2","t1.bind_bank_id=t2.id")
                                         ->where(["t1.user_id"=>$user_id])
                                         ->field("t2.id,t1.create_at,t1.money,t1.status,t2.name,t2.bank,t1.check_at")
                                         ->order("t1.create_at desc")
                                         ->paginate(config("app.page_num"))
                                         ->toArray();
        exit(ajaxReturn($data,1,'数据获取成功'));
    }

    //提现提交表
    //bind_bank_id  银行卡id
    //money  提现金额
    public function withdrawPost(){
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where("id",$user_id) ->find();
        $data = input();
        if(!is_numeric($data["bind_bank_id"])){
            exit(ajaxReturn([],0,"请先绑定银行卡"));
        }
        if(!is_numeric($data["money"])){
            exit(ajaxReturn([],0,"参数错误"));
        }

        if($data["money"] > $member["ue_jin"]){
            exit(ajaxReturn([],0,"资金不足"));
        }
        $conf = ConfigModel::getConf("withdraw");
        if($data["money"] < $conf["withdraw_line"]){
            exit(ajaxReturn([],0,"充值金额达不到".$conf["withdraw_line"]."元"));
        }

        $data["create_at"] = time();
        $data["user_id"] = $member["id"];
        unset($data["access_token"]);
        Db::startTrans();
        try{
            $after_num = $member["ue_jin"] - $data["money"];
            Db::name("member") ->where(["id"=>$member["id"]]) ->update(["ue_jin"=>$after_num]);
            Minutiae::insertMinu($member["id"],8,"账户本金提现",-$data["money"],$after_num,1,2);
            //写记录
            if($member["vip"] < time()){
                $jin_discount = floor($data["money"] * ($conf["withdraw_ratio"]/100)*100)/100;
                $data["money"] -= $jin_discount;
                //平台流水
                Minutiae::platformFlow($jin_discount,$user_id,0,3,1);
            }
            Db::name("withdraw") ->insert($data);
            Db::commit();
            exit(ajaxReturn([],1,'提交成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //提现佣金
    public function withdMommis(){
        $money = input("money");
        if(!is_numeric($money)){
            exit(ajaxReturn([],0,"参数错误"));
        }
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where("id",$user_id) ->find();
        if($money > $member["commission"]){
            exit(ajaxReturn([],0,"佣金不足"));
        }
        $conf = ConfigModel::getConf("withdraw");
        if($money < $conf["commission_line"]){
            exit(ajaxReturn([],0,"充值金额达不到".$conf["commission_line"]."元"));
        }


        Db::startTrans();
        try{
            $after_dec = $member["commission"] - $money;
            Db::name("member") ->where(["id"=>$member["id"]]) ->update(["commission"=>$after_dec]);
            //写记录
            Minutiae::insertMinu($member["id"],2,"佣金转本金",-$money,$after_dec,2);
            if($member["vip"] < time()){
                $commis_discount = floor($money * ($conf["commission_ratio"]/100)*100)/100;
                $money -= $commis_discount;
                //平台流水
                Minutiae::platformFlow($commis_discount,$user_id,0,4,2);
            }
            $after_inc = $member["ue_jin"] + $money;
            Db::name("member") ->where(["id"=>$member["id"]]) ->update(["ue_jin"=>$after_inc]);
            //写记录
            Minutiae::insertMinu($member["id"],2,"来自佣金",$money,$after_inc);

            Db::commit();
            exit(ajaxReturn([],1,'操作成功'));
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit(ajaxReturn([],0,$e->getMessage()));
        }
    }

    //垫付任务价格表
    public function payPriceList(){
        $type = input("post.type");
        if(!is_numeric($type)){
            exit(ajaxReturn([],0,'参数错误'));
        }
        $list = Db::name("task_commission_fee") ->where(["task_type"=>$type]) ->field("start_price,end_price,commission_fee") ->select();
        exit(ajaxReturn($list,1,'获取成功'));
    }
    //浏览任务价格表
    public function browsePrice(){
        $conf = ConfigModel::getConf("jin");
        $data = ["favorites"=>$conf["is_favorites"],"shopping_trolley"=>$conf["is_shopping_trolley"],"browse_fee"=>$conf["browse_task_fee"]];
        exit(ajaxReturn($data,1,'获取成功'));
    }

    //获取本金和佣金
    public function getMoney(){
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where(["id"=>$user_id]) ->field("ue_jin,commission") ->find();
        if(empty($member)){
            exit(ajaxReturn([],0,'获取失败'));
        }else{
            exit(ajaxReturn($member,1,'获取成功'));
        }
    }
}