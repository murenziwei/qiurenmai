<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-04 17:13:15
 */
namespace app\api\controller;

use think\Db;
use app\api\validate\BuyNo as BuyNoVali;
use app\api\model\Config as ConfigModel;

class Member extends Base
{
    public function blacklist(){
        $user_id = $this ->user["id"];
        $list = Db::name("blacklist") ->where(["user_id"=>$user_id,"is_del"=>0]) ->field("id,block_id,create_at,reason") ->order("create_at desc") ->paginate(config("app.page_num")) ->toArray();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }


    public function doBlack(){
        $block_id = input("block_id");
        $reason = input("reason");
        if(!is_numeric($block_id) || empty($reason)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where(["id"=>$block_id,"type"=>2]) ->find();
        if(empty($member)){
            exit(ajaxReturn([],0,'无此用户'));
        }
        $is_exist = Db::name("blacklist") ->where(["user_id"=>$user_id,"block_id"=>$block_id,"is_del"=>0]) ->find();
        if($is_exist){
            exit(ajaxReturn([],0,'已拉黑此人'));
        }
        $data = ["block_id"=>$block_id,"reason"=>$reason];
        $data["user_id"] = $user_id;
        $data["create_at"] = time();
        $res = Db::name("blacklist") ->insert($data);
        if($res){
            exit(ajaxReturn([],1,'拉黑成功'));
        }else{
            exit(ajaxReturn([],0,'拉黑失败'));
        }
    }

    public function cancelBlack(){
        $id = input("id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,'参数有误'));
        }
        $user_id = $this ->user["id"];
        $res = Db::name("blacklist") ->where(["id"=>$id,"user_id"=>$user_id,"is_del"=>0]) ->update(["is_del"=>1]);
        if($res){
            exit(ajaxReturn([],1,'删除成功'));
        }else{
            exit(ajaxReturn([],0,'删除失败'));
        }
    }

    //刷手端首页
    public function consumerIndex(){
        $user_id = $this ->user["id"];
        $member = Db::name("member") ->where(["id"=>$user_id,"type"=>2]) ->field("ue_account,vip,ue_jin,commission") ->find();
        if(empty($member)){
            exit(ajaxReturn([],0,"获取用户失败"));
        }
        if($member["vip"] >= time()){
            $member["is_vip"] = 1;
        }else{
            $member["is_vip"] = 0;
        }
        $freeze_jin = DB::query('SELECT sum(freeze_cash_pledge) as freeze_cash_pledge,sum(freeze_commission) as freeze_commission from sd_freeze_jin where is_withdraw=0 and user_id='.$user_id);
        $wait_jin = DB::query('SELECT sum(cash_pledge) as wait_cash_pledge,sum(real_commission) as wait_commission,count(*) as wait_count from sd_son_task where status=3 and user_id='.$user_id);
        if($wait_jin[0]["wait_count"] == 0){
            $wait_jin[0]["wait_cash_pledge"] = 0.00;
            $wait_jin[0]["wait_commission"] = 0.00;
        }
        $note = Db::name("introduce") ->value("note");

        exit(ajaxReturn(compact('member','freeze_jin','wait_jin','note'),1,"获取数据成功"));
    }

    //刷手任务
    public function consumerTask(){
        $user_id = $this ->user["id"];
        $task = Db::name("son_task") ->alias("t1")
                                     ->join("sd_task_goods_info t2","t1.goods_info_id=t2.id")
                                     ->join("sd_bind_buy_no t3","t1.wangwang_id=t3.wang_id")
                                     ->where("t1.user_id",$user_id)
                                     ->field("t1.id,t3.wang_id,t1.status,t1.real_commission,t2.goods_name,t2.goods_img,t3.platform_type")
                                     ->order("t1.create_at desc")
                                     ->paginate(config("app.page_num"))
                                     ->toArray();
        exit(ajaxReturn($task,1,"获取数据成功"));
    }

    //绑定淘宝买号
    public function bindBugNo(){
        $data = input();
        $validate = new BuyNoVali();
        if (!$validate->check($data)) {
            exit(ajaxReturn([],0,$validate->getError()));
        }
        //判断是否超过上限
        $user_id = $this ->user["id"];
        $line = ConfigModel::getConf("base","buy_upper_limit");
        $count = Db::name("bind_buy_no") ->where(["user_id"=>$user_id,"is_del"=>0,"platform_type"=>$data["platform_type"]]) ->count();
        if($count >= $line){
            exit(ajaxReturn([],0,"平台的账号绑定不能超过".$line."个"));
        }

        $arr = explode("-",$data["location"]);
        if(!isset($arr[2])){
            exit(ajaxReturn([],0,"所在地区格式错误"));
        }
        $data["province"] = $arr[0];
        $data["user_id"] = $user_id;
        $data["create_at"] = time();
        unset($data["access_token"]);
        $res = Db::name("bind_buy_no") ->insert($data);
        if($res){
            exit(ajaxReturn([],1,"提交成功"));
        }else{
            exit(ajaxReturn([],0,"提交成功"));
        }
    }
    //------------------------------买号---------------------------
    public function buyNoList(){
        $user_id = $this ->user["id"];
        $list = Db::name("bind_buy_no") ->where(["is_del"=>0,"user_id"=>$user_id]) ->field("id,wang_id,platform_type,often_area,zhifu_name,status") ->select();
        exit(ajaxReturn($list,1,"获取数据成功"));
    }


    public function doDelBuyNo(){
        $id = input("id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $user_id = $this ->user["id"];
        $is_del = Db::name('bind_buy_no') ->where(['id'=>$id,"user_id"=>$user_id]) ->update(['is_del'=>1]);
        if($is_del){
           exit(ajaxReturn([],1,"删除成功"));
        }else{
            exit(ajaxReturn([],0,"删除失败"));
        }
    }


    public function editBuyNo(){
        $id = input("id");
        if(!is_numeric($id)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        $user_id = $this ->user["id"];
        $data = Db::name("bind_buy_no") ->where(["user_id"=>$user_id,"is_del"=>0,"user_id"=>$user_id]) ->field("id,wang_id,platform_type,often_area,zhifu_name,name,ip_img,wang_img,location,zhifu_img,sex,street,phone") ->find();
        if(empty($data)){
             exit(ajaxReturn([],0,"数据获取失败"));
        }
        exit(ajaxReturn($data,1,"数据获取成功"));
    }


    public function doEditbuyNo(){
        $data = input();
        if(!isset($data['id']) || !is_numeric($data['id'])){
            exit(ajaxReturn([],0,"参数错误"));
        }
        $validate = new buyNoVali();
        if (!$validate->check($data)) {
           exit(ajaxReturn([],0,$validate->getError()));
        }
        $user_id = $this ->user["id"];
        unset($data["access_token"]);
        $res = Db::name('bind_buy_no') ->where(['id'=>$data['id'],"user_id"=>$user_id]) ->update($data);

        if($res !== false){
            exit(ajaxReturn([],1,"修改成功"));
        }else{
            exit(ajaxReturn([],0,"修改失败"));
        }
    }

    //待完成订单
    public function waitTaskList(){
        $user_id = $this ->user["id"];
        $list = Db::name("son_task") ->alias("t1")
                                     ->join("sd_task_goods_info t2","t1.goods_info_id=t2.id")
                                     ->join("sd_bind_buy_no t3","t1.wangwang_id=t3.wang_id")
                                     ->where(["t1.user_id"=>$user_id])
                                     ->where("t1.status","between","2,4")
                                     ->field("t1.id,t3.wang_id,t1.status,t1.real_commission,t2.goods_name,t2.goods_img,t3.platform_type,t1.is_wait_sale,t1.task_type")
                                     ->order("t1.create_at desc")
                                     ->paginate(config("app.page_num"))
                                     ->toArray();

        exit(ajaxReturn($list,1,"获取数据成功"));
    }

    //修改密码
    public function editPwd(){
        $new_pwd = input("post.new_pwd");
        $old_pwd = input("post.old_pwd");
        $conf_pwd = input("post.conf_pwd");
        if(empty($new_pwd) || empty($old_pwd) || empty($conf_pwd)){
            exit(ajaxReturn([],0,"参数有误"));

        }
        if($new_pwd != $conf_pwd){
            exit(ajaxReturn([],0,"确认密码不正确"));
        }
        $user_id = $this ->user["id"];
        $old_pwd = MD5(md5($old_pwd) . config('app.salf'));
        $ue_pwd = Db::name("member") ->where(["id"=>$user_id]) ->value("ue_password");
        if($old_pwd != $ue_pwd){
            exit(ajaxReturn([],0,"旧密码不正确"));
        }
        $new_pwd = MD5(md5($new_pwd) . config('app.salf'));
        $res = Db::name("member") ->where(["id"=>$user_id]) ->update(["ue_password"=>$new_pwd]);
        if($res !== false){
            exit(ajaxReturn([],1,"修改成功"));
        }else{
            exit(ajaxReturn([],0,"修改失败"));
        }
    }

    //忘记密码
    public function forGetPwd(){
        $phone = input("post.phone");
        $code = input("post.code");
        $new_pwd = input("post.new_pwd");
        $conf_pwd = input("post.conf_pwd");
        if(empty($phone) || empty($new_pwd) || empty($conf_pwd) || empty($code)){
            exit(ajaxReturn([],0,"参数有误"));
        }
        if($new_pwd != $conf_pwd){
            exit(ajaxReturn([],0,"确认密码不正确"));
        }
        if(cache($phone) != $code){
            exit(ajaxReturn([],0,"验证码错误"));
        }
        $new_pwd = MD5(md5($new_pwd) . config('app.salf'));
        $user_id = $this ->user["id"];
        $res = Db::name("member") ->where(["id"=>$user_id]) ->update(["ue_password"=>$new_pwd]);
        if($res !== false){
            exit(ajaxReturn([],1,"修改成功"));
        }else{
            exit(ajaxReturn([],0,"修改失败"));
        }
    }
}