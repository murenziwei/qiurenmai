<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2018/12/30
 * Time: 8:06
 */

namespace app\admin\logic;

use app\common\BaseModel;
use app\admin\entity\Login as loginEntity;
use app\common\model\Auth as authModel;
use app\common\model\Role as roleModel;
use app\admin\model\User as userModel;
use think\facade\Session;

class Login extends BaseModel
{
    public $loginEntity;
    public function __construct(array $data = [])
    {
        parent::__construct($data);
        $this->loginEntity = new loginEntity();
    }

    public function checkLogin(){
        if(!array_key_exists('username',$this->requestData)||empty($this->requestData['username']))
            return $this->failReturn('账号不能为空');
        if(!array_key_exists('password',$this->requestData)||empty($this->requestData['password']))
            return $this->failReturn('密码不能为空');
        $password = md5(md5($this->requestData['password']).config('app.salf'));
        $this->loginEntity->setUsername($this->requestData['username']);
        $this->loginEntity->setPassword($password);

        $status = userModel::where($this->loginEntity->params())->find();
        //dump($status);die;
        if ($status) {
            if($status['status']==0){
                return $this->failReturn('账号已被冻结');
            }
            $lifeTime = 24 * 3600;
//            Session::init([
//                'prefix'         => 'module',
//                'type'           => '',
//                'auto_start'     => true,
//            ]);
            Session::set('nickname',$status['nickname']);
            Session::set('user_id',$status['user_id']);
            Session::set('role_id',$status['role_id']);
            $this->_putMenuAndAuthToSession($status['role_id']);
            return $this->successReturn('登录成功');
        }else{
            return $this->failReturn('用户名或密码错误');
        }
    }

    private function _putMenuAndAuthToSession($role_id){
        $authModel = authModel::where(['is_delete'=>0]);
        //查找出用户所拥有的权限
        $row = roleModel::where(['role_id'=>$role_id])->find();
        $auth_id_list = $row['auth_id_list'];
//        Session::init([
//            'prefix'         => 'module',
//            'type'           => '',
//            'auto_start'     => true,
//        ]);
        if ($auth_id_list == '*') {
            //则为超级管理员
            Session::set('auth','*');
            $menu = $authModel->where('pid = 0')->select()->toArray();//查找出一级权限
            //查找出所有的二级权限
            foreach ($menu as $k => $v) {
                $menu[$k]['sub'] = authModel::where(['pid' => $v['auth_id'],'is_delete'=>0])->select()->toArray();
            }
            Session::set('menu',$menu);
        }else{
            $auth = array();
            $menu = array();
            //非超级管理员
            $all_auth = authModel::where("auth_id","in", "$auth_id_list")->select(); //查找出所有的权限
            if($all_auth){
                $all_auth = $all_auth->toArray();
            }
            //遍历权限，把rules字段存在auth中

            foreach ($all_auth as $k => $v) {
                $auth[] = $v['rules'];
                //并找出所有的一级权限
                if ($v['pid'] == 0) {
                    $menu[] = $v;
                }
            }

            //找出所有的二级权限
            foreach ($menu as $k => $v) {
                foreach ($all_auth as $vv) {
                    if ($vv['pid'] == $v['auth_id']) {
                        $menu[$k]['sub'][] = $vv;
                    }
                }
            }
            //存session
            $lifeTime = 24 * 3600;
            Session::set('auth',$auth);
            Session::set('menu',$menu);

        }
    }
}