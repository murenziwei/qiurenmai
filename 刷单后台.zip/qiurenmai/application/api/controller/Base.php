<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:18:03
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-06-11 18:25:45
 */
namespace app\api\controller;

use app\common\service\Oauth2;
use app\engine\service\AihCore as OtherClass;
use PHPQRCode\QRcode;
use think\App;
use think\Controller;
use app\lib\exception\AccessException;
use think\Exception;
use app\common\model\Member as memberModel;
use app\common\model\Receivables as receivablesModel;
use think\facade\Request;
use think\Db;
use app\lib\exception\TokenException;

class Base extends Controller
{
    public $request;
    public $requestData;//请求数据包
    public $aesData;//请求数据包
    protected $user;

    public function __construct()
    {
        parent::__construct();
        try{
            //验证token
            $this ->checkToken();
        }catch (\Exception $e){
            $returnData = json_encode([
                'data' => array(),
                'code' => -1,
                'message' => $e->getMessage(),
                'errorCode' => ''
            ]);
            exit($returnData);
        }
    }
    //比对token
    public function checkToken(){
        $time = time();
        $access_token = $this->request->param('access_token');
        $user_info = Db::name("member") ->where("access_token",$access_token)
                                        ->where("login_at","gt",$time)
                                        ->field("id")
                                        ->find();
        if(empty($user_info)){
            throw new TokenException([
                'message'=>'token无效',
                'errorCode'=>10004
            ]);
        }else{
            $this ->user = $user_info;
        }
    }


}