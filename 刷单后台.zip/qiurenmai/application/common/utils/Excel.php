<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/1/10
 * Time: 16:15
 */

namespace app\common\utils;


class Excel
{
    /**
     * 订单数据写入Excel
     * @param $data
     * @param string $name
     */
    public static function orderExport($data,$name=''){
        $fileName = 'result';
        if(empty($name))
            $fileName .= "_" . date("Y_m_d", time()).time() . ".xls";
        else
            $fileName .= "_" . $name . '_' . date("Y_m_d", time()).time() . ".xls";
        $objPHPExcel = new \PHPExcel();
        $objPHPExcel->getProperties();
        $key = ord("A"); // 设置表头
        foreach ($data['head_list'] as $v) {
            $colum = chr($key);
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue($colum . '1', $v);
            $key++;
        }
        //设置数据
        $column = 2;
        $objActSheet = $objPHPExcel->getActiveSheet();
        $objActSheet->getStyle('G')->getNumberFormat()->setFormatCode ("0.0000");
        $objActSheet->getStyle('H')->getNumberFormat()->setFormatCode ("0.0000");
        $objActSheet->getStyle('I')->getNumberFormat()->setFormatCode ("0.0000");
        $objActSheet->getStyle('J')->getNumberFormat()->setFormatCode ("0.0000");
        foreach ($data['list'] as $key => $rows) { // 行写入
            $span = ord("A");
            foreach ($rows as $keyName => $value) { // 列写入
                $objActSheet->setCellValue(chr($span) . $column, $value);
                $span++;
            }
            $column++;
        }
        $fileName = iconv("utf-8", "gb2312", $fileName); // 重命名表

        //设置列宽度
        $objPHPExcel->setActiveSheetIndex(0); // 设置活动单指数到第一个表,所以Excel打开这是第一个表
        $objActSheet->getColumnDimension( 'A')->setWidth(10);//ID
        $objActSheet->getColumnDimension( 'B')->setWidth(25);//订单号
        $objActSheet->getColumnDimension( 'C')->setWidth(50);//商品名称
        $objActSheet->getColumnDimension( 'D')->setWidth(50);//规格
        $objActSheet->getColumnDimension( 'E')->setWidth(10);//下单用户id
        $objActSheet->getColumnDimension( 'F')->setWidth(15);//下单用户手机
        $objActSheet->getColumnDimension( 'G')->setWidth(15);//支付金额
        $objActSheet->getColumnDimension( 'H')->setWidth(15);//商品总价
        $objActSheet->getColumnDimension( 'I')->setWidth(15);//商品单价
        $objActSheet->getColumnDimension( 'J')->setWidth(15);//订单运费
        $objActSheet->getColumnDimension( 'K')->setWidth(10);//购买数量
        $objActSheet->getColumnDimension( 'L')->setWidth(25);//收货人
        $objActSheet->getColumnDimension( 'M')->setWidth(50);//收货地址
        $objActSheet->getColumnDimension( 'N')->setWidth(15);//收货人电话
        $objActSheet->getColumnDimension( 'O')->setWidth(50);//买家留言
        $objActSheet->getColumnDimension( 'P')->setWidth(15);//物流名称
        $objActSheet->getColumnDimension( 'Q')->setWidth(15);//发货单号
        $objActSheet->getColumnDimension( 'R')->setWidth(15);//订单状态
        $objActSheet->getColumnDimension( 'S')->setWidth(25);//下单时间
        self::export($objPHPExcel,$fileName);
    }

    /**
     * 输出Excel下载
     * @param $object
     * @param $file_name
     */
    public static function export($object,$file_name){
        header("Content-Type: text/html;charset=utf-8");
        header('Content-Type: application/vnd.ms-excel');
        header("Content-Disposition: attachment;filename='$file_name'");
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($object, 'Excel5');
        $objWriter->save('php://output'); // 文件通过浏览器下载
        exit();
    }
}