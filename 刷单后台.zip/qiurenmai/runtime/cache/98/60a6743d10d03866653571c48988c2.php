<?php
//000000604800
 exit();?>
{"user":{"id":1,"uid":"","ue_account":"tst","cash_pledge":"0.00","ue_phone":"tst","qq_no":"","email":"","type":null,"create_at":"","last_login_at":"","bank_card":"","status":0,"access_token":""},"access_token":"26c45b7496018ed7afefad2502868614","expire_in":604800,"refresh_token":"fa43cab84a043d0fdde4e6eb5e0a60f8","timestamp":1559700992,"scope":""}