<?php
namespace app\lib\exception;


class OrderException extends BaseException
{
    public $code = 0;
    public $message = '订单不存在，请检查ID';
    public $errorCode = 80000;

    public function __construct(array $params = [])
    {
        parent::__construct($params);
        if(array_key_exists('msg',$params))$this->message = $params['msg'];
        if(array_key_exists('errorCode',$params))$this->errorCode = $params['errorCode'];
        if(array_key_exists('code',$params))$this->code = $params['code'];
    }

}