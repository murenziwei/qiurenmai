<?php
namespace app\api\validate;


class OrderImg extends BaseVali
{
    protected $rule = [
        'search_img'  => 'require',
        'order_img' => 'require',
        'follow_img' => 'require',
        'record_img' => 'require',
        'favorites_img' => 'require',
        'order_no' => 'require',
        'real_pay' => 'require'
    ];

    //验证场景
    protected $scene = [
        'type1' => ['search_img','order_img','follow_img','record_img','favorites_img','order_no','real_pay'],
        'type2' => ['order_img','follow_img','record_img','favorites_img','order_no','real_pay'],
        'type3' => ['order_img','follow_img','order_no','real_pay'],
        'type4' => ['search_img','order_img','follow_img','record_img','favorites_img','order_no','real_pay'],
        'type5' => ['search_img','record_img'],
        'wait'  => ['search_img','record_img','favorites_img']
    ];

    protected $field = [
        'search_img'  => '搜索框',
        'order_img' => '订单',
        'follow_img' => '店铺关注',
        'record_img' => '浏览历史',
        'favorites_img' => '店铺收藏',
        'order_no' => '订单号',
        'real_pay' => '垫付金额'
    ];
}