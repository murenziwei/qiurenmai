<?php
/**
 * @Author: Marte
 * @Date:   2019-06-05 09:17:52
 * @Last Modified by:   Marte
 * @Last Modified time: 2019-07-05 15:21:57
 */
namespace app\api\controller;

use think\Db;
use think\Controller;
use app\api\model\Config as ConfigModel;
use app\api\model\Minutiae;
use app\api\model\Member as MemberModel;

class Run extends Controller
{

    //为垫付任务生成子任务
    public function createSonPay(){
        $task = Db::name("task") ->where(["is_create_son"=>0,"is_pay"=>1]) ->where("task_type","neq",5) ->field("id,user_id,is_top,task_num,task_type,shop_wang_id,every_commission,every_cash_pledge,add_service_fee,wait_sell_at") ->find();
        if(empty($task)){
            exit("无任务");
        }
        $goods_info_id = Db::name("task_goods_info") ->where(["task_id"=>$task["id"]]) ->value("id");
        if(empty($goods_info_id)){
            exit("未找到商品id");
        }
        $comment_ask = Db::name("task_comment_info") ->where(["task_id"=>$task["id"]]) ->field("id,type") ->select();
        if(empty($comment_ask)){
            exit("未找到评论需求");
        }
        //佣金折扣
        $com_discount = ConfigModel::getConf("jin","com_discount");
        Db::startTrans();
        try{
            $time = time();
            $data = ["task_id"=>$task["id"],"shop_id"=>$task["user_id"],"goods_info_id"=>$goods_info_id,"create_at"=>$time,"is_top"=>$task["is_top"],"task_type"=>$task["task_type"],"shop_wang_id"=>$task["shop_wang_id"],"add_service_fee"=>$task["add_service_fee"],"cash_pledge"=>$task["every_cash_pledge"],"commission"=>$task["every_commission"]];
            //给买手的佣金
            $data["real_commission"] = $data["commission"] - floor($data["commission"] * ($com_discount/100)*100)/100;
            //生成放出时间
            $send_time_arr = $this ->paySendAt($task["id"]);

            foreach($comment_ask as $k => &$v){
                // if($v['type'] != 1){
                //    $data["commission"] = $task["every_commission"] + 1;
                // }
                $data["comment_info_id"] = $v["id"];
                if(!empty($send_time_arr)){
                    $data["start_at"] = $send_time_arr[$k];
                }else{
                    $data["start_at"] = $time;
                }
                Db::name("son_task") ->insert($data);
            }


            //更改状态
            Db::name("task") ->where(["id"=>$task["id"]]) ->update(["is_create_son"=>1]);
            Db::commit();
            exit("生成成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
    }

    //生成放出时间私类
    private function paySendAt($task_id){
        //放出计划
        $send_plan = Db::name("task_send_plan") ->where(["task_id"=>$task_id]) ->select();
        if(empty($send_plan)){
            return false;
        }
        $arr = [];
        foreach($send_plan as $k=>$v){
            $start_at = $v["start_at"];
            for($i = 0;$i < $v["task_num"];$i++){
                $start_at += ($v["time_interval"] * 60);
                $arr[] = $start_at;
            }
        }
        return $arr;
    }

    //为浏览任务生成子任务
    public function createSonBrowse(){
        $task = Db::name("task") ->where(["is_create_son"=>0,"is_pay"=>1,"task_type"=>5]) ->field("id,user_id,is_top,task_num,task_type,shop_wang_id,every_commission") ->find();
        if(empty($task)){
            exit("无任务");
        }
        $goods_info_id = Db::name("task_goods_info") ->where(["task_id"=>$task["id"]]) ->value("id");
        if(empty($goods_info_id)){
            exit("未找到商品id");
        }
        $browse_calendar = Db::name("browse_calendar") ->where(["task_id"=>$task["id"]]) ->select();
        if(empty($browse_calendar)){
            exit("浏览日程为空");
        }
        //佣金折扣
        $com_discount = ConfigModel::getConf("jin","com_discount");
        $real_commission = $task["every_commission"] - floor($task["every_commission"] * ($com_discount/100)*100)/100;
        Db::startTrans();
        try{

            $data = ["task_id"=>$task["id"],"shop_id"=>$task["user_id"],"goods_info_id"=>$goods_info_id,"create_at"=>time(),"is_top"=>$task["is_top"],"task_type"=>$task["task_type"],"shop_wang_id"=>$task["shop_wang_id"],"commission"=>$task["every_commission"],"real_commission"=>$real_commission];
            foreach($browse_calendar as $k => $v){
                $data["browse_calendar_id"] = $v["id"];
                $calendar = json_decode($v["calendar"],true);
                foreach($calendar as $sk =>$sv){
                    for($i = 0;$i < $sv;$i++){
                        $data["start_at"] = $sk * 3600 + $v["start_day"];
                        Db::name("son_task") ->insert($data);
                    }
                }
            }
            // for($i = 0;$i < $v["task_num"];$i++){
            //     $data["start_at"] = $send_time_arr[$i];
            //     Db::name("son_task") ->insert($data);
            // }

            //更改状态
            Db::name("task") ->where(["id"=>$task["id"]]) ->update(["is_create_son"=>1]);
            Db::commit();
            exit("生成成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
    }

    //执行放出计划
    public function execSendPlan(){
        $res = Db::name("son_task") ->where(["status"=>0]) ->where("start_at","elt",time()) ->update(["status"=>1]);
        exit($res);
    }
    //自动取消待操作
    public function autoCancelNot(){
        //取消时间
        $cancel_at = ConfigModel::getConf("base","cancel_at") * 60;
        $due_task = Db::name("son_task") ->where(["status"=>2,"is_wait_sale"=>0]) ->where("accept_at","elt",time()-$cancel_at) ->field("id,user_id") ->find();
        if(empty($due_task)){
            exit("无过期任务");
        }
        $this ->CancelTask($due_task["id"],$due_task["user_id"]);
    }
    //自动取消预售
    public function autoCancelWait(){
        $due_task = Db::name("son_task") ->alias("t1")
                                         ->join("sd_task t2","t1.task_id = t2.id")
                                         ->where(["t1.status"=>2,"t1.is_wait_sale"=>1,"t2.task_type"=>3])
                                         ->where("t2.wait_sell_at","elt",time()-60*60*24)
                                         ->field("id,user_id")
                                         ->find();
        if(empty($due_task)){
            exit("无待售任务");
        }
        $this ->CancelTask($due_task["id"],$due_task["user_id"]);
    }

    //取消私类
    private function CancelTask($id,$user_id){
        Db::startTrans();
        try{
            Db::name("son_task") ->where(["id"=>$id]) ->update(["status"=>1,"user_id"=>0]);
            //扣钱
            //Db::name("member") ->where(["id"=>$user_id]) ->setDec("ue_jin");
            Db::commit();
            exit("生成成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
    }

    //任务完成后处理
    public function doFinishTask(){
        $son_task = Db::name("son_task") ->where(["status"=>6,"finish_at"=>""]) ->where("task_type","neq",5) ->find();
        if(empty($son_task)){
            exit("无任务");
        }
        $conf = ConfigModel::getConf();

        $comment_fee = Minutiae::getComiss($son_task["comment_info_id"],$conf);
        Db::startTrans();
        try{
            //退一佣金
            $member = Db::name("member") ->where(["id"=>$son_task["user_id"]]) ->field("commission,pid") ->find();
            if(empty($member)){
                exit(ajaxReturn([],0,"用户余额未找到"));
            }
            $after_num = $conf["take_deposit"] + $member["commission"];

            Db::name("member") ->where(["id"=>$son_task["user_id"]]) ->update(["commission"=>$after_num]);

            $after_num = MemberModel::afterRes($son_task["user_id"],$conf["take_deposit"],1,"commission");
            //写记录
            Minutiae::insertMinu($son_task["user_id"],10,'任务完成返还,任务ID:'.$son_task["id"],$conf["take_deposit"],$after_num,2,1);
            $fee_info = Db::name("fee_info") ->where("task_id",$son_task["task_id"]) ->find();

            $task_income = $fee_info["thousand_fee"] + $fee_info["favorites_fee"] + $fee_info["add_fee"] + $comment_fee;
            $commiss_income = $son_task["commission"] - $son_task["real_commission"];
            //任务收入和佣金收入
            Minutiae::platformFlow($task_income,$son_task["shop_id"],$son_task["id"],1);
            Minutiae::platformFlow($commiss_income,$son_task["shop_id"],$son_task["id"],2);
            //给买手上级一金币
            if($member["pid"] != 0){
                 $after_p = MemberModel::afterRes($member["pid"],1,1,"commission");
                 Minutiae::insertMinu($member["pid"],12,'下级佣金,用户ID:'.$son_task["user_id"],1,$after_p,2,1);
                 Minutiae::platformFlow(-1,$member["pid"],$son_task["id"],9,2,2);
            }
            Db::name("son_task") ->where(["id"=>$son_task["id"]]) ->update(["finish_at"=>time()]);
            Db::commit();
            exit("处理成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
    }

    //空包处理
     public function doEmptyPack(){
        $empty_parcel = Db::name("task")->alias("t1")
                                       ->join("sd_son_task t2","t1.id=t2.task_id")
                                       ->join("sd_empty_parcel_serve t3","t1.id=t3.task_id")
                                       ->join("sd_order t4","t2.id=t4.task_id")
                                       ->where(["t2.status"=>3,"t4.post_no"=>""])
                                       ->field("t2.id as son_task_id,t3.*")
                                       ->find();
        if(empty($empty_parcel)){
            exit("无单");
        }
        //$son_task = Db::name("son_task") ->where(["task_id"=>$empty_parcel["task_id"],])
        $order = Db::name("order") ->alias("t1")
                                   ->join("sd_bind_shop t2","t1.shop_id=t2.wangwang_id")
                                   ->join("sd_bind_buy_no t3","t1.buy_id=t3.wang_img")
                                   //->where(["t1.task_id"])
                                   ->field("t2.shop_name,t2.phone as post_phone,t2.address as post_addr,t2.detailed_address as post_street,t3.name as ue_name,t3.phone as ue_phone,t3.location as ue_addr,t3.street as ue_street")
                                   ->find();
        $order["post_addr"] = explode("-", $order["post_addr"]);
        $order["ue_addr"] = explode("-", $order["ue_addr"]);
        if(!isset($order["post_addr"][2]) || !isset($order["post_addr"][2])){
            exit("地址错误");
        }
        $pack = new Emptypack();
        $json = $pack ->main(compact("empty_parcel","order"));
        $res = json_decode($json,true);
        if(isset($res["code"]) && $res["code"] == 0){
            $update = Db::name("order") ->where(["task_id"=>$empty_parcel["son_task_id"]]) ->update(["post_no"=>$res["Data"][0]["Trackingno"]]);
            if($update){
                exit("更新成功");
            }else{
                exit("更新失败");
            }
        }else{
            dump($res);
        }
     }

     //自动解冻佣金
     public function unfreezeJin(){
        $data = Db::name("freeze_jin") ->alias("t1")
                                       ->join("sd_son_task t2","t1.son_task_id=t2.id")
                                       ->where(["t1.is_withdraw"=>0,"t2.status"=>6])
                                       ->field("t1.*")
                                       ->find();
        if(empty($data)){
            exit("无单");
        }
        Db::startTrans();
        try{
            if($data["freeze_cash_pledge"] != 0.00){
                $after_jin = MemberModel::afterRes($data["user_id"],$data["freeze_cash_pledge"],1);
                //写记录
                Minutiae::insertMinu($data["son_task_id"],11,"本金解冻",$data["freeze_cash_pledge"],$after_jin);
                $update = ["ue_jin"=>$after_jin];
            }

            $after_comiss = MemberModel::afterRes($data["user_id"],$data["freeze_commission"],1,"commission");
            //写记录
            Minutiae::insertMinu($data["son_task_id"],11,"佣金解冻",$data["freeze_commission"],$after_comiss,2);
            $update["commission"] = $after_comiss;
            Db::name("member") ->where(["id"=>$data["id"]]) ->update($update);
            Db::name("freeze_jin") ->where(["id"=>$data["id"]]) ->update(["is_withdraw"=>1]);
            Db::commit();
            exit("解冻成功");
        } catch (\Exception $e) {
            // 回滚事务
            Db::rollback();
            exit($e->getMessage());
        }
     }
}