<?php
namespace app\api\validate;

use think\Validate;

class EmptyPar extends Validate
{
    protected $rule = [
        'parcel_weight' => 'require|float',
        'post_type' => 'require'
    ];

    protected $field = [
        'parcel_weight' => '重量',
        'post_type' => '快递类型'
    ];

}